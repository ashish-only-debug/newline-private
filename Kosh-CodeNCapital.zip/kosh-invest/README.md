# Kosh — AI investing coach for first-time investors

Built for **Code N Capital** (Finnexia × IIIT-Delhi). Kosh turns a stock-tracking dashboard into an assistant that *explains* the market: what a company does, how it's performing, how risky it is, and why news matters, all in plain language.

> All companies, prices, financials and news are **fictional**. Indices are simulated from the demo universe. No real trading or payments.

## Run it

```bash
node server.js
```
Then open http://localhost:5173. No install step and no dependencies (Node 18+).

Optional: turn on LLM answers in the chat (the key stays on the server and never reaches the browser):
```bash
OPENAI_API_KEY=sk-... OPENAI_MODEL=gpt-4o-mini node server.js
```
Without a key, the built-in explainer engine answers instead. You can also open `index.html` directly from a static host.

## Deploy (Vercel)

The repo is ready for Vercel with no build step: static files at the root, serverless functions in `/api`.

```bash
npx vercel login
npx vercel --prod
```

Accept the defaults (framework "Other", no build command, output directory = root).

On the hosted site:
- **Works:** everything except Live League, including mutual funds, headlines and inflation, served through `/api` functions and cached by Vercel's CDN.
- **If the World Bank API is slow:** the inflation function serves the bundled real snapshot in `data/inflation-snapshot.json`, labelled as cached.
- **Live League:** shows a note instead. Rooms need one continuously running server, so run `node server.js` on a laptop for the league.

## Design

Apple-inspired, using Apple's design language rather than its branding:
- **Font:** the system font (SF Pro on Apple devices), with tabular digits so numbers line up.
- **Colours:** the system palette, with every text and button colour pair checked against WCAG AA (4.5:1).
- **Look and controls:** translucent bars, pill buttons, iOS-style segmented controls, Messages-style chat bubbles, and a bottom tab bar on phones.
- **Appearance:** follows the device's light/dark setting (Auto), with a Light / Dark override.
- **No web fonts:** the page renders the same offline.

## Real data (live, not simulated)

These need `node server.js` and an internet connection. The server fetches and caches each source; nothing is generated.

| Feature | Source | What you get |
|---|---|---|
| **Mutual Fund Explorer** (`#/funds`) | AMFI NAV data via [mfapi.in](https://www.mfapi.in) | Search any Indian mutual fund. See its full NAV history, 1M–10Y returns, volatility and worst fall. Run a **SIP backtest on real past NAVs** (with XIRR) and compare up to 3 funds. |
| **Live Headlines** (`#/headlines`) | Google News RSS | Today's real Indian market headlines by topic or search. Each links to the publisher's article, with "What's repo rate / IPO / FII…?" explainer chips. Headlines are shown as published, never rewritten. |
| **Inflation** (Learning Centre → Calculators, Goal planner, SIP backtest) | World Bank indicator FP.CPI.TOTL.ZG | India's yearly consumer price inflation, used for real (after-inflation) returns and inflation-adjusted goals. |

If a source is down, the page says so and offers a retry. Inflation can also be typed in by hand. The World Bank API can be slow, so the server loads it in the background and keeps the last real response in `.cache-inflation.json`, labelled as a cached copy. Yahoo Finance stock prices were tested but are rate-limited, so they aren't used, and the 12 stocks remain simulated.

The top bar shows **Live data** (green) on real-data pages and **Demo data** (amber) everywhere else.

## The differentiator: Crash Test + Bias Mirror + Live League

Most beginners don't lose money from a lack of information. They lose it through **behaviour**: panic-selling in crashes, chasing hype, betting everything on one stock. Kosh is built to train that.

- **Crash Test** (`#/crash`): spread ₹1,00,000 across 5 assets, then live through a scripted 60-day crash and recovery in about 90 seconds. Headlines flash up, the index falls 24%, and there's a big red **Sell everything** button. Two traps are built in: **SETU**, a hype stock up 32% that then falls 53% from its peak, and **Akash Telecom**, whose fall is caused by real company news so it never recovers.
- **Bias Mirror** report: your trades become an *Investor DNA* archetype (Panic Seller, FOMO Chaser, All-In Gambler, Falling-Knife Catcher, Sideliner, Overtrader, Steady Hand, Bargain Hunter) with a **discipline score**. Every habit is measured in rupees from your own trades, e.g. "selling cost you ₹20,620". You're compared with the index, with cash, and with simply holding the portfolio you built on day 0.
- **Live League** (`#/league`): the presenter creates a room on the projector. The audience scans the QR code and joins from their phones on the same Wi-Fi. Everyone plays the same market at the same moment, with a live leaderboard. The final screen ranks **best return** *and* **most disciplined**, because return can be luck and discipline isn't.

### Running a league at the event
1. Run `node server.js` on your laptop. It prints the Wi-Fi address players should use.
2. Open `#/league` → **Create room** and put that screen on the projector.
3. Players scan the QR code (or type the link), pick a nickname, and you press **Start round**. That gives them 20 s to build a portfolio, then 90 s of market.
4. Press **New round** to play again with the same room.

Notes: phones must be on the same Wi-Fi as the laptop, and venue networks sometimes block devices from talking to each other. A phone hotspot from your laptop is a reliable fallback. macOS may ask to allow incoming connections for `node`; allow it. The QR code loads a small library from cdnjs. If there's no internet the code won't show, but the link still works.

## More standout tools

- **Tip Check** (`#/tipcheck`): paste a WhatsApp, Telegram or Instagram stock tip. It highlights pump-and-dump warning signs right in the text, such as guaranteed returns, "operator"/insider claims, paid VIP groups, urgency, penny stocks and secrecy, and explains each one. It also lists good signs (fundamentals, honest risk, sources, SEBI registration number), tells you what to verify, and where to report fraud (SEBI SCORES, cybercrime.gov.in, helpline 1930). It runs entirely in the browser.
- **Time Machine** (`#/timemachine`): "If I'd put ₹1 lakh into X three years ago…" It compares a lump sum, a monthly SIP, a bank FD, and panic-selling at the bottom. It also shows the **pain** you'd have sat through: worst drop from peak, lowest value and days spent below what you put in.
- **My Plan** (`#/journey`): a 6-question risk profile that gives an example asset mix (with safety overrides for short horizons and panic-sellers, plus an emergency-fund warning). A goal planner works out the monthly saving needed and shows weak-market and good-market outcomes. **15 badges and 5 levels** reward using the app's learning features.
- **Markets heatmap and beginner screens:** tiles sized by market cap, coloured by day change, 1Y return, risk or P/E. One-tap screens like "Profitable & low debt", "Fast growers", "Dividend payers" and "Lower risk" each explain the idea behind them.
- **What you actually keep** (Learning Centre → Calculators): Indian charges (STT, stamp duty, exchange/SEBI fees, GST, DP) and capital-gains tax (STCG 20%, LTCG 12.5% above ₹1.25 lakh, plus 4% cess). It shows how much tax holding past 12 months would save.

## What's inside

| Area | What it does |
|---|---|
| **Dashboard** | AI daily brief, simulated NIFTY 50/SENSEX, gainers/losers, trending (unusual volume), watchlist, portfolio, recently viewed, updates, learning progress. You can show, hide and reorder widgets. |
| **Markets** | Search, sector and size filters, gainer/loser/watchlist tabs, sortable columns, 1M sparklines, risk score. |
| **Stock page** | 1D/1W/1M/6M/1Y/ALL chart with volume and a NIFTY overlay, an auto "chart explained" note, an **AI Stock Explainer** (beginner and advanced), 12 metrics each with an ⓘ explainer, revenue/profit history, **explainable risk** (6 factors with evidence), bull vs bear case, a research checklist and related insights. |
| **Compare** | 2–3 companies: normalised % chart, side-by-side table with ★ for the leader on each metric, AI key differences, risk side by side. |
| **News & Insights** | Category and sentiment filters, plus an **AI News Impact Analyzer**: what happened, why it matters, exposed companies with their live numbers, and what to watch. New demo items are released during the session so alerts can be shown live. |
| **Learning Centre** | 5 lessons with built-in quizzes, a searchable glossary (meaning, why it matters, how to read it, example, advanced note), a quick quiz, decision scenarios, and SIP, lump-sum/CAGR, risk-vs-return and P/E fair-value calculators. |
| **Simulator** | ₹10,00,000 of virtual money. Buy/sell ticket with validation, a review step and a confirmation. Holdings P&L, sector allocation donut, performance chart, transaction history, AI portfolio coach, reset. |
| **Alerts** | Price above/below, % day move, company news, watchlist movers and portfolio change. Checked on every tick, with an in-app bell and toasts. |
| **Kosh AI chat** | Knows which stock you're looking at. Handles "why is it moving", terms, risks, stocks vs mutual funds, financial performance, comparisons and your portfolio. It refuses to give buy/sell advice. |

## How the AI works (and why it's trustworthy)
- **Local explainer engine** (`js/ai.js`): every sentence is computed from the numbers on screen, such as CAGR, margins, P/E vs median, PEG, volatility, drawdown and debt. Nothing is invented, and each risk factor shows its evidence.
- **Optional LLM** (`server.js` → `/api/chat`): the question goes out with the selected stocks' data as JSON context. A system prompt keeps the model grounded in that data, tells it to label demo data, and forbids personalised buy/sell advice. It's rate-limited, and the key never reaches the frontend.
- Each chat answer shows which engine produced it and what data it used.

## Files
- `index.html`, `styles.css`: shell and design tokens (dark and light themes, responsive)
- `js/data.js`: fictional companies, glossary, lessons, scenarios, demo news
- `js/market.js`: deterministic price history, metrics, simulated ticks and indices
- `js/ai.js`: explainer, risk, comparison, chart story, news impact, chat
- `js/charts.js`: dependency-free SVG charts with hover tooltips
- `js/app.js`: routing, screens, simulator, alerts, search, chat UI
- `server.js`: static server plus an optional LLM proxy
