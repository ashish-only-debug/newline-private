// Shared helpers for the Vercel functions (files starting with "_" are not routes).
// The same sources as server.js: mfapi.in (AMFI NAVs), Google News RSS, World Bank.
// Responses are cached by Vercel's CDN via s-maxage so judges get fast, stable results.

function send(res, code, obj, cacheSeconds = 0) {
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", cacheSeconds ? `public, s-maxage=${cacheSeconds}, stale-while-revalidate=${cacheSeconds * 4}` : "no-store");
  res.statusCode = code;
  res.end(JSON.stringify(obj));
}

async function getJson(url, ms = 9000) {
  const r = await fetch(url, { headers: { "User-Agent": "KoshEdu/1.0", Accept: "application/json" }, signal: AbortSignal.timeout(ms) });
  if (!r.ok) throw new Error("upstream " + r.status);
  return r.json();
}

const decode = (s) => String(s || "").replace(/<!\[CDATA\[|\]\]>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).trim();

const DOWN = { error: "The data source didn't respond. Check your internet connection and try again." };

module.exports = { send, getJson, decode, DOWN };
