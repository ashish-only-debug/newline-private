const { send } = require("./_lib");
// Hosted build: no LLM key, so the chat uses the built-in explainer.
module.exports = (req, res) => send(res, 200, { ok: true, llm: false, model: null, hosted: true });
