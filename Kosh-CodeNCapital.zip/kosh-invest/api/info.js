const { send } = require("./_lib");
// Tells the client it's running on a hosted (serverless) deployment, where Live League rooms
// can't be kept in memory. League works when the presenter runs `node server.js`.
module.exports = (req, res) => send(res, 200, { hosted: true, lan: [] });
