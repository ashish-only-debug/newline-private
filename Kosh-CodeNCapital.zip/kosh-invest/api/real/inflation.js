const { send, getJson } = require("../_lib");
// Real World Bank data fetched earlier, bundled as a fallback because the World Bank API
// sometimes takes minutes to answer. Served with stale:true and its original fetch time.
const snapshot = require("../../data/inflation-snapshot.json");

module.exports = async (req, res) => {
  try {
    const j = await getJson("https://api.worldbank.org/v2/country/IN/indicator/FP.CPI.TOTL.ZG?format=json&per_page=40", 7000);
    const rows = (j[1] || []).filter((r) => r.value != null).map((r) => [+r.date, +r.value]).sort((a, b) => a[0] - b[0]);
    if (!rows.length) throw new Error("no rows");
    return send(res, 200, { rows, source: "World Bank indicator FP.CPI.TOTL.ZG (consumer price inflation, India)", fetched: Date.now() }, 24 * 3600);
  } catch (e) {
    console.error("inflation live fetch failed, serving bundled snapshot:", e.message);
    return send(res, 200, { ...snapshot, stale: true }, 3600);
  }
};
