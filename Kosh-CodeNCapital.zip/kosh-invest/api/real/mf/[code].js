const { send, getJson, DOWN } = require("../../_lib");

module.exports = async (req, res) => {
  const code = String((req.query && req.query.code) || "");
  if (!/^\d{3,7}$/.test(code)) return send(res, 400, { error: "Invalid scheme code." });
  try {
    const j = await getJson("https://api.mfapi.in/mf/" + code);
    if (!j || !j.meta || !j.meta.scheme_name || !Array.isArray(j.data) || !j.data.length) {
      return send(res, 404, { error: "No mutual fund was found with this scheme code. Search by name instead." }, 3600);
    }
    // newest-first dd-mm-yyyy -> oldest-first [yyyy-mm-dd, nav]
    const data = j.data.map((d) => { const [dd, mm, yy] = d.date.split("-"); return [`${yy}-${mm}-${dd}`, +d.nav]; }).filter((d) => d[1] > 0).reverse();
    return send(res, 200, { meta: j.meta, data, source: "AMFI via mfapi.in", fetched: Date.now() }, 3 * 3600);
  } catch (e) {
    console.error("mf scheme", code, e.message);
    return send(res, 502, DOWN);
  }
};
