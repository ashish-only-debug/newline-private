const { send, getJson, DOWN } = require("../../_lib");

module.exports = async (req, res) => {
  const term = String((req.query && req.query.q) || "").slice(0, 60).trim();
  if (term.length < 3) return send(res, 400, { error: "Type at least 3 characters." });
  try {
    const results = (await getJson("https://api.mfapi.in/mf/search?q=" + encodeURIComponent(term))).slice(0, 25);
    return send(res, 200, { results }, 6 * 3600);
  } catch (e) {
    console.error("mf search", e.message);
    return send(res, 502, DOWN);
  }
};
