const { send, decode, DOWN } = require("../_lib");

module.exports = async (req, res) => {
  const term = String((req.query && req.query.q) || "sensex OR nifty").slice(0, 80);
  try {
    const r = await fetch(`https://news.google.com/rss/search?q=${encodeURIComponent(term)}&hl=en-IN&gl=IN&ceid=IN:en`, { headers: { "User-Agent": "Mozilla/5.0 KoshEdu/1.0" }, signal: AbortSignal.timeout(9000) });
    if (!r.ok) throw new Error("upstream " + r.status);
    const xml = await r.text();
    const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0, 30).map(([, it]) => {
      const tag = (t) => (it.match(new RegExp(`<${t}[^>]*>([\\s\\S]*?)</${t}>`)) || [])[1];
      const source = decode(tag("source"));
      let title = decode(tag("title"));
      if (source && title.endsWith(" - " + source)) title = title.slice(0, -(source.length + 3));
      const link = decode(tag("link"));
      return { title, link: /^https:\/\//.test(link) ? link : null, source, published: Date.parse(decode(tag("pubDate"))) || null };
    }).filter((x) => x.title && x.link);
    return send(res, 200, { items, source: "Google News RSS", fetched: Date.now() }, 600);
  } catch (e) {
    console.error("news", e.message);
    return send(res, 502, DOWN);
  }
};
