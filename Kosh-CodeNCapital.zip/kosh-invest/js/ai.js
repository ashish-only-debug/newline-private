/*
 * Kosh AI layer.
 * 1) A local, explainable engine that turns the demo data into plain-language analysis.
 *    Every sentence is computed from numbers on screen — nothing is invented.
 * 2) An optional LLM path (server.js → /api/chat) used only when the server has an API key.
 *    The key never reaches the browser. If the server isn't available, the local engine answers.
 */
window.KOSH_AI = (() => {
  const M = window.KOSH_MARKET, D = window.KOSH_DATA, F = window.KF;

  const level = (v, lo, hi) => (v < lo ? "Low" : v < hi ? "Medium" : "High");
  const growthWord = (g) => (g == null ? "not measurable (it made losses in the base year)" : g > 0.2 ? "fast" : g > 0.1 ? "solid" : g > 0.05 ? "modest" : "slow");

  // ---------- Explainable risk analysis ----------
  function risk(sym) {
    const m = M.metrics(sym), c = M.bySym(sym).c, med = M.medianPE();
    const items = [];
    items.push({
      key: "Price volatility", level: level(m.vol, 0.22, 0.35), metric: "beta",
      value: F.pct(m.vol * 100, 1, false) + " a year",
      evidence: `Daily price moves over the past year annualise to ${F.pct(m.vol * 100, 1, false)}. ${m.vol >= 0.35 ? "Expect large swings — a 30%+ fall within a year would not be unusual." : m.vol >= 0.22 ? "Moderate swings, similar to a typical mid-sized stock." : "Calmer than most stocks in the demo universe."}`,
    });
    const peg = m.pe && m.profitCagr ? m.pe / (m.profitCagr * 100) : null;
    let vLevel = "Medium";
    if (m.pe == null) vLevel = "High";
    else if (m.pe > 45 || (peg && peg > 2.2)) vLevel = "High";
    else if (m.pe < med * 0.8 && (!peg || peg < 1.5)) vLevel = "Low";
    items.push({
      key: "Valuation", level: vLevel, metric: "pe",
      value: m.pe ? "P/E " + m.pe.toFixed(1) : "No P/E (loss)",
      evidence: m.pe
        ? `P/E of ${m.pe.toFixed(1)} vs demo-universe median ${med.toFixed(1)}.${peg ? ` Compared with its ${F.pct(m.profitCagr * 100, 0, false)} yearly profit growth, the PEG is ${peg.toFixed(2)} (around 1 = price in line with growth; above 2 = paying a lot for growth).` : " Profit growth can't be measured from a loss year, so PEG isn't meaningful."}`
        : "The company isn't profitable, so the price rests entirely on future expectations.",
    });
    if (c.lender) {
      items.push({ key: "Leverage", level: "Medium", metric: "npa", value: "Lender",
        evidence: `As a lender it borrows to lend (debt is ${F.num(m.deRaw, 1)}× equity), which is normal. The real risk is bad loans — check its NPA ratio and borrowing costs.` });
    } else {
      items.push({ key: "Debt load", level: level(m.de, 0.5, 1.2), metric: "de", value: "D/E " + m.de.toFixed(2),
        evidence: `It owes ${F.cr(c.debt)} against ${F.cr(c.equity)} of shareholder equity. ${m.de >= 1.2 ? "High debt means rising interest rates or a weak year can hurt quickly." : m.de >= 0.5 ? "Manageable, but keep an eye on interest costs." : "Very little debt — a cushion in tough times."}` });
    }
    const declines = c.profit.slice(1).filter((p, i) => p < c.profit[i]).length;
    const losses = c.profit.filter((p) => p <= 0).length;
    items.push({
      key: "Earnings consistency", level: losses ? "High" : declines >= 1 ? "Medium" : "Low", metric: "profit",
      value: losses ? `${losses} loss year${losses > 1 ? "s" : ""}` : declines ? `${declines} down year` : "Grew every year",
      evidence: `Profit over ${D.FY[0]}–${D.FY[4]}: ${c.profit.map((p) => F.cr(p)).join(" → ")}. ${losses ? "Loss years mean the profit track record is short." : declines ? "At least one year of falling profit shows the business is sensitive to costs or cycles." : "Profit rose every year — a consistent record."}`,
    });
    items.push({
      key: "Drawdown (1Y)", level: level(-m.mdd, 15, 30), metric: "hi52",
      value: F.pct(m.mdd, 1),
      evidence: `The worst peak-to-trough fall in the past year was ${F.pct(m.mdd, 1)}. That's how much an unlucky buyer at the top was down at the worst point.`,
    });
    if (m.profitGrowth != null && m.profitCagr != null) {
      const slow = m.profitGrowth < m.profitCagr / 2;
      items.push({
        key: "Growth momentum", level: m.profitGrowth < 0 ? "High" : slow ? "Medium" : "Low", metric: "cagr",
        value: "Latest " + F.pct(m.profitGrowth * 100, 0),
        evidence: `Last year's profit growth (${F.pct(m.profitGrowth * 100, 0)}) vs its 4-year average (${F.pct(m.profitCagr * 100, 0)} a year). ${m.profitGrowth < 0 ? "Profit shrank — check whether it's temporary." : slow ? "Growth is slowing versus its own history." : "Growth is holding up."}`,
      });
    }
    const pts = { Low: 20, Medium: 55, High: 85 };
    const score = Math.round(items.reduce((a, i) => a + pts[i.level], 0) / items.length);
    return { items, score, label: score < 40 ? "Lower risk" : score < 62 ? "Moderate risk" : "Higher risk" };
  }

  // ---------- AI stock explainer ----------
  function explain(sym, mode = "beginner") {
    const s = M.bySym(sym), c = s.c, m = M.metrics(sym), med = M.medianPE();
    const nifty = M.indexSeries(M.indexDefs[0], "1Y");
    const niftyRet = (nifty.at(-1).p / nifty[0].p - 1) * 100;
    const rk = risk(sym);
    const paras = [];
    if (mode === "beginner") {
      paras.push(`<strong>What it does:</strong> ${c.about} ${c.model}`);
      paras.push(`<strong>How the share has done:</strong> over the past year the price ${m.ret1Y >= 0 ? "rose" : "fell"} ${F.pct(Math.abs(m.ret1Y), 1, false)}, ${m.ret1Y > niftyRet ? "beating" : "trailing"} the simulated NIFTY 50 (${F.pct(niftyRet, 1)}). Today it's ${m.chgPct >= 0 ? "up" : "down"} ${F.pct(Math.abs(m.chgPct), 2, false)}.`);
      paras.push(`<strong>Is the business growing?</strong> Sales went from ${F.cr(c.revenue[0])} to ${F.cr(c.revenue[4])} in four years — about ${m.revCagr ? F.pct(m.revCagr * 100, 0, false) : "—"} a year, which is ${growthWord(m.revCagr)}. ${c.profit[0] > 0 ? `Profit grew from ${F.cr(c.profit[0])} to ${F.cr(c.profit[4])}.` : `It made a loss of ${F.cr(Math.abs(c.profit[0]))} in ${D.FY[0]} and a profit of ${F.cr(c.profit[4])} in ${D.FY[4]}.`} It keeps about ₹${m.margin.toFixed(0)} of every ₹100 of sales as profit.`);
      paras.push(m.pe
        ? `<strong>Is it expensive?</strong> Investors pay ₹${m.pe.toFixed(0)} for every ₹1 of yearly profit (P/E ${m.pe.toFixed(1)}). The middle stock in our demo list costs ₹${med.toFixed(0)}, so this one is ${m.pe > med * 1.2 ? "pricier — the market expects strong growth" : m.pe < med * 0.8 ? "cheaper — either a bargain or the market expects slower growth" : "around average"}.`
        : `<strong>Is it expensive?</strong> It has no meaningful profit yet, so the P/E can't be used. The price is a bet on future profits.`);
      paras.push(`<strong>Overall risk:</strong> ${rk.label.toLowerCase()} (${rk.score}/100). The biggest flag: ${rk.items.slice().sort((a, b) => ({ High: 3, Medium: 2, Low: 1 }[b.level] - { High: 3, Medium: 2, Low: 1 }[a.level]))[0].evidence}`);
    } else {
      const peg = m.pe && m.profitCagr ? m.pe / (m.profitCagr * 100) : null;
      paras.push(`<strong>Business:</strong> ${c.model}`);
      paras.push(`<strong>Growth & quality:</strong> revenue CAGR ${m.revCagr ? F.pct(m.revCagr * 100, 1, false) : "—"} (FY26 ${F.pct(m.revGrowth * 100, 1)}), profit CAGR ${m.profitCagr ? F.pct(m.profitCagr * 100, 1, false) : "n/m (base-year loss)"}. Net margin ${m.margin.toFixed(1)}%, ROE ${m.roe.toFixed(1)}%. ${c.lender ? `Balance sheet leverage ${m.deRaw.toFixed(1)}× is structural for a lender — focus on asset quality.` : `D/E ${m.de.toFixed(2)}.`}`);
      paras.push(`<strong>Valuation:</strong> ${m.pe ? `P/E ${m.pe.toFixed(1)} vs universe median ${med.toFixed(1)}${peg ? `; PEG ${peg.toFixed(2)}` : ""}.` : "P/E not meaningful."} Market cap ${F.cr(m.mcap)} (${m.capClass}), dividend yield ${m.divYield.toFixed(2)}%.`);
      paras.push(`<strong>Price behaviour:</strong> 1Y return ${F.pct(m.ret1Y, 1)} vs simulated NIFTY ${F.pct(niftyRet, 1)}; realised vol ${F.pct(m.vol * 100, 1, false)}; max drawdown ${F.pct(m.mdd, 1)}; trading ${(((m.price - m.lo52) / (m.hi52 - m.lo52)) * 100).toFixed(0)}% of the way up its 52-week range.`);
      paras.push(`<strong>Risk composite:</strong> ${rk.score}/100 — ${rk.items.map((i) => `${i.key} ${i.level.toLowerCase()}`).join(", ")}.`);
    }
    return paras;
  }

  // ---------- comparison ----------
  function compare(syms) {
    const rows = syms.map((s) => ({ s, c: M.bySym(s).c, m: M.metrics(s), r: risk(s) }));
    const best = (fn, hi = true) => rows.filter((r) => fn(r) != null).sort((a, b) => (hi ? fn(b) - fn(a) : fn(a) - fn(b)))[0];
    const out = [];
    const g = best((r) => r.m.revCagr);
    out.push(`<strong>${g.c.name}</strong> is growing sales fastest (${F.pct(g.m.revCagr * 100, 0, false)} a year).`);
    const mg = best((r) => r.m.margin);
    out.push(`<strong>${mg.c.name}</strong> keeps the most profit from each ₹100 of sales (₹${mg.m.margin.toFixed(0)}).`);
    const pe = best((r) => r.m.pe, false);
    if (pe) out.push(`<strong>${pe.c.name}</strong> is cheapest on P/E (${pe.m.pe.toFixed(1)}) — check whether that's because growth is slower.`);
    const lv = best((r) => (r.c.lender ? null : r.m.de), false);
    if (lv) out.push(`<strong>${lv.c.name}</strong> carries the least debt (D/E ${lv.m.de.toFixed(2)}).`);
    const v = best((r) => r.m.vol, false);
    out.push(`<strong>${v.c.name}</strong> has the calmest price (volatility ${F.pct(v.m.vol * 100, 0, false)}).`);
    const rt = best((r) => r.m.ret1Y);
    out.push(`<strong>${rt.c.name}</strong> returned the most over 1 year (${F.pct(rt.m.ret1Y, 1)}). Past returns don't predict future ones.`);
    const lr = best((r) => r.r.score, false);
    out.push(`On Kosh's explainable risk score, <strong>${lr.c.name}</strong> is lowest (${lr.r.score}/100).`);
    if (new Set(rows.map((r) => r.c.sector)).size > 1) out.push(`These companies are in different sectors (${rows.map((r) => r.c.sector).join(", ")}), so they react to different events — owning them together adds diversification.`);
    return out;
  }

  // ---------- chart explanation ----------
  function chartStory(sym, tf, data, idx = false) {
    if (!data || data.length < 2) return "";
    const a = data[0].p, b = data.at(-1).p;
    const chg = (b / a - 1) * 100;
    let hi = data[0], lo = data[0], big = null;
    for (let i = 1; i < data.length; i++) {
      if (data[i].p > hi.p) hi = data[i];
      if (data[i].p < lo.p) lo = data[i];
      const mv = data[i].p / data[i - 1].p - 1;
      if (!big || Math.abs(mv) > Math.abs(big.mv)) big = { mv, d: data[i] };
    }
    const fmtT = (t) => (tf === "1D" ? F.time(t) : tf === "1W" ? F.date(t, { weekday: "short", hour: "2-digit", minute: "2-digit" }) : F.date(t));
    const name = idx ? sym : M.bySym(sym).c.name;
    let txt = `<strong>${name}</strong> ${chg >= 0 ? "rose" : "fell"} <strong class="${F.cls(chg)}">${F.pct(chg)}</strong> over this ${tf === "ALL" ? "5-year" : tf} window (${F.inr(a)} → ${F.inr(b)}). `;
    txt += `It peaked at ${F.inr(hi.p)} (${fmtT(hi.t)}) and bottomed at ${F.inr(lo.p)} (${fmtT(lo.t)}). `;
    if (big) txt += `The largest single ${tf === "1D" ? "5-minute" : tf === "1W" ? "step" : "day"} move was ${F.pct(big.mv * 100)} on ${fmtT(big.d.t)}. `;
    const vs = data.filter((d) => d.v);
    if (!idx && vs.length > 5) {
      const avg = vs.reduce((s, d) => s + d.v, 0) / vs.length;
      const peak = vs.reduce((m, d) => (d.v > m.v ? d : m), vs[0]);
      if (peak.v > avg * 1.8) txt += `Volume spiked to ${(peak.v / avg).toFixed(1)}× average on ${fmtT(peak.t)} — moves on heavy volume usually carry more conviction. `;
      const half = Math.floor(vs.length / 2);
      const upVol = vs.slice(half).reduce((s, d) => s + d.v, 0) / (vs.length - half);
      const dnVol = vs.slice(0, half).reduce((s, d) => s + d.v, 0) / half;
      if (upVol > dnVol * 1.25) txt += `Trading activity picked up in the second half of the period. `;
    }
    const range = ((hi.p - lo.p) / lo.p) * 100;
    txt += range > 25 ? "The wide range shows high volatility in this period." : range < 6 ? "A narrow range — the price was fairly stable." : "";
    return txt;
  }

  // ---------- news impact analyzer ----------
  function newsImpact(n) {
    const affected = n.syms.map((s) => {
      const m = M.metrics(s), c = M.bySym(s).c;
      let exposure = "";
      if (n.id === "n2") exposure = c.lender ? `Lender — borrowing costs move with rates (balance-sheet leverage ${m.deRaw.toFixed(1)}×).` : `D/E ${m.de.toFixed(2)} — ${m.de > 1.2 ? "high sensitivity to interest costs" : "moderate sensitivity"}.`;
      else exposure = `Revenue ${F.cr(m.revenue)}, P/E ${m.pe ? m.pe.toFixed(1) : "n/m"}, volatility ${F.pct(m.vol * 100, 0, false)}.`;
      return { s, name: c.name, exposure, chgPct: m.chgPct };
    });
    const tone = { pos: "Likely positive", neg: "Likely negative", neutral: "Mixed" }[n.sent];
    return { tone, affected };
  }

  // ---------- chat (local engine) ----------
  const aliases = {
    pe: ["p/e", "pe ratio", "price to earnings", "price-to-earnings", " pe "], eps: ["eps", "earnings per share"],
    mcap: ["market cap", "market capitalisation", "market capitalization", "mcap"], revenue: ["revenue", "sales"],
    margin: ["margin"], de: ["debt to equity", "debt-to-equity", "d/e", "leverage"], roe: ["roe", "return on equity"],
    divy: ["dividend"], beta: ["volatility", "volatile"], hi52: ["52-week", "52 week"], cagr: ["cagr", "compound annual"],
    volume: ["volume"], sip: ["sip", "systematic investment"], mf: ["mutual fund"], diversification: ["diversif"],
    npa: ["npa", "bad loan", "non-performing"], bullbear: ["bullish", "bearish", "bull ", "bear "],
    repo: ["repo rate", "repo"], inflation: ["inflation", " cpi "], ipo: [" ipo", "initial public offering"], fii: [" fii", " fpi", "foreign investor", "foreign institutional"],
    index: ["sensex", "nifty 50", "what is nifty", "index fund"], gdp: [" gdp"], sebi: ["sebi"], cgt: ["capital gain", "ltcg", "stcg"],
  };
  function findSyms(q) {
    const ql = " " + q.toLowerCase() + " ";
    return M.companies.filter((c) => ql.includes(" " + c.sym.toLowerCase()) || ql.includes(c.name.toLowerCase()) || ql.includes(c.name.split(" ")[0].toLowerCase())).map((c) => c.sym);
  }
  function findTerm(q) {
    const ql = " " + q.toLowerCase() + " ";
    for (const [k, list] of Object.entries(aliases)) if (list.some((a) => ql.includes(a))) return k;
    return null;
  }
  const gl = (k) => D.glossary[k];
  const termAnswer = (k, mode) => {
    const g = gl(k);
    return `<p><strong>${g.term}</strong> — ${g.what}</p><p><strong>Why it matters:</strong> ${g.why}</p><p><strong>How to read it:</strong> ${g.read}</p><p><strong>Example:</strong> ${g.ex}</p>${mode === "advanced" ? `<p><strong>Going deeper:</strong> ${g.adv}</p>` : ""}`;
  };

  function localAnswer(q, ctx) {
    const ql = q.toLowerCase();
    const syms = findSyms(q);
    const sym = syms[0] || ctx.sym;
    const mode = ctx.mode || "beginner";
    const sources = [];

    if (/^(hi|hello|hey|namaste)\b/.test(ql)) return { html: `<p>Hi! I can explain any stock in the demo universe, compare companies, define financial terms, summarise demo news or review your simulated portfolio. Try one of the suggestions below.</p>` };

    if (/(should i|buy|sell|invest in|good investment|recommend|target price)/.test(ql) && !/mutual fund/.test(ql)) {
      const s = sym ? M.bySym(sym).c : null;
      return { html: `<p>I can't tell you whether to buy or sell — Kosh is a learning tool, not a licensed advisor, and all data here is simulated.</p>${s ? `<p>What I <em>can</em> do is lay out the evidence for <strong>${s.name}</strong>:</p><p><strong>Bull case:</strong></p><ul>${s.bull.map((x) => `<li>${x}</li>`).join("")}</ul><p><strong>Bear case:</strong></p><ul>${s.bear.map((x) => `<li>${x}</li>`).join("")}</ul><p><strong>Research before deciding:</strong></p><ul>${s.research.map((x) => `<li>${x}</li>`).join("")}</ul>` : "<p>Pick a stock and ask me about its risks, valuation or growth.</p>"}<p>Also consider your time horizon, how much you can afford to lose, and diversification.</p>` };
    }

    if (/(stock|share)s?\b.*\b(vs|versus|or|and|difference)\b.*mutual fund|mutual fund.*\b(vs|versus|or|difference)\b.*(stock|share)/.test(ql)) {
      return { html: `<p><strong>Stocks vs mutual funds</strong></p><ul><li><strong>Stock:</strong> you own one company directly. Higher potential upside, but one bad result can hit you hard. You do the research.</li><li><strong>Mutual fund:</strong> your money is pooled with others and spread across dozens of companies by a manager or an index rule. Built-in diversification, small yearly fee (expense ratio).</li></ul><p><strong>Example:</strong> ₹10,000 in one stock that falls 40% → ₹6,000. The same in a 50-stock fund where that stock is 2% → the fall costs you ~₹80.</p><p>Many beginners start with an index fund SIP, then add individual stocks as they learn. Try the SIP calculator in the Learning Centre.</p>` };
    }

    if (syms.length >= 2 || (/compare|vs\b|versus/.test(ql) && syms.length >= 1 && ctx.sym && syms[0] !== ctx.sym)) {
      const list = [...new Set(syms.length >= 2 ? syms : [ctx.sym, syms[0]])].slice(0, 3);
      return { html: `<p><strong>Comparing ${list.map((s) => M.bySym(s).c.name).join(" vs ")}</strong></p><ul>${compare(list).map((x) => `<li>${x}</li>`).join("")}</ul><p>Open <a href="#/compare/${list.join(",")}">Compare</a> for side-by-side charts.</p>`, sources: ["Demo financials", "Simulated prices"] };
    }

    if (/(why|reason).*(up|down|rise|rising|fall|falling|drop|dropping|move|moving|jump|crash)/.test(ql) || /(going|gone) (up|down)/.test(ql)) {
      if (!sym) return { html: "<p>Which stock? Open a stock page or name it, e.g. “Why is VYOM going up?”</p>" };
      const s = M.bySym(sym), m = M.metrics(sym), c = s.c;
      const rel = D.news.filter((n) => n.syms.includes(sym));
      const idx = M.indices()[0];
      const volRatio = m.dayVol / m.avgVol;
      let h = `<p><strong>${c.name}</strong> is ${m.chgPct >= 0 ? "up" : "down"} <span class="${F.cls(m.chgPct)}">${F.pct(m.chgPct)}</span> today and ${F.pct(m.ret1M)} over the past month. The simulated NIFTY is ${F.pct(idx.chgPct)} today${Math.sign(idx.chgPct) === Math.sign(m.chgPct) ? ", so part of the move is the overall market" : ", so this move is against the market — more likely stock-specific"}.</p>`;
      if (rel.length) h += `<p><strong>Related demo news:</strong></p><ul>${rel.map((n) => `<li>${n.h} — <em>${n.sent === "pos" ? "generally positive" : n.sent === "neg" ? "generally negative" : "mixed"}</em></li>`).join("")}</ul>`;
      h += `<p>Today's volume so far is ${volRatio.toFixed(1)}× the 20-day daily average${volRatio > 1.5 ? " — heavy trading suggests conviction behind the move" : ""}.</p>`;
      h += `<p class="note">Honest caveat: prices in Kosh are simulated, so moves aren't caused by real events. In real markets, look for company news, sector trends, market-wide moves and volume — exactly the checks above.</p>`;
      return { html: h, sources: ["Simulated prices", "Demo news scenarios"] };
    }

    if (/risk/.test(ql)) {
      if (!sym) return { html: termAnswer("diversification", mode) + "<p>Name a stock to see its explainable risk breakdown.</p>" };
      const r = risk(sym), c = M.bySym(sym).c;
      return { html: `<p><strong>${c.name}: ${r.label} (${r.score}/100)</strong></p><ul>${r.items.map((i) => `<li><strong>${i.key} — ${i.level}:</strong> ${i.evidence}</li>`).join("")}</ul><p><strong>Business risks:</strong></p><ul>${c.risks.map((x) => `<li>${x}</li>`).join("")}</ul>`, sources: ["Demo financials", "1Y simulated prices"] };
    }

    if (/(financial|performance|results|earnings|revenue|profit|explain|tell me about|overview|summar|what does .* do)/.test(ql) && sym) {
      const term = findTerm(q);
      if (term && !/(company|stock|its|this)/.test(ql)) return { html: termAnswer(term, mode) };
      return { html: explain(sym, mode).map((p) => `<p>${p}</p>`).join(""), sources: ["Demo financials FY22–FY26", "Simulated prices"] };
    }

    const term = findTerm(q);
    if (term || /what (is|does|are)|meaning|define/.test(ql)) {
      if (term) {
        let extra = "";
        const m = sym ? M.metrics(sym) : null;
        if (m && term === "pe" && m.pe) extra = `<p><strong>For ${M.bySym(sym).c.name}:</strong> P/E is ${m.pe.toFixed(1)} vs a demo median of ${M.medianPE().toFixed(1)}.</p>`;
        if (m && term === "de" && m.de != null) extra = `<p><strong>For ${M.bySym(sym).c.name}:</strong> D/E is ${m.de.toFixed(2)}.</p>`;
        if (m && term === "eps") extra = `<p><strong>For ${M.bySym(sym).c.name}:</strong> EPS is ${F.inr(m.eps)}.</p>`;
        return { html: termAnswer(term, mode) + extra };
      }
    }

    if (/portfolio|holdings|my (stocks|investments)|how am i doing/.test(ql) && ctx.portfolio) {
      const p = ctx.portfolio;
      if (!p.holdings.length) return { html: `<p>Your simulated portfolio is all cash (${F.inr(p.cash)} virtual). Open any stock and use <strong>Buy (demo)</strong> to start experimenting.</p>` };
      const top = p.holdings.slice().sort((a, b) => b.value - a.value)[0];
      const share = (top.value / p.invested) * 100;
      return { html: `<p>Your simulated portfolio is worth <strong>${F.inr(p.total)}</strong> (${F.signed(p.pnl)}, ${F.pct(p.pnlPct)} on invested money).</p><ul><li>${p.holdings.length} holdings across ${new Set(p.holdings.map((h) => M.bySym(h.sym).c.sector)).size} sectors.</li><li>Largest position: ${M.bySym(top.sym).c.name} at ${share.toFixed(0)}% of invested value${share > 35 ? " — that's concentrated; consider spreading risk" : ""}.</li><li>Cash available: ${F.inr(p.cash)}.</li></ul>` };
    }

    if (/news/.test(ql)) {
      const rel = sym ? D.news.filter((n) => n.syms.includes(sym)) : D.news.slice(0, 4);
      return { html: `<p>${sym ? `Demo news linked to ${M.bySym(sym).c.name}` : "Latest demo scenarios"}:</p><ul>${rel.map((n) => `<li><a href="#/news/${n.id}">${n.h}</a></li>`).join("") || "<li>None yet.</li>"}</ul><p class="note">These are fictional teaching scenarios, not real news.</p>` };
    }

    if (syms.length) return { html: explain(syms[0], mode).slice(0, 3).map((p) => `<p>${p}</p>`).join("") + `<p>Ask me about its risks, valuation, or to compare it with another company.</p>` };

    return { html: `<p>I'm not sure about that one yet. I'm best at:</p><ul><li>Explaining a stock (“Explain Aurveda Power simply”)</li><li>Terms (“What is P/E ratio?”)</li><li>Risks (“What are the risks of SETU?”)</li><li>Comparisons (“Compare NIMB vs KSHT”)</li><li>Your simulated portfolio</li></ul>` };
  }

  // ---------- optional LLM via server proxy ----------
  let llm = { checked: false, available: false, model: null };
  async function checkLLM() {
    if (llm.checked) return llm;
    llm.checked = true;
    try {
      const r = await fetch("/api/health", { cache: "no-store" });
      if (r.ok) { const j = await r.json(); llm.available = !!j.llm; llm.model = j.model || null; }
    } catch { /* static hosting: local engine only */ }
    return llm;
  }
  function contextFor(sym) {
    if (!sym) return null;
    const c = M.bySym(sym).c, m = M.metrics(sym), r = risk(sym);
    return {
      company: { sym: c.sym, name: c.name, sector: c.sector, about: c.about, model: c.model, strengths: c.strengths, risks: c.risks, bull: c.bull, bear: c.bear },
      financials: { years: D.FY, revenue_cr: c.revenue, profit_cr: c.profit, equity_cr: c.equity, debt_cr: c.debt, lender: !!c.lender },
      metrics: { price: +m.price.toFixed(2), day_change_pct: +m.chgPct.toFixed(2), pe: m.pe && +m.pe.toFixed(1), eps: +m.eps.toFixed(2), mcap_cr: Math.round(m.mcap), margin_pct: +m.margin.toFixed(1), roe_pct: +m.roe.toFixed(1), de: m.de && +m.de.toFixed(2), vol_pct: +(m.vol * 100).toFixed(1), ret_1y_pct: +m.ret1Y.toFixed(1), universe_median_pe: +M.medianPE().toFixed(1) },
      risk: { score: r.score, items: r.items.map((i) => ({ factor: i.key, level: i.level, evidence: i.evidence.replace(/<[^>]+>/g, "") })) },
      demo_news: D.news.filter((n) => n.syms.includes(sym)).map((n) => ({ headline: n.h, why: n.why })),
    };
  }
  async function ask(q, ctx) {
    const st = await checkLLM();
    if (st.available) {
      try {
        const syms = findSyms(q);
        const body = { question: q, mode: ctx.mode, history: (ctx.history || []).slice(-6), stocks: [...new Set([...(syms.length ? syms : []), ctx.sym].filter(Boolean))].slice(0, 3).map(contextFor) };
        const r = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        if (r.ok) {
          const j = await r.json();
          if (j.answer) return { html: mdToHtml(j.answer), engine: `LLM (${st.model || "server"}) grounded in Kosh demo data`, sources: ["Demo data sent as context"] };
        }
      } catch (e) { console.warn("LLM failed, using local engine", e); }
    }
    const a = localAnswer(q, ctx);
    return { ...a, engine: "Kosh local explainer (rule-based, runs in your browser)" };
  }
  function mdToHtml(md) {
    const esc = F.esc(md);
    const lines = esc.split(/\n/);
    let html = "", inList = false;
    for (let l of lines) {
      l = l.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\*(.+?)\*/g, "<em>$1</em>");
      if (/^\s*[-*•]\s+/.test(l)) { if (!inList) { html += "<ul>"; inList = true; } html += `<li>${l.replace(/^\s*[-*•]\s+/, "")}</li>`; }
      else { if (inList) { html += "</ul>"; inList = false; } if (l.trim()) html += `<p>${l}</p>`; }
    }
    if (inList) html += "</ul>";
    return html;
  }

  return { risk, explain, compare, chartStory, newsImpact, ask, checkLLM, findSyms, llm: () => llm };
})();
