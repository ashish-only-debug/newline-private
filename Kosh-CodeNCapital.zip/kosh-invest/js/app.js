/* Kosh app: routing, state, screens, simulator, alerts and the assistant UI. */
(() => {
  const M = window.KOSH_MARKET, D = window.KOSH_DATA, AI = window.KOSH_AI, C = window.KC, F = window.KF;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = F.esc;

  /* ---------------- icons ---------------- */
  const P = {
    home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    markets: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
    compare: '<path d="M8 3v18M16 3v18"/><path d="M3 8h5M16 16h5"/>',
    news: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h10M7 12h10M7 16h6"/>',
    learn: '<path d="M2 7l10-4 10 4-10 4z"/><path d="M6 9v6c3 2 9 2 12 0V9"/>',
    wallet: '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M16 13h2M3 10h18"/>',
    star: '<path d="M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/>',
    bell: '<path d="M6 8a6 6 0 1112 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 20a2 2 0 004 0"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    moon: '<path d="M20 14.5A8 8 0 019.5 4a8 8 0 1010.5 10.5z"/>',
    auto: '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 000 18z" fill="currentColor"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    send: '<path d="M4 12l16-8-6 16-2-7z"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
    up: '<path d="M12 19V5M5 12l7-7 7 7"/>', down: '<path d="M12 5v14M5 12l7 7 7-7"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    zap: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/><path d="M3 4v4h4"/>',
    pie: '<path d="M21 12A9 9 0 1112 3v9z"/><path d="M15 3.5A9 9 0 0120.5 9H15z"/>',
    rss: '<path d="M4 11a9 9 0 019 9M4 4a16 16 0 0116 16"/><circle cx="5" cy="19" r="1"/>',
    more: '<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="1"/><rect x="13" y="3" width="8" height="6" rx="1"/><rect x="13" y="11" width="8" height="10" rx="1"/><rect x="3" y="15" width="8" height="6" rx="1"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5"/><path d="M16 4.5a3.5 3.5 0 010 7M18 14.8c2 .7 3.2 2.5 3.5 5.2"/>',
  };
  const ic = (n, extra = "") => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${P[n]}</svg>`;

  /* ---------------- persistent state ---------------- */
  const KEY = "kosh.v1";
  const store = {
    get() { try { return JSON.parse(localStorage.getItem(KEY)) || null; } catch { return null; } },
    set(v) { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch { /* private mode */ } },
  };
  const WIDGETS = [
    ["dna", "Crash Test · your Investor DNA"],
    ["journey", "My progress & smart tools"],
    ["brief", "AI daily brief"], ["indices", "Market overview (NIFTY 50 & SENSEX)"], ["movers", "Top gainers & losers"],
    ["portfolio", "Portfolio performance"], ["watchlist", "Watchlist"], ["trending", "Trending (unusual volume)"],
    ["recent", "Recently viewed"], ["updates", "Market updates"], ["learn", "Continue learning"],
  ];
  function fresh() {
    const px = (s) => M.bySym(s).c.price;
    const h = { NIMB: { qty: 10, avg: +(px("NIMB") * 0.93).toFixed(2) }, KSHT: { qty: 25, avg: +(px("KSHT") * 0.97).toFixed(2) }, AURV: { qty: 40, avg: +(px("AURV") * 1.04).toFixed(2) } };
    const cost = Object.values(h).reduce((a, x) => a + x.qty * x.avg, 0);
    return {
      v: 1, mode: "beginner", theme: "dark",
      watchlist: ["VYOM", "SETU", "TRNG", "MEDH"], recent: [],
      portfolio: {
        start: 1000000, cash: +(1000000 - cost).toFixed(2), holdings: h,
        txns: Object.entries(h).map(([sym, x]) => ({ id: uid(), t: Date.now(), sym, side: "BUY", qty: x.qty, price: x.avg, note: "Starter position" })),
      },
      alerts: [
        { id: uid(), type: "pct", sym: "VYOM", value: 1.5, active: true, created: Date.now() },
        { id: uid(), type: "news", sym: "SETU", active: true, created: Date.now() },
      ],
      notifs: [{ id: uid(), t: Date.now(), title: "Welcome to Kosh", body: "Everything here uses fictional companies and simulated prices. Explore freely — no real money is involved.", read: false, kind: "info" }],
      dash: { order: WIDGETS.map((w) => w[0]), hidden: [] },
      lessons: {}, quiz: {}, research: {}, badges: {}, profile: null, goal: null,
    };
  }
  function uid() { return Math.random().toString(36).slice(2, 10); }
  let S = store.get();
  if (!S || S.v !== 1) S = fresh();
  S.badges = S.badges || {};
  WIDGETS.forEach(([k], i) => { if (!S.dash.order.includes(k)) S.dash.order.splice(Math.min(i, S.dash.order.length), 0, k); });
  const save = () => store.set(S);
  let pendingTerm = null;

  /* ---------------- theme & mode ---------------- */
  if (S.themeV !== 2) { S.theme = "system"; S.themeV = 2; }
  const THEMES = { system: ["Auto", "auto"], light: ["Light", "sun"], dark: ["Dark", "moon"] };
  function applyTheme() {
    if (!THEMES[S.theme]) S.theme = "system";
    if (S.theme === "system") document.documentElement.removeAttribute("data-theme");
    else document.documentElement.setAttribute("data-theme", S.theme);
    document.querySelectorAll("[data-theme-set]").forEach((x) => x.setAttribute("aria-pressed", String(x.dataset.themeSet === S.theme)));
    const b = document.getElementById("theme-btn");
    if (b) {
      const next = { system: "light", light: "dark", dark: "system" }[S.theme];
      b.innerHTML = ic(THEMES[S.theme][1]);
      b.setAttribute("aria-label", `Appearance: ${THEMES[S.theme][0]}${S.theme === "system" ? " (follows your device)" : ""}. Switch to ${THEMES[next][0]}`);
      b.title = b.getAttribute("aria-label");
    }
  }
  applyTheme();

  /* ---------------- shell ---------------- */
  const NAV = [
    [null, null, null, ""], ["#/", "Dashboard", "home"], ["#/journey", "My Plan", "target"],
    [null, "Train", null], ["#/crash", "Crash Test", "zap"], ["#/league", "Live League", "users"], ["#/tipcheck", "Tip Check", "shield"], ["#/timemachine", "Time Machine", "clock"],
    [null, "Explore", null], ["#/markets", "Markets", "markets"], ["#/funds", "Mutual Funds", "pie"], ["#/compare", "Compare", "compare"], ["#/headlines", "Live Headlines", "rss"], ["#/news", "News Scenarios", "news"], ["#/learn", "Learning Centre", "learn"],
    [null, "Practice", null], ["#/portfolio", "Simulator", "wallet"], ["#/watchlist", "Watchlist", "star"], ["#/alerts", "Alerts", "bell"],
  ];
  document.getElementById("app").innerHTML = `
    <div class="app">
      <aside class="sidebar" id="sidebar" aria-label="Main navigation">
        <div class="brand"><div class="brand-mark">K</div><div><div class="brand-name">Kosh</div><div class="brand-sub">AI investing coach</div></div></div>
        <nav>${NAV.map(([h, l, i]) => (h ? `<a class="nav-link" href="${h}" data-nav="${h}">${ic(i)}<span>${l}</span></a>` : l ? `<div class="nav-group">${l}</div>` : "")).join("")}</nav>
        <div class="side-settings"><div class="nav-group">Explanations</div><div class="seg" role="group" aria-label="Explanation level" style="width:100%"><button data-mode="beginner" style="flex:1">Beginner</button><button data-mode="advanced" style="flex:1">Advanced</button></div>
          <div class="nav-group">Appearance</div><div class="seg" role="group" aria-label="Appearance" style="width:100%">${[["system", "Auto"], ["light", "Light"], ["dark", "Dark"]].map(([v, l]) => `<button data-theme-set="${v}" style="flex:1">${l}</button>`).join("")}</div></div>
        <div class="sidebar-foot"><strong>About the data</strong>Stocks, prices &amp; news scenarios are simulated. Mutual funds, headlines &amp; inflation are live public data. No real trading.</div>
      </aside>
      <div class="main">
        <header class="topbar">
          <button class="icon-btn menu-btn" id="menu-btn" aria-label="Open menu">${ic("menu")}</button>
          <div class="search" role="combobox" aria-expanded="false" aria-haspopup="listbox" aria-owns="suggest">
            ${ic("search")}
            <input id="q" type="search" placeholder="Search stocks, sectors or terms (e.g. P/E)…" autocomplete="off" aria-label="Search" aria-controls="suggest" />
            <div class="suggest" id="suggest" role="listbox"></div>
          </div>
          <div class="top-actions">
            <span class="data-pill" title="All prices are simulated. Nothing on this site is live market data."><span class="dot pulse"></span><span class="lbl">Demo data · </span><span id="tick-time">${F.time(new Date())}</span></span>
            <div class="seg hide-sm" role="group" aria-label="Explanation level"><button data-mode="beginner">Beginner</button><button data-mode="advanced">Advanced</button></div>
            <button class="icon-btn" id="theme-btn" aria-label="Toggle light/dark theme">${ic("sun")}</button>
            <div style="position:relative">
              <button class="icon-btn" id="bell" aria-label="Notifications" aria-expanded="false">${ic("bell")}<span class="badge" id="badge" hidden></span></button>
              <div class="notif-panel" id="notif-panel" hidden></div>
            </div>
          </div>
        </header>
        <main class="content" id="content" tabindex="-1"></main>
        <nav class="bottom-nav" aria-label="Quick navigation">${[["#/", "Home", "home"], ["#/markets", "Markets", "markets"], ["#/crash", "Crash", "zap"], ["#/funds", "Funds", "pie"]].map(([h, l, i]) => `<a href="${h}" data-bnav="${h}">${ic(i)}<span>${l}</span></a>`).join("")}<button id="bnav-more" aria-label="More pages">${ic("more")}<span>More</span></button></nav>
      </div>
    </div>
    <button class="chat-fab" id="chat-fab" aria-label="Open AI assistant">${ic("spark")}<span class="lbl">Ask Kosh AI</span></button>
    <section class="chat" id="chat" hidden aria-label="AI assistant">
      <div class="chat-head"><div class="brand-mark" style="width:30px;height:30px;font-size:14px">K</div><div style="flex:1"><strong>Kosh AI</strong><div class="note" id="chat-engine">Checking engine…</div></div><button class="icon-btn" id="chat-close" aria-label="Close assistant">${ic("x")}</button></div>
      <div class="chat-ctx" id="chat-ctx"></div>
      <div class="chat-body" id="chat-body" aria-live="polite"></div>
      <form class="chat-form" id="chat-form"><input class="input" id="chat-in" placeholder="Ask about a stock, a term, risks…" autocomplete="off" aria-label="Message" /><button class="btn primary" aria-label="Send">${ic("send")}</button></form>
    </section>
    <div class="toasts" id="toasts" aria-live="polite"></div>`;

  applyTheme();
  const content = $("#content");
  let page = { live: null, cleanup: null };

  function setModeButtons() { $$("[data-mode]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.mode === S.mode))); }
  setModeButtons();

  /* ---------------- toasts & notifications ---------------- */
  function toast(msg, kind = "") {
    const t = document.createElement("div");
    t.className = "toast " + kind; t.innerHTML = msg; t.title = "Click to dismiss";
    t.onclick = () => t.remove();
    const box = $("#toasts"); while (box.children.length >= 3) box.firstChild.remove();
    $("#toasts").appendChild(t);
    setTimeout(() => t.remove(), 5000);
  }
  function award(id) {
    if (S.badges[id]) return;
    const b = window.KOSH_EXTRA.BADGES.find((x) => x[0] === id); if (!b) return;
    const before = window.KOSH_EXTRA.level(S.badges);
    S.badges[id] = Date.now(); save();
    const after = window.KOSH_EXTRA.level(S.badges);
    toast(`🏅 <strong>Badge unlocked: ${esc(b[1])}</strong> · +100 XP${after.idx > before.idx ? `<br>Level up! You're now a <strong>${after.name}</strong>.` : ""}`, "up");
  }
  function notify(title, body, kind = "info", link = null) {
    S.notifs.unshift({ id: uid(), t: Date.now(), title, body, read: false, kind, link });
    S.notifs = S.notifs.slice(0, 50);
    save(); renderBadge();
    if (!/^#\/(crash|league)/.test(location.hash)) toast(`<strong>${esc(title)}</strong><br>${esc(body)}`, kind);
  }
  function renderBadge() {
    const n = S.notifs.filter((x) => !x.read).length;
    const b = $("#badge"); b.hidden = !n; b.textContent = n > 9 ? "9+" : n;
  }
  function renderNotifPanel() {
    const p = $("#notif-panel");
    p.innerHTML = `<div class="spread" style="padding:6px 8px 10px"><strong>Notifications</strong><div class="row"><button class="btn sm ghost" id="mark-read">Mark all read</button><a class="btn sm ghost" href="#/alerts">Manage</a></div></div>` +
      (S.notifs.length ? S.notifs.map((n) => `<div class="notif ${n.read ? "" : "unread"}" ${n.link ? `data-go="${n.link}" style="cursor:pointer"` : ""}><span class="dot" style="color:var(--${n.kind === "down" ? "down" : n.kind === "up" ? "up" : "accent-text"});margin-top:6px"></span><div><div class="t">${esc(n.title)}</div><div class="d">${esc(n.body)}</div><div class="note">${F.date(n.t, { day: "numeric", month: "short" })} ${F.time(n.t)}</div></div></div>`).join("") : `<div class="empty">No notifications yet.</div>`);
  }
  renderBadge();

  /* ---------------- popover for metric explanations ---------------- */
  let pop = null;
  function closePop() { if (pop) { pop.remove(); pop = null; } }
  function openPop(btn, key) {
    closePop();
    const g = D.glossary[key]; if (!g) return;
    pop = document.createElement("div");
    pop.className = "popover"; pop.setAttribute("role", "dialog"); pop.setAttribute("aria-label", g.term);
    pop.innerHTML = `<div class="spread"><h4>${esc(g.term)}</h4><button class="icon-btn" style="width:28px;height:28px" aria-label="Close">${ic("x")}</button></div>
      <dl><div><dt>What it means</dt><dd>${g.what}</dd></div><div><dt>Why it matters</dt><dd>${g.why}</dd></div><div><dt>How to read it</dt><dd>${g.read}</dd></div><div><dt>Example</dt><dd>${g.ex}</dd></div>${S.mode === "advanced" ? `<div><dt>Advanced</dt><dd>${g.adv}</dd></div>` : ""}</dl>
      <div class="row" style="margin-top:12px"><button class="btn sm" data-ask="Explain ${esc(g.term)} with an example">${ic("spark")} Ask AI</button><a class="btn sm ghost" href="#/learn/glossary">Glossary</a></div>`;
    document.body.appendChild(pop);
    const r = btn.getBoundingClientRect();
    const pw = pop.offsetWidth, ph = pop.offsetHeight;
    let left = Math.min(Math.max(16, r.left - pw / 2 + 9), innerWidth - pw - 16);
    let top = r.bottom + 8; if (top + ph > innerHeight - 10) top = Math.max(10, r.top - ph - 8);
    pop.style.left = left + "px"; pop.style.top = top + "px";
    pop.querySelector("button").focus();
  }
  const info = (key) => `<button class="info-btn" data-term="${key}" aria-label="What is ${esc(D.glossary[key]?.term || key)}?">i</button>`;

  /* ---------------- helpers ---------------- */
  const logo = (c, size = "") => `<span class="logo" style="background:${c.color};${size}">${c.sym.slice(0, 2)}</span>`;
  const isWatched = (s) => S.watchlist.includes(s);
  const starBtn = (s) => `<button class="star" data-watch="${s}" aria-pressed="${isWatched(s)}" aria-label="${isWatched(s) ? "Remove from" : "Add to"} watchlist">${ic("star")}</button>`;
  const priceCell = (s) => `<span class="num" data-p="${s}">${F.inr(M.bySym(s).price)}</span>`;
  const chgCell = (s) => { const m = M.metrics(s); return `<span class="change ${F.cls(m.chgPct)}" data-c="${s}">${F.pct(m.chgPct)}</span>`; };
  function seg(name, opts, cur) { return `<div class="seg" role="group" data-seg="${name}">${opts.map((o) => `<button data-v="${o}" aria-pressed="${o === cur}">${o}</button>`).join("")}</div>`; }
  function riskTag(sym) { const r = AI.risk(sym); return `<span class="tag ${r.score < 40 ? "up" : r.score < 62 ? "warn" : "down"}">${r.score}</span>`; }

  function portfolioState() {
    const p = S.portfolio;
    const holdings = Object.entries(p.holdings).filter(([, h]) => h.qty > 0).map(([sym, h]) => {
      const s = M.bySym(sym); const value = h.qty * s.price; const cost = h.qty * h.avg;
      return { sym, qty: h.qty, avg: h.avg, price: s.price, value, cost, pnl: value - cost, pnlPct: (value / cost - 1) * 100, day: h.qty * (s.price - s.prevClose) };
    });
    const invested = holdings.reduce((a, h) => a + h.value, 0);
    const cost = holdings.reduce((a, h) => a + h.cost, 0);
    const day = holdings.reduce((a, h) => a + h.day, 0);
    const total = invested + p.cash;
    return { holdings, invested, cost, cash: p.cash, total, pnl: invested - cost, pnlPct: cost ? (invested / cost - 1) * 100 : 0, day, dayPct: invested - day ? (day / (invested - day)) * 100 : 0, overall: (total / p.start - 1) * 100 };
  }

  /* ---------------- router ---------------- */
  function route() {
    closePop(); closeSidebar();
    if (page.cleanup) page.cleanup();
    page = { live: null, cleanup: null };
    const h = location.hash || "#/";
    const [, name = "", arg = ""] = h.match(/^#\/([^/]*)\/?(.*)$/) || [];
    $$("[data-nav]").forEach((a) => {
      const n = a.dataset.nav.replace("#/", "");
      a.classList.toggle("active", n === name || (n === "" && name === "") || (n === "markets" && name === "stock"));
      if (a.classList.contains("active")) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });
    const pages = { "": dashboard, markets, stock, compare, news, learn, portfolio, watchlist, alerts,
      crash: () => { page.cleanup = window.KOSH_CRASH.mountSolo(content, UI); },
      league: (a) => { page.cleanup = window.KOSH_CRASH.mountLeague(content, a, UI); },
      tipcheck: () => { page.cleanup = window.KOSH_EXTRA.tipcheck(content, UI); },
      timemachine: () => { page.cleanup = window.KOSH_EXTRA.timemachine(content, UI); },
      journey: () => { page.cleanup = window.KOSH_EXTRA.journey(content, UI); },
      funds: (a) => { page.cleanup = window.KOSH_REAL.funds(content, a, UI); },
      headlines: () => { page.cleanup = window.KOSH_REAL.headlines(content, UI); } };
    (pages[name] || notFound)(decodeURIComponent(arg));
    chatContext();
    $$("[data-bnav]").forEach((x) => { const n = x.dataset.bnav.replace("#/", ""); x.classList.toggle("active", n === name || (n === "markets" && name === "stock")); });
    const live = name === "funds" || name === "headlines";
    const pill = $(".data-pill"); pill.classList.toggle("live", live);
    pill.querySelector(".lbl").textContent = live ? "Live data · " : "Demo data · ";
    pill.title = live ? "This page uses real data from public sources." : "All prices on this page are simulated. Nothing is live market data.";
    content.classList.remove("enter"); void content.offsetWidth; content.classList.add("enter");
    window.scrollTo(0, 0);
  }
  function notFound() { content.innerHTML = `<div class="empty"><h2>Page not found</h2><p><a href="#/">Back to dashboard</a></p></div>`; }

  /* ============ DASHBOARD ============ */
  function dashboard() {
    const pf = portfolioState();
    const hour = new Date().getHours();
    content.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">Your dashboard</div><h1>Good ${hour < 12 ? "morning" : hour < 17 ? "afternoon" : "evening"} 👋</h1><p>A personalised view of the simulated market. Rearrange it any time.</p></div>
      <button class="btn" id="customize">${ic("settings")} Customize</button></div>
      <div class="stack" id="widgets" style="gap:16px"></div>
      <div class="footer-note">Kosh is an educational prototype. Companies, prices, financials and news are fictional; indices are simulated from the demo universe. Nothing here is investment advice, and no real trades or payments happen.</div>`;
    const order = S.dash.order.filter((k) => !S.dash.hidden.includes(k));
    const host = $("#widgets");
    const W = {
      dna: () => {
        let last = null; try { last = JSON.parse(localStorage.getItem("kosh.crash")); } catch {}
        return `<section class="hero" style="margin:0"><div class="spread" style="flex-wrap:wrap;gap:14px"><div style="max-width:620px"><div class="eyebrow">${ic("zap", 'width="12" height="12"')} Crash Test</div><h2 style="font-size:22px;margin:6px 0">${last ? `Your Investor DNA: ${esc(last.arch)}` : "How would you behave in a market crash?"}</h2><p class="muted" style="margin:0">${last ? `Discipline ${last.score}/100 · return ${F.pct(last.ret, 1)}. Play again to see if your habits change.` : "Live through a 60-day crash in 90 seconds. The Bias Mirror then shows which of your habits make or lose money."}</p></div><div class="row"><a class="btn primary" href="#/crash">${last ? "Play again" : "Take the Crash Test"}</a><a class="btn" href="#/league">${ic("users")} Play with a group</a></div></div></section>`;
      },
      journey: () => {
        const lv = window.KOSH_EXTRA.level(S.badges);
        const tools = [["#/tipcheck", "shield", "Tip Check", "Got a WhatsApp stock tip? Check it for scam patterns."], ["#/timemachine", "clock", "Time Machine", "What if you'd invested 3 years ago, and could you have held on?"], ["#/journey", "target", "My Plan", S.profile ? "See your risk profile and goal plan." : "Find your risk profile in 6 questions."]];
        return `<section class="card"><div class="card-head"><h2>Your journey</h2><a class="btn sm ghost" href="#/journey">Badges</a></div>
          <div class="row" style="gap:14px;margin-bottom:14px"><strong>Level ${lv.idx + 1} · ${lv.name}</strong><div class="lesson-progress" style="flex:1;min-width:120px"><i style="width:${lv.pct}%"></i></div><span class="note">${lv.xp} XP${lv.next ? ` · ${lv.toNext} to ${lv.next}` : ""}</span></div>
          <div class="grid g3">${tools.map(([h, i, t, d]) => `<a class="tool-card" href="${h}">${ic(i)}<strong>${t}</strong><span class="note">${d}</span></a>`).join("")}</div></section>`;
      },
      brief: () => `<section class="card ai"><div class="card-head"><h2>${ic("spark", 'width="18" height="18"')} Today in 60 seconds</h2><span class="ai-tag">AI brief</span></div><div class="ai-text" id="brief"></div></section>`,
      indices: () => `<section class="card"><div class="card-head"><h2>Market overview</h2><div class="row">${seg("ixtf", ["1D", "1M", "1Y"], "1D")}<span class="tag warn">Simulated</span></div></div>
        <div class="grid g2" id="ix-cards"></div><div class="chart" id="ix-chart" style="margin-top:14px"></div><div class="chart-explain" id="ix-explain"></div></section>`,
      movers: () => `<section class="card"><div class="card-head"><h2>Top movers today</h2><a href="#/markets" class="btn sm ghost">All stocks</a></div><div class="grid g2"><div><div class="eyebrow" style="color:var(--up);margin-bottom:6px">Gainers</div><div id="gainers"></div></div><div><div class="eyebrow" style="color:var(--down);margin-bottom:6px">Losers</div><div id="losers"></div></div></div></section>`,
      portfolio: () => `<section class="card"><div class="card-head"><h2>Portfolio performance <span class="tag">Virtual money</span></h2><a href="#/portfolio" class="btn sm ghost">Open simulator</a></div><div class="grid g2" id="pf-stats" style="gap:10px"></div></section>`,
      watchlist: () => `<section class="card"><div class="card-head"><h2>Watchlist</h2><a href="#/watchlist" class="btn sm ghost">Manage</a></div><div id="wl"></div></section>`,
      trending: () => `<section class="card"><div class="card-head"><h2>Trending</h2><span class="note">Ranked by today's volume vs 20-day average</span></div><div id="trend"></div></section>`,
      recent: () => `<section class="card"><div class="card-head"><h2>Recently viewed</h2></div><div id="recent"></div></section>`,
      updates: () => `<section class="card"><div class="card-head"><h2>Market updates</h2><a href="#/news" class="btn sm ghost">All insights</a></div><div id="updates"></div><p class="note">Fictional demo scenarios — not real news.</p></section>`,
      learn: () => { const done = Object.keys(S.lessons).length; const next = D.lessons.find((l) => !S.lessons[l.id]); return `<section class="card"><div class="card-head"><h2>Continue learning</h2><span class="note">${done}/${D.lessons.length} lessons</span></div><div class="lesson-progress"><i style="width:${(done / D.lessons.length) * 100}%"></i></div><p style="margin-top:12px">${next ? `Next up: <strong>${next.title}</strong> · ${next.mins} min` : "All lessons complete — try the scenarios and calculators."}</p><a class="btn primary sm" href="#/learn">${next ? "Start lesson" : "Open Learning Centre"}</a></section>`; },
    };
    // lay out: pair some widgets in two columns
    const pairs = new Set(["portfolio", "watchlist", "trending", "recent", "updates", "learn"]);
    let html = "", buf = [];
    const flush = () => { if (buf.length) { html += `<div class="grid g2">${buf.join("")}</div>`; buf = []; } };
    for (const k of order) {
      if (pairs.has(k)) { buf.push(W[k]()); if (buf.length === 2) flush(); }
      else { flush(); html += W[k](); }
    }
    flush();
    host.innerHTML = html || `<div class="card empty">All widgets are hidden. <button class="btn sm" id="customize2">Customize</button></div>`;

    let ixtf = "1D";
    const fill = () => {
      setHTML("#brief", dailyBrief());
      if ($("#ix-cards")) {
        $("#ix-cards").innerHTML = M.indices().map((x) => {
          const sp = M.indexSeries(x, "1D");
          return `<div class="stat-mini"><div class="spread"><span class="label">${x.name} <span class="faint">(sim)</span></span>${C.spark(sp, x.chgPct >= 0 ? "var(--up)" : "var(--down)", 80, 26)}</div><div class="value">${F.num(x.level)}</div><div class="change ${F.cls(x.chg)}">${x.chg >= 0 ? "+" : "−"}${F.num(Math.abs(x.chg))} (${F.pct(x.chgPct)})</div></div>`;
        }).join("");
      }
      const ms = M.companies.map((c) => ({ c, m: M.metrics(c.sym) }));
      const row = ({ c, m }, extra = "") => `<div class="list-item click" tabindex="0" data-go="#/stock/${c.sym}">${logo(c)}<div class="grow"><div class="sym-name">${c.sym}</div><div class="sym-sub">${esc(c.name)}</div></div><div class="end">${priceCell(c.sym)}<div>${extra || chgCell(c.sym)}</div></div></div>`;
      if ($("#gainers")) {
        const sorted = ms.slice().sort((a, b) => b.m.chgPct - a.m.chgPct);
        setHTML("#gainers", sorted.filter((x) => x.m.chgPct > 0).slice(0, 3).map((x) => row(x)).join("") || `<div class="empty">No gainers right now.</div>`);
        setHTML("#losers", sorted.reverse().filter((x) => x.m.chgPct < 0).slice(0, 3).map((x) => row(x)).join("") || `<div class="empty">No losers right now.</div>`);
      }
      setHTML("#trend", ms.map((x) => ({ ...x, r: x.m.dayVol / x.m.avgVol })).sort((a, b) => b.r - a.r).slice(0, 4).map((x) => row(x, `<span class="tag info">${x.r.toFixed(1)}× vol</span>`)).join(""));
      setHTML("#wl", S.watchlist.length ? S.watchlist.slice(0, 5).map((s) => row(ms.find((x) => x.c.sym === s))).join("") : emptyState("star", "Your watchlist is empty", "Tap the ☆ on any stock to track it here."));
      setHTML("#recent", S.recent.length ? S.recent.slice(0, 4).map((s) => row(ms.find((x) => x.c.sym === s))).join("") : emptyState("eye", "Nothing viewed yet", "Stocks you open will appear here."));
      setHTML("#updates", D.news.slice(0, 4).map((n) => `<div class="list-item click" tabindex="0" data-go="#/news/${n.id}"><span class="dot" style="color:var(--${n.sent === "pos" ? "up" : n.sent === "neg" ? "down" : "warn"})"></span><div class="grow"><div style="font-weight:600">${esc(n.h)}</div><div class="sym-sub">${n.syms.join(", ")} · ${n.cat}</div></div></div>`).join(""));
      if ($("#pf-stats")) {
        const p = portfolioState();
        $("#pf-stats").innerHTML = [
          ["Total value", F.inr(p.total, 0), `<span class="${F.cls(p.overall)}">${F.pct(p.overall)} all-time</span>`],
          ["Today", `<span class="${F.cls(p.day)}">${F.signed(p.day, 0)}</span>`, `<span class="${F.cls(p.dayPct)}">${F.pct(p.dayPct)}</span>`],
          ["Unrealised P&L", `<span class="${F.cls(p.pnl)}">${F.signed(p.pnl, 0)}</span>`, `<span class="${F.cls(p.pnlPct)}">${F.pct(p.pnlPct)}</span>`],
          ["Cash", F.inr(p.cash, 0), `${p.holdings.length} holdings`],
        ].map(([l, v, s]) => `<div class="stat-mini"><span class="label">${l}</span><span class="value">${v}</span><span class="note">${s}</span></div>`).join("");
      }
    };
    const drawIx = () => {
      if (!$("#ix-chart")) return;
      const defs = M.indexDefs;
      const series = defs.map((d, i) => ({ name: d.name, color: i ? "var(--c2)" : "var(--c1)", data: M.indexSeries(d, ixtf) }));
      C.line($("#ix-chart"), { series, percent: true, tf: ixtf, height: 200, label: "Simulated index performance" });
      $("#ix-explain").innerHTML = AI.chartStory("Simulated NIFTY 50", ixtf, series[0].data, true) + ` <span class="faint">SENSEX moved ${F.pct((series[1].data.at(-1).p / series[1].data[0].p - 1) * 100)} over the same window.</span>`;
    };
    fill(); drawIx();
    const sg = $('[data-seg="ixtf"]');
    if (sg) sg.addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; ixtf = b.dataset.v; $$("button", sg).forEach((x) => x.setAttribute("aria-pressed", String(x === b))); drawIx(); });
    const cust = () => customizeModal();
    $("#customize").onclick = cust; if ($("#customize2")) $("#customize2").onclick = cust;
    page.live = () => { fill(); if (ixtf === "1D" && $("#ix-chart") && !$("#ix-chart").matches(":hover")) drawIx(); };
  }
  // Live updates must never rebuild a list under the user's cursor (a click would hit a vanished button).
  function setHTML(sel, html, force = false) {
    const e = $(sel); if (!e) return;
    if (!force && e.childElementCount && (e.matches(":hover") || (e.contains(document.activeElement) && document.activeElement !== document.body))) return;
    e.innerHTML = html;
  }
  function emptyState(icon, title, body) { return `<div class="empty">${ic(icon)}<div style="font-weight:600;color:var(--text)">${title}</div><div>${body}</div></div>`; }

  function dailyBrief() {
    const ms = M.companies.map((c) => ({ c, m: M.metrics(c.sym) }));
    const up = ms.filter((x) => x.m.chgPct > 0).length;
    const ix = M.indices()[0];
    const top = ms.slice().sort((a, b) => b.m.chgPct - a.m.chgPct);
    const pf = portfolioState();
    const wl = S.watchlist.map((s) => ms.find((x) => x.c.sym === s)).filter(Boolean);
    const wlBig = wl.slice().sort((a, b) => Math.abs(b.m.chgPct) - Math.abs(a.m.chgPct))[0];
    const conc = pf.holdings.length ? pf.holdings.slice().sort((a, b) => b.value - a.value)[0] : null;
    const tips = [];
    if (conc && conc.value / pf.invested > 0.4) tips.push(`${M.bySym(conc.sym).c.name} is ${((conc.value / pf.invested) * 100).toFixed(0)}% of your invested money — <a href="#/learn">learn about diversification</a>.`);
    const hiPE = top[0].m.pe && top[0].m.pe > 45;
    if (hiPE) tips.push(`Today's top gainer trades at a P/E of ${top[0].m.pe.toFixed(0)} — high expectations can mean sharp moves both ways.`);
    return `<p>The simulated NIFTY 50 is <strong class="${F.cls(ix.chgPct)}">${F.pct(ix.chgPct)}</strong>; <strong>${up} of ${ms.length}</strong> demo stocks are up${up > ms.length / 2 ? " — broadly positive breadth" : up < ms.length / 2 ? " — more decliners than advancers" : ""}.</p>
      <p><strong>Biggest moves:</strong> <a href="#/stock/${top[0].c.sym}">${top[0].c.name}</a> <span class="${F.cls(top[0].m.chgPct)}">${F.pct(top[0].m.chgPct)}</span>, <a href="#/stock/${top.at(-1).c.sym}">${top.at(-1).c.name}</a> <span class="${F.cls(top.at(-1).m.chgPct)}">${F.pct(top.at(-1).m.chgPct)}</span>.</p>
      ${pf.holdings.length ? `<p><strong>Your simulated portfolio</strong> is <span class="${F.cls(pf.day)}">${F.signed(pf.day, 0)}</span> today (${F.pct(pf.dayPct)}).</p>` : ""}
      ${wlBig ? `<p><strong>Watchlist:</strong> ${wlBig.c.name} is your biggest mover (${F.pct(wlBig.m.chgPct)}).</p>` : ""}
      ${tips.length ? `<p><strong>Coach tip:</strong> ${tips[0]}</p>` : ""}
      <p class="src">Generated from simulated prices at ${F.time(M.lastTick())} · explanations are educational, not advice.</p>`;
  }

  function customizeModal() {
    const body = () => S.dash.order.map((k, i) => {
      const label = WIDGETS.find((w) => w[0] === k)[1];
      return `<div class="widget-ctl"><label><input type="checkbox" data-w="${k}" ${S.dash.hidden.includes(k) ? "" : "checked"}> ${label}</label>
        <button class="icon-btn" style="width:30px;height:30px" data-mv="${i}" data-d="-1" aria-label="Move ${label} up" ${i === 0 ? "disabled" : ""}>${ic("up")}</button>
        <button class="icon-btn" style="width:30px;height:30px" data-mv="${i}" data-d="1" aria-label="Move ${label} down" ${i === S.dash.order.length - 1 ? "disabled" : ""}>${ic("down")}</button></div>`;
    }).join("");
    const m = modal(`<div class="modal-head"><h2>Customize dashboard</h2><button class="icon-btn" data-close aria-label="Close">${ic("x")}</button></div><p class="muted">Show, hide and reorder widgets. Saved in this browser.</p><div id="wc">${body()}</div><div class="row" style="margin-top:14px;justify-content:space-between"><button class="btn ghost" id="wreset">Reset</button><button class="btn primary" data-close>Done</button></div>`, () => route());
    m.addEventListener("change", (e) => {
      const k = e.target.dataset.w; if (!k) return;
      S.dash.hidden = e.target.checked ? S.dash.hidden.filter((x) => x !== k) : [...S.dash.hidden, k]; save();
    });
    m.addEventListener("click", (e) => {
      const b = e.target.closest("[data-mv]");
      if (b) { const i = +b.dataset.mv, j = i + +b.dataset.d; const o = S.dash.order; [o[i], o[j]] = [o[j], o[i]]; save(); $("#wc", m).innerHTML = body(); }
      if (e.target.closest("#wreset")) { S.dash = { order: WIDGETS.map((w) => w[0]), hidden: [] }; save(); $("#wc", m).innerHTML = body(); }
    });
  }

  function modal(html, onClose) {
    const ov = document.createElement("div");
    ov.className = "overlay";
    ov.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
    document.body.appendChild(ov);
    const prev = document.activeElement;
    const close = () => { ov.remove(); document.removeEventListener("keydown", key); onClose && onClose(); prev && prev.focus && prev.focus(); };
    const key = (e) => { if (e.key === "Escape") close(); };
    document.addEventListener("keydown", key);
    ov.addEventListener("click", (e) => { if (e.target === ov || e.target.closest("[data-close]")) close(); });
    const f = ov.querySelector("input, select, button:not([data-close])"); f && f.focus();
    ov.close = close;
    return ov;
  }

  /* ============ MARKETS ============ */
  function markets(arg) {
    const sectors = [...new Set(M.companies.map((c) => c.sector))].sort();
    const st = { q: "", sector: "", cap: "", tab: arg === "losers" ? "Losers" : arg === "gainers" ? "Gainers" : "All", sort: "mcap", dir: -1, preset: "", view: "Table", color: "day" };
    const med = M.medianPE();
    const PRESETS = {
      profitable: ["Profitable & low debt", (c, m) => m.profit > 0 && !c.lender && m.de < 0.5, "Companies that make money without leaning on borrowed money tend to survive bad years."],
      growers: ["Fast growers", (c, m) => m.revCagr > 0.15, "Sales growing 15%+ a year. Fast growth usually comes with a higher P/E, so check you're not overpaying."],
      dividend: ["Dividend payers", (c, m) => m.divYield >= 1, "They return at least 1% of the share price to you as cash each year: income while you wait."],
      value: ["Below-median P/E", (c, m) => m.pe && m.pe < med, `P/E under the demo median (${med.toFixed(0)}). Cheaper can mean a bargain, or a business the market expects to slow.`],
      steady: ["Lower risk", (c) => AI.risk(c.sym).score < 45, "Kosh risk score under 45: calmer prices and steadier profits. A good starting point for beginners."],
      risky: ["Handle with care", (c) => AI.risk(c.sym).score >= 60, "Risk score 60+. Not necessarily bad, but keep any position small."],
    };
    content.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">Explore</div><h1>Markets</h1><p>12 fictional companies across sectors. Click any row for an AI analysis.</p></div><span class="tag warn">Simulated prices</span></div>
      <div class="card">
        <div class="row" style="margin-bottom:14px">
          ${seg("tab", ["All", "Gainers", "Losers", "Watchlist"], st.tab)}
          <input class="input" id="mf-q" placeholder="Filter by name or symbol" style="max-width:220px" aria-label="Filter stocks" />
          <select class="input" id="mf-sector" style="max-width:200px" aria-label="Sector"><option value="">All sectors</option>${sectors.map((s) => `<option>${s}</option>`).join("")}</select>
          <select class="input" id="mf-cap" style="max-width:160px" aria-label="Size"><option value="">All sizes</option><option>Large-cap</option><option>Mid-cap</option><option>Small-cap</option></select>
          <span class="note" id="mf-count"></span>
          <div style="margin-left:auto" class="row">${seg("view", ["Table", "Heatmap"], "Table")}</div>
        </div>
        <div class="row" style="margin-bottom:6px"><span class="note">Beginner screens:</span>${Object.entries(PRESETS).map(([k, [l]]) => `<button class="chip" data-preset="${k}" aria-pressed="false">${l}</button>`).join("")}</div>
        <p class="note" id="mf-why" style="min-height:18px;margin-bottom:12px"></p>
        <div id="mheat-ctl" class="row" style="margin-bottom:10px" hidden><span class="note">Colour by:</span>${seg("hcolor", ["Day change", "1Y return", "Risk score", "P/E"], "Day change")}</div>
        <div id="mheat" class="heatmap" hidden></div>
        <div class="table-wrap" id="mtable"><table class="t"><thead><tr id="mhead"></tr></thead><tbody id="mbody"></tbody></table></div>
      </div>`;
    const cols = [
      ["name", "Company", null], ["price", "Price", "price"], ["chg", "Day", null], ["spark", "1M trend", null], ["ret1Y", "1Y", null],
      ["mcap", "Market cap", "mcap"], ["pe", "P/E", "pe"], ["risk", "Risk", "beta"],
    ];
    const val = (sym, k) => { const m = M.metrics(sym); return { name: M.bySym(sym).c.name, price: m.price, chg: m.chgPct, ret1Y: m.ret1Y, mcap: m.mcap, pe: m.pe ?? 9999, risk: AI.risk(sym).score }[k]; };
    const draw = () => {
      $("#mhead").innerHTML = `<th></th>` + cols.map(([k, l, g]) => `<th class="${k === "name" || k === "spark" ? "" : "r"}" ${k === st.sort ? `aria-sort="${st.dir > 0 ? "ascending" : "descending"}"` : ""}>${k === "spark" ? l : `<button data-sort="${k}">${l}${k === st.sort ? (st.dir > 0 ? " ↑" : " ↓") : ""}</button>`} ${g ? info(g) : ""}</th>`).join("");
      let list = M.companies.map((c) => c.sym);
      const q = st.q.toLowerCase();
      if (q) list = list.filter((s) => s.toLowerCase().includes(q) || M.bySym(s).c.name.toLowerCase().includes(q));
      if (st.sector) list = list.filter((s) => M.bySym(s).c.sector === st.sector);
      if (st.cap) list = list.filter((s) => M.metrics(s).capClass === st.cap);
      if (st.tab === "Gainers") list = list.filter((s) => M.metrics(s).chgPct > 0);
      if (st.tab === "Losers") list = list.filter((s) => M.metrics(s).chgPct < 0);
      if (st.tab === "Watchlist") list = list.filter(isWatched);
      if (st.preset) list = list.filter((s) => PRESETS[st.preset][1](M.bySym(s).c, M.metrics(s)));
      $("#mf-why").innerHTML = st.preset ? `<strong style="color:var(--text)">${PRESETS[st.preset][0]}:</strong> ${PRESETS[st.preset][2]}` : "Pick a screen to filter by an idea, not a number.";
      const sortKey = st.tab === "Gainers" && st.sort === "mcap" ? "chg" : st.tab === "Losers" && st.sort === "mcap" ? "chg" : st.sort;
      const dir = st.tab === "Losers" && st.sort === "mcap" ? 1 : st.dir;
      list.sort((a, b) => { const x = val(a, sortKey), y = val(b, sortKey); return (typeof x === "string" ? x.localeCompare(y) : x - y) * dir; });
      $("#mf-count").textContent = `${list.length} of ${M.companies.length}`;
      $("#mbody").innerHTML = list.length ? list.map((s) => {
        const c = M.bySym(s).c, m = M.metrics(s);
        return `<tr class="click" tabindex="0" data-go="#/stock/${s}"><td style="width:30px">${starBtn(s)}</td><td><div class="sym">${logo(c)}<div><div class="sym-name">${c.sym}</div><div class="sym-sub">${esc(c.name)} · ${esc(c.sector)}</div></div></div></td>
          <td class="r">${priceCell(s)}</td><td class="r">${chgCell(s)}</td><td>${C.spark(M.series(s, "1M"), m.ret1M >= 0 ? "var(--up)" : "var(--down)")}</td>
          <td class="r"><span class="change ${F.cls(m.ret1Y)}">${F.pct(m.ret1Y, 1)}</span></td><td class="r num">${F.cr(m.mcap)}<div class="sym-sub">${m.capClass}</div></td>
          <td class="r num">${m.pe ? m.pe.toFixed(1) : "—"}</td><td class="r">${riskTag(s)}</td></tr>`;
      }).join("") : `<tr><td colspan="9">${emptyState("search", "No stocks match", st.tab === "Watchlist" ? "Your watchlist is empty — star a stock to add it." : "Try clearing a filter.")}</td></tr>`;
      $("#mtable").hidden = st.view !== "Table"; $("#mheat").hidden = st.view === "Table"; $("#mheat-ctl").hidden = st.view === "Table";
      if (st.view === "Heatmap") {
        const col = (sym) => {
          const m = M.metrics(sym);
          const [v, lo, hi, inv] = st.color === "day" ? [m.chgPct, -3, 3] : st.color === "1y" ? [m.ret1Y, -60, 60] : st.color === "risk" ? [AI.risk(sym).score, 20, 85, 1] : [m.pe ?? 160, 15, 110, 1];
          let t = Math.max(-1, Math.min(1, ((v - lo) / (hi - lo)) * 2 - 1)); if (inv) t = -t;
          return { bg: `color-mix(in srgb, var(--${t >= 0 ? "up" : "down"}) ${Math.round(12 + Math.abs(t) * 58)}%, var(--surface-2))`, label: st.color === "day" ? F.pct(m.chgPct) : st.color === "1y" ? F.pct(m.ret1Y, 0) : st.color === "risk" ? AI.risk(sym).score + "/100" : m.pe ? "P/E " + m.pe.toFixed(0) : "P/E n/m" };
        };
        $("#mheat").innerHTML = list.length ? list.slice().sort((a, b) => M.metrics(b).mcap - M.metrics(a).mcap).map((sym) => { const m = M.metrics(sym), k = col(sym), c = M.bySym(sym).c; return `<button class="heat-tile" data-go="#/stock/${sym}" style="flex-grow:${Math.round(m.mcap / 1000)};background:${k.bg}" aria-label="${esc(c.name)} ${k.label}"><strong>${sym}</strong><span class="ht-name">${esc(c.name)}</span><span class="num">${k.label}</span></button>`; }).join("") : emptyState("search", "No stocks match", "Try clearing a filter.");
      }
    };
    draw();
    $("#mf-q").oninput = (e) => { st.q = e.target.value; draw(); };
    $("#mf-sector").onchange = (e) => { st.sector = e.target.value; draw(); };
    $("#mf-cap").onchange = (e) => { st.cap = e.target.value; draw(); };
    content.querySelector(".card").addEventListener("click", (e) => {
      const p = e.target.closest("[data-preset]"); if (p) { st.preset = st.preset === p.dataset.preset ? "" : p.dataset.preset; $$("[data-preset]").forEach((x) => x.setAttribute("aria-pressed", String(x.dataset.preset === st.preset))); draw(); return; }
      const v = e.target.closest('[data-seg="view"] button'); if (v) { st.view = v.dataset.v; $$('[data-seg="view"] button').forEach((x) => x.setAttribute("aria-pressed", String(x === v))); draw(); return; }
      const h = e.target.closest('[data-seg="hcolor"] button'); if (h) { st.color = { "Day change": "day", "1Y return": "1y", "Risk score": "risk", "P/E": "pe" }[h.dataset.v]; $$('[data-seg="hcolor"] button').forEach((x) => x.setAttribute("aria-pressed", String(x === h))); draw(); }
    });
    $('[data-seg="tab"]').onclick = (e) => { const b = e.target.closest("button"); if (!b) return; st.tab = b.dataset.v; $$('[data-seg="tab"] button').forEach((x) => x.setAttribute("aria-pressed", String(x === b))); draw(); };
    $("#mhead").onclick = (e) => { const b = e.target.closest("[data-sort]"); if (!b) return; const k = b.dataset.sort; st.dir = st.sort === k ? -st.dir : k === "name" ? 1 : -1; st.sort = k; draw(); };
    page.onWatch = draw;
  }

  /* ============ STOCK DETAIL ============ */
  function stock(sym) {
    sym = (sym || "").toUpperCase();
    const s = M.bySym(sym);
    if (!s) return notFound();
    const c = s.c;
    S.recent = [sym, ...S.recent.filter((x) => x !== sym)].slice(0, 8); save();
    let tf = "1D", vsIx = false, mode = S.mode;
    const m0 = M.metrics(sym);
    content.innerHTML = `
      <div class="stock-head">
        <div class="row" style="align-items:flex-start;gap:14px">${logo(c)}<div><div class="row"><h1>${esc(c.name)}</h1>${starBtn(sym)}</div><div class="row muted" style="gap:8px"><span class="mono">${c.sym}</span>·<span>${esc(c.sector)}</span>·<span class="tag">${m0.capClass}</span><span class="tag warn">Fictional company</span></div></div></div>
        <div style="text-align:right"><div class="price-big" data-p="${sym}">${F.inr(s.price)}</div><div id="hd-chg"></div><div class="note">Simulated · updated <span data-tick>${F.time(M.lastTick())}</span></div></div>
      </div>
      <div class="row" style="margin-bottom:16px">
        <button class="btn buy" data-trade="${sym}" data-side="BUY">Buy (demo)</button>
        <button class="btn sell" data-trade="${sym}" data-side="SELL">Sell (demo)</button>
        <button class="btn" data-alert="${sym}">${ic("bell")} Set alert</button>
        <a class="btn" href="#/compare/${sym},${sym === "NIMB" ? "KSHT" : "NIMB"}">${ic("compare")} Compare</a>
        <button class="btn" data-ask="Explain ${esc(c.name)}'s financial performance in simple language">${ic("spark")} Ask AI about ${c.sym}</button>
      </div>
      <div class="grid g-main">
        <div class="stack" style="gap:16px">
          <section class="card">
            <div class="card-head"><h2>Price chart</h2><div class="row">${seg("tf", M.TF, tf)}<label class="row note" style="gap:6px;cursor:pointer"><input type="checkbox" id="vsix" style="accent-color:var(--accent)"> vs NIFTY (sim)</label></div></div>
            <div class="chart" id="pchart"></div>
            <div class="chart-explain" id="pexplain"></div>
          </section>
          <section class="card ai">
            <div class="card-head"><h2>${ic("spark", 'width="18" height="18"')} AI Stock Explainer</h2><div class="row">${seg("mode", ["Beginner", "Advanced"], mode === "advanced" ? "Advanced" : "Beginner")}</div></div>
            <div class="ai-text" id="explain"></div>
            <p class="src note">Generated from the demo financials and simulated prices shown on this page. Educational only — not a recommendation.</p>
          </section>
          <section class="card">
            <div class="card-head"><h2>Key metrics</h2><span class="note">Tap <b>i</b> for what each means</span></div>
            <div class="metric-grid" id="metrics"></div>
          </section>
          <section class="card">
            <div class="card-head"><h2>Revenue & profit ${info("revenue")}</h2><div class="legend"><span><i style="background:var(--c2)"></i>Revenue</span><span><i style="background:var(--c1)"></i>Net profit</span></div></div>
            <div class="chart" id="fin"></div>
            <div class="table-wrap" style="margin-top:10px"><table class="t"><thead><tr><th></th>${D.FY.map((y) => `<th class="r">${y}</th>`).join("")}</tr></thead><tbody>
              <tr><td>Revenue</td>${c.revenue.map((v) => `<td class="r num">${F.cr(v)}</td>`).join("")}</tr>
              <tr><td>Net profit</td>${c.profit.map((v) => `<td class="r num ${v < 0 ? "down" : ""}">${F.cr(v)}</td>`).join("")}</tr>
              <tr><td>Margin ${info("margin")}</td>${c.profit.map((v, i) => `<td class="r num">${((v / c.revenue[i]) * 100).toFixed(1)}%</td>`).join("")}</tr>
            </tbody></table></div>
            <p class="note">Fictional financials for teaching. ${c.lender ? "For lenders, 'revenue' means total income (mostly interest earned)." : ""}</p>
          </section>
          <section class="card">
            <div class="card-head"><h2>Bullish vs bearish factors ${info("bullbear")}</h2></div>
            <div class="bull-bear"><div class="bb bull"><h4>▲ Bull case</h4><ul>${c.bull.map((x) => `<li>${x}</li>`).join("")}</ul></div><div class="bb bear"><h4>▼ Bear case</h4><ul>${c.bear.map((x) => `<li>${x}</li>`).join("")}</ul></div></div>
          </section>
        </div>
        <div class="stack" style="gap:16px">
          <section class="card"><div class="card-head"><h2>Company overview</h2></div><p>${c.about}</p><p class="muted"><strong style="color:var(--text)">How it makes money:</strong> ${c.model}</p></section>
          <section class="card"><div class="card-head"><h2>${ic("shield", 'width="18" height="18"')} Explainable risk</h2><span id="risk-label"></span></div><div id="risk"></div></section>
          <section class="card"><div class="card-head"><h2>Strengths & risks</h2></div>
            <div class="eyebrow" style="color:var(--up)">Strengths</div><ul class="bullets" style="margin:6px 0 12px">${c.strengths.map((x) => `<li>${x}</li>`).join("")}</ul>
            <div class="eyebrow" style="color:var(--down)">Risks</div><ul class="bullets" style="margin-top:6px">${c.risks.map((x) => `<li>${x}</li>`).join("")}</ul></section>
          <section class="card"><div class="card-head"><h2>Research before deciding</h2><span class="note" id="rs-count"></span></div><div id="research"></div></section>
          <section class="card"><div class="card-head"><h2>Related insights</h2></div><div id="rnews"></div></section>
        </div>
      </div>`;

    const drawHead = () => { const m = M.metrics(sym); $("#hd-chg").innerHTML = `<span class="change ${F.cls(m.chg)}">${F.signed(m.chg)} (${F.pct(m.chgPct)})</span> <span class="note">today</span>`; };
    const drawChart = () => {
      const data = M.series(sym, tf);
      const series = [{ name: c.sym, color: data.at(-1).p >= data[0].p ? "var(--up)" : "var(--down)", data }];
      if (vsIx) series.push({ name: "NIFTY (sim)", color: "var(--c2)", data: M.indexSeries(M.indexDefs[0], tf) });
      C.line($("#pchart"), { series, tf, volume: !vsIx, percent: vsIx, height: 300, refLine: tf === "1D" ? s.prevClose : null, label: `${c.name} ${tf} price` });
      $("#pexplain").innerHTML = `<div class="row" style="margin-bottom:6px"><span class="ai-tag">${ic("spark", 'width="12" height="12"')} Chart explained</span></div>` + AI.chartStory(sym, tf, data) + (vsIx ? ` <span class="faint">The simulated NIFTY moved ${F.pct((series[1].data.at(-1).p / series[1].data[0].p - 1) * 100)} in the same window.</span>` : "");
    };
    const drawExplain = () => { $("#explain").innerHTML = AI.explain(sym, mode).map((p) => `<p>${p}</p>`).join("") + `<div class="chips" style="margin-top:10px">${["Why is it moving today?", "What are the risks?", "Is the P/E high?"].map((q) => `<button class="chip" data-ask="${q.replace("it", c.sym).replace("the P/E", c.sym + "'s P/E")}">${q}</button>`).join("")}</div>`; };
    const drawMetrics = () => {
      const m = M.metrics(sym);
      const rows = [
        ["Market cap", F.cr(m.mcap), "mcap"], ["P/E ratio", m.pe ? m.pe.toFixed(1) : "n/m", "pe"], ["EPS", F.inr(m.eps), "eps"],
        ["Revenue FY26", F.cr(m.revenue), "revenue"], ["Net profit FY26", F.cr(m.profit), "profit"], ["Net margin", m.margin.toFixed(1) + "%", "margin"],
        ["ROE", m.roe.toFixed(1) + "%", "roe"], [c.lender ? "Leverage (lender)" : "Debt / equity", c.lender ? m.deRaw.toFixed(1) + "×" : m.de.toFixed(2), c.lender ? "npa" : "de"],
        ["Revenue CAGR (4y)", m.revCagr ? F.pct(m.revCagr * 100, 1, false) : "—", "cagr"], ["Dividend yield", m.divYield.toFixed(2) + "%", "divy"],
        ["Volatility (1Y)", F.pct(m.vol * 100, 1, false), "beta"], ["52-week range", `${F.inr(m.lo52, 0)} – ${F.inr(m.hi52, 0)}`, "hi52"],
      ];
      $("#metrics").innerHTML = rows.map(([l, v, k]) => `<div class="stat-mini"><span class="label">${l} ${info(k)}</span><span class="value">${v}</span></div>`).join("");
    };
    const drawRisk = () => {
      const r = AI.risk(sym);
      $("#risk-label").innerHTML = `<span class="tag ${r.score < 40 ? "up" : r.score < 62 ? "warn" : "down"}">${r.label} · ${r.score}/100</span>`;
      $("#risk").innerHTML = `<div class="risk-meter" role="img" aria-label="Risk score ${r.score} of 100"><i style="left:${r.score}%"></i></div><div class="spread note"><span>Lower</span><span>Higher</span></div>` +
        r.items.map((i) => `<details class="x risk-x"><summary><span class="rk-main"><span class="rk-name">${i.key} ${info(i.metric)}</span><span class="note">${i.value}</span></span><span class="tag ${i.level === "Low" ? "up" : i.level === "Medium" ? "warn" : "down"}">${i.level}</span></summary><div class="x-body">${i.evidence}</div></details>`).join("") +
        `<p class="note">Score averages six factors computed from the data on this page. Open each to see the evidence.</p>`;
    };
    const drawResearch = () => {
      const done = S.research[sym] || [];
      $("#research").innerHTML = c.research.map((x, i) => `<label class="widget-ctl" style="cursor:pointer"><input type="checkbox" data-rs="${i}" ${done.includes(i) ? "checked" : ""}> <span>${x}</span></label>`).join("");
      $("#rs-count").textContent = `${done.length}/${c.research.length} checked`;
    };
    $("#research").addEventListener("change", (e) => {
      const i = +e.target.dataset.rs; const d = new Set(S.research[sym] || []);
      e.target.checked ? d.add(i) : d.delete(i); S.research[sym] = [...d]; save(); $("#rs-count").textContent = `${d.size}/${c.research.length} checked`; if (d.size === c.research.length) award("researcher");
    });
    const rel = D.news.filter((n) => n.syms.includes(sym));
    $("#rnews").innerHTML = rel.length ? rel.map((n) => `<div class="list-item click" tabindex="0" data-go="#/news/${n.id}"><span class="dot" style="color:var(--${n.sent === "pos" ? "up" : n.sent === "neg" ? "down" : "warn"})"></span><div class="grow"><div style="font-weight:600">${esc(n.h)}</div><div class="note">Demo scenario · tap for AI impact analysis</div></div></div>`).join("") : emptyState("news", "No linked insights", "No demo scenarios mention this company yet.");
    C.bars($("#fin"), { labels: D.FY, groups: [{ name: "Revenue", color: "var(--c2)", values: c.revenue }, { name: "Net profit", color: "var(--c1)", values: c.profit }], fmt: F.cr, height: 190, label: "Revenue and profit by year" });

    drawHead(); drawChart(); drawExplain(); drawMetrics(); drawRisk(); drawResearch();
    $('[data-seg="tf"]').onclick = (e) => { const b = e.target.closest("button"); if (!b) return; tf = b.dataset.v; $$('[data-seg="tf"] button').forEach((x) => x.setAttribute("aria-pressed", String(x === b))); drawChart(); };
    $('[data-seg="mode"]').onclick = (e) => { const b = e.target.closest("button"); if (!b) return; mode = b.dataset.v.toLowerCase(); $$('[data-seg="mode"] button').forEach((x) => x.setAttribute("aria-pressed", String(x === b))); drawExplain(); };
    $("#vsix").onchange = (e) => { vsIx = e.target.checked; drawChart(); };
    page.sym = sym;
    page.live = () => { drawHead(); if ((tf === "1D" || tf === "1W") && !$("#pchart").matches(":hover")) drawChart(); if (!$("#metrics").matches(":hover")) drawMetrics(); };
  }

  /* ============ COMPARE ============ */
  function compare(arg) {
    let syms = (arg ? arg.split(",") : ["NIMB", "AURV", "KSHT"]).map((x) => x.toUpperCase()).filter((x) => M.bySym(x)).slice(0, 3);
    if (syms.length < 2) syms = ["NIMB", "AURV"];
    let tf = "1Y";
    const colors = ["var(--c1)", "var(--c2)", "var(--c3)"];
    const opt = (sel) => M.companies.map((c) => `<option value="${c.sym}" ${c.sym === sel ? "selected" : ""}>${c.sym} — ${esc(c.name)}</option>`).join("");
    content.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">Smart comparison</div><h1>Compare companies</h1><p>Pick two or three. Every metric explains what it means and who comes out ahead.</p></div></div>
      <div class="card" style="margin-bottom:16px"><div class="grid g3">
        ${[0, 1, 2].map((i) => `<div class="field"><label for="cp${i}"><span class="dot" style="color:${colors[i]}"></span> Company ${i + 1}${i === 2 ? " (optional)" : ""}</label><select class="input" id="cp${i}">${i === 2 ? `<option value="">— None —</option>` : ""}${opt(syms[i])}</select></div>`).join("")}
      </div></div>
      <div class="grid g-main">
        <div class="stack" style="gap:16px">
          <section class="card"><div class="card-head"><h2>Price performance</h2>${seg("ctf", M.TF.filter((x) => x !== "1D"), tf)}</div><div class="chart" id="cchart"></div><div class="legend" id="clegend" style="margin-top:8px"></div><div class="chart-explain" id="cexplain"></div></section>
          <section class="card"><div class="card-head"><h2>Side by side</h2><span class="note">★ = strongest on that metric</span></div><div class="table-wrap"><table class="t" id="ctable"></table></div></section>
          <section class="card"><div class="card-head"><h2>Revenue growth</h2></div><div class="chart" id="cbars"></div><div class="legend" id="cbleg"></div></section>
        </div>
        <div class="stack" style="gap:16px">
          <section class="card ai"><div class="card-head"><h2>${ic("spark", 'width="18" height="18"')} Key differences</h2><span class="ai-tag">AI</span></div><ul class="bullets" id="cinsights"></ul><p class="note">Computed from demo data. Strongest on a metric ≠ best investment.</p></section>
          <section class="card"><div class="card-head"><h2>Risk side by side</h2></div><div id="crisk"></div></section>
        </div>
      </div>`;
    const draw = () => {
      const cs = syms.map((s) => M.bySym(s).c);
      const ser = syms.map((s, i) => ({ name: s, color: colors[i], data: M.series(s, tf) }));
      C.line($("#cchart"), { series: ser, percent: true, tf, height: 280, label: "Comparison chart" });
      $("#clegend").innerHTML = ser.map((x) => `<span><i style="background:${x.color}"></i>${x.name} <b class="${F.cls(x.data.at(-1).p - x.data[0].p)}">${F.pct((x.data.at(-1).p / x.data[0].p - 1) * 100)}</b></span>`).join("");
      const best = ser.slice().sort((a, b) => b.data.at(-1).p / b.data[0].p - a.data.at(-1).p / a.data[0].p)[0];
      $("#cexplain").innerHTML = `All lines start at 0% so you can compare growth fairly regardless of share price. Over ${tf}, <strong>${best.name}</strong> did best. Hover the chart to compare any date.`;
      const ms = syms.map((s) => M.metrics(s));
      const rows = [
        ["Price", "price", (m) => F.inr(m.price), null],
        ["1Y return", "hi52", (m) => F.pct(m.ret1Y, 1), (m) => m.ret1Y],
        ["Market cap", "mcap", (m) => F.cr(m.mcap), (m) => m.mcap],
        ["Revenue FY26", "revenue", (m) => F.cr(m.revenue), (m) => m.revenue],
        ["Net profit FY26", "profit", (m) => F.cr(m.profit), (m) => m.profit],
        ["Revenue CAGR", "cagr", (m) => (m.revCagr ? F.pct(m.revCagr * 100, 1, false) : "—"), (m) => m.revCagr],
        ["Net margin", "margin", (m) => m.margin.toFixed(1) + "%", (m) => m.margin],
        ["P/E", "pe", (m) => (m.pe ? m.pe.toFixed(1) : "n/m"), (m) => (m.pe ? -m.pe : null)],
        ["ROE", "roe", (m) => m.roe.toFixed(1) + "%", (m) => m.roe],
        ["Debt / equity", "de", (m, i) => (cs[i].lender ? "Lender" : m.de.toFixed(2)), (m, i) => (cs[i].lender ? null : -m.de)],
        ["Volatility", "beta", (m) => F.pct(m.vol * 100, 0, false), (m) => -m.vol],
        ["Risk score", "beta", (m, i) => AI.risk(syms[i]).score + "/100", (m, i) => -AI.risk(syms[i]).score],
      ];
      $("#ctable").innerHTML = `<thead><tr><th>Metric</th>${syms.map((s, i) => `<th class="r"><span style="color:${colors[i]}">●</span> ${s}</th>`).join("")}</tr></thead><tbody>` +
        rows.map(([l, k, f, score]) => {
          let bi = -1;
          if (score) { let bv = -Infinity; ms.forEach((m, i) => { const v = score(m, i); if (v != null && v > bv) { bv = v; bi = i; } }); }
          return `<tr><td>${l} ${info(k)}</td>${ms.map((m, i) => `<td class="r num" ${i === bi ? 'style="color:var(--accent-text);font-weight:700"' : ""}>${f(m, i)}${i === bi ? " ★" : ""}</td>`).join("")}</tr>`;
        }).join("") + `<tr><td>Sector</td>${cs.map((c) => `<td class="r">${esc(c.sector)}</td>`).join("")}</tr></tbody>`;
      $("#cinsights").innerHTML = AI.compare(syms).map((x) => `<li>${x}</li>`).join("");
      C.bars($("#cbars"), { labels: D.FY, groups: cs.map((c, i) => ({ name: c.sym, color: colors[i], values: c.revenue })), fmt: F.cr, height: 200, label: "Revenue by year" });
      $("#cbleg").innerHTML = cs.map((c, i) => `<span><i style="background:${colors[i]}"></i>${c.sym}</span>`).join("");
      $("#crisk").innerHTML = syms.map((s, i) => { const r = AI.risk(s); return `<div class="risk-row"><div class="spread"><strong><span style="color:${colors[i]}">●</span> ${s}</strong><span class="tag ${r.score < 40 ? "up" : r.score < 62 ? "warn" : "down"}">${r.label} · ${r.score}</span></div><div class="row" style="gap:4px;margin-top:6px">${r.items.map((x) => `<span class="tag ${x.level === "Low" ? "up" : x.level === "Medium" ? "warn" : "down"}" title="${esc(x.evidence.replace(/<[^>]+>/g, ""))}">${x.key}</span>`).join("")}</div></div>`; }).join("");
      history.replaceState(null, "", "#/compare/" + syms.join(","));
      award("comparer");
      chatContext();
    };
    draw();
    [0, 1, 2].forEach((i) => $("#cp" + i).onchange = () => {
      const v = [0, 1, 2].map((k) => $("#cp" + k).value).filter(Boolean);
      const uniq = [...new Set(v)];
      if (uniq.length < v.length) toast("Pick different companies to compare.");
      if (uniq.length >= 2) { syms = uniq; draw(); }
    });
    $('[data-seg="ctf"]').onclick = (e) => { const b = e.target.closest("button"); if (!b) return; tf = b.dataset.v; $$('[data-seg="ctf"] button').forEach((x) => x.setAttribute("aria-pressed", String(x === b))); draw(); };
    page.compare = () => syms;
  }

  /* ============ NEWS ============ */
  const extraNews = [
    { id: "x1", cat: "company", syms: ["SETU"], sent: "neg", h: "Setu Payments: regulator proposes cap on merchant fees", src: "Kosh demo scenario", at: 40,
      body: "A simulated consultation paper proposes capping fees charged on small-merchant payments.", why: "Payment fees are Setu's core revenue. A cap could slow revenue growth, which matters more because its high P/E assumes fast growth.", watch: ["Final rule and timeline", "Share of revenue from capped transactions"] },
    { id: "x2", cat: "company", syms: ["VYOM", "NIMB"], sent: "pos", h: "Vyom and Nimbus announce avionics software partnership", src: "Kosh demo scenario", at: 110,
      body: "A simulated joint venture to build flight-control software.", why: "Small for Nimbus (large revenue base) but adds a capability for Vyom. Partnerships take years to show up in revenue.", watch: ["Investment amount", "Revenue sharing terms"] },
  ];
  const liveNews = () => [...extraNews.filter((n) => n.published).sort((a, b) => b.published - a.published), ...D.news];
  function news(id) {
    const st = { cat: "All", sel: id || liveNews()[0].id };
    content.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">AI News Impact Analyzer</div><h1>News & market insights</h1><p>Select any item to see what happened, why it matters and which companies are exposed.</p></div></div>
      <div class="card" style="margin-bottom:16px;border-color:color-mix(in srgb,var(--warn) 40%,var(--border));background:var(--warn-bg)"><strong style="color:var(--warn)">Demo scenarios, not real news.</strong> <span class="muted">Every item below is a fictional teaching scenario about the fictional companies in Kosh. Connect a verified news API via the server to show real headlines — Kosh never invents real-world news.</span></div>
      <div class="row" style="margin-bottom:14px">${seg("ncat", ["All", "Company", "Economy", "Market", "Watchlist"], "All")}<select class="input" id="nsent" style="max-width:180px" aria-label="Sentiment"><option value="">Any impact</option><option value="pos">Positive</option><option value="neg">Negative</option><option value="neutral">Mixed</option></select></div>
      <div class="grid g-main" style="align-items:start">
        <div class="grid g2" id="nlist"></div>
        <aside class="card ai" id="ndetail" style="position:sticky;top:84px"></aside>
      </div>`;
    const draw = () => {
      let list = liveNews();
      if (st.cat === "Watchlist") list = list.filter((n) => n.syms.some(isWatched));
      else if (st.cat !== "All") list = list.filter((n) => n.cat === st.cat.toLowerCase());
      const sent = $("#nsent").value; if (sent) list = list.filter((n) => n.sent === sent);
      $("#nlist").innerHTML = list.length ? list.map((n) => `<button class="card news-card" data-nid="${n.id}" aria-current="${n.id === st.sel}">
          <div class="row" style="gap:6px"><span class="tag ${n.sent === "pos" ? "up" : n.sent === "neg" ? "down" : "warn"}">${n.sent === "pos" ? "Positive" : n.sent === "neg" ? "Negative" : "Mixed"}</span><span class="tag">${n.cat}</span>${n.published ? '<span class="tag info">New</span>' : ""}</div>
          <h3>${esc(n.h)}</h3><div class="note">${n.syms.join(" · ")} · ${n.published ? "Released " + F.time(n.published) : F.date(Date.now() - n.d * 864e5, { day: "numeric", month: "short" })} (simulated)</div></button>`).join("") : `<div class="card" style="grid-column:1/-1">${emptyState("news", "Nothing here", st.cat === "Watchlist" ? "No demo items mention your watchlist." : "Try another filter.")}</div>`;
      detail();
    };
    const detail = () => {
      const n = liveNews().find((x) => x.id === st.sel);
      if (!n) { $("#ndetail").innerHTML = emptyState("news", "Select an item", "Pick any card to see the AI impact analysis."); return; }
      const im = AI.newsImpact(n);
      $("#ndetail").innerHTML = `<div class="card-head"><span class="ai-tag">${ic("spark", 'width="12" height="12"')} AI impact summary</span><span class="tag ${n.sent === "pos" ? "up" : n.sent === "neg" ? "down" : "warn"}">${im.tone}</span></div>
        <h2 style="margin-bottom:8px">${esc(n.h)}</h2>
        <p class="muted"><strong style="color:var(--text)">What happened:</strong> ${n.body}</p>
        <p><strong>Why it matters to investors:</strong> ${n.why}</p>
        <div class="eyebrow" style="margin:12px 0 6px">Exposed companies</div>
        ${im.affected.map((a) => `<div class="list-item click" tabindex="0" data-go="#/stock/${a.s}">${logo(M.bySym(a.s).c)}<div class="grow"><div class="sym-name">${a.name}</div><div class="sym-sub">${a.exposure}</div></div><div class="end">${chgCell(a.s)}</div></div>`).join("")}
        <div class="eyebrow" style="margin:12px 0 6px">What to watch next</div>
        <ul class="bullets">${n.watch.map((w) => `<li>${w}</li>`).join("")}</ul>
        <div class="row" style="margin-top:12px"><button class="btn sm" data-alert="${n.syms[0]}" data-alert-type="news">${ic("bell")} Alert me on ${n.syms[0]} news</button><button class="btn sm" data-ask="How could '${esc(n.h)}' affect ${n.syms[0]}?">${ic("spark")} Ask follow-up</button></div>
        <p class="note" style="margin-top:10px">Source: ${n.src}. Fictional scenario; the analysis links it to the demo financials.</p>`;
    };
    draw();
    $('[data-seg="ncat"]').onclick = (e) => { const b = e.target.closest("button"); if (!b) return; st.cat = b.dataset.v; $$('[data-seg="ncat"] button').forEach((x) => x.setAttribute("aria-pressed", String(x === b))); draw(); };
    $("#nsent").onchange = draw;
    $("#nlist").onclick = (e) => { const b = e.target.closest("[data-nid]"); if (!b) return; st.sel = b.dataset.nid; award("news"); history.replaceState(null, "", "#/news/" + st.sel); $$("[data-nid]").forEach((x) => x.setAttribute("aria-current", String(x === b))); detail(); if (innerWidth < 1100) $("#ndetail").scrollIntoView({ behavior: "smooth" }); };
    page.onNews = draw;
  }

  /* ============ LEARN ============ */
  function learn(tab) {
    const tabs = [["lessons", "Lessons"], ["glossary", "Glossary"], ["quiz", "Quick quiz"], ["scenarios", "Scenarios"], ["calc", "Calculators"]];
    tab = tabs.some((t) => t[0] === tab) ? tab : "lessons";
    const done = Object.keys(S.lessons).length;
    content.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">Beginner Investment Coach</div><h1>Learning Centre</h1><p>Short lessons, quizzes, real-life scenarios and calculators.</p></div>
        <div style="min-width:200px"><div class="spread note"><span>Progress</span><span>${done}/${D.lessons.length} lessons</span></div><div class="lesson-progress"><i style="width:${(done / D.lessons.length) * 100}%"></i></div></div></div>
      <div class="tabs" role="tablist">${tabs.map(([k, l]) => `<button role="tab" aria-selected="${k === tab}" data-ltab="${k}">${l}</button>`).join("")}</div>
      <div id="lbody"></div>`;
    $(".tabs").onclick = (e) => { const b = e.target.closest("[data-ltab]"); if (b) location.hash = "#/learn/" + b.dataset.ltab; };
    const body = $("#lbody");
    if (tab === "lessons") {
      body.innerHTML = D.lessons.map((l, i) => `<details class="x" ${i === 0 && !S.lessons[l.id] ? "open" : ""}><summary><span class="row">${S.lessons[l.id] ? `<span class="tag up">${ic("check", 'width="12" height="12"')} Done</span>` : `<span class="tag">${l.mins} min</span>`} ${i + 1}. ${l.title}</span></summary>
        <div class="x-body">${l.body.map((p) => `<p style="color:var(--text)">${p}</p>`).join("")}<div class="divider"></div><div class="eyebrow" style="margin-bottom:8px">Check yourself</div>${l.quiz.map((q, k) => quizBlock(q, l.id + "-" + k)).join("")}
        <button class="btn ${S.lessons[l.id] ? "" : "primary"} sm" data-lesson="${l.id}">${S.lessons[l.id] ? "Mark as not done" : "Mark lesson complete"}</button></div></details>`).join("");
      body.addEventListener("click", (e) => { const b = e.target.closest("[data-lesson]"); if (!b) return; const id = b.dataset.lesson; if (S.lessons[id]) delete S.lessons[id]; else { S.lessons[id] = Date.now(); toast("Lesson complete — nice work!", "up"); award("student"); if (Object.keys(S.lessons).length === D.lessons.length) award("scholar"); } save(); learn("lessons"); });
    } else if (tab === "glossary") {
      body.innerHTML = `<div class="row" style="margin-bottom:14px"><input class="input" id="gq" placeholder="Search terms…" style="max-width:320px" aria-label="Search glossary" /><span class="note">Showing ${S.mode} explanations · switch level in the top bar</span></div><div id="glist"></div>`;
      const draw = () => {
        const q = $("#gq").value.toLowerCase();
        const items = Object.entries(D.glossary).filter(([, g]) => !q || g.term.toLowerCase().includes(q) || g.what.toLowerCase().includes(q));
        $("#glist").innerHTML = items.length ? items.map(([k, g]) => `<details class="x"><summary>${g.term}</summary><div class="x-body"><p><strong>What it means:</strong> ${g.what}</p><p><strong>Why it matters:</strong> ${g.why}</p><p><strong>How to read it:</strong> ${g.read}</p><p><strong>Example:</strong> ${g.ex}</p>${S.mode === "advanced" ? `<p><strong>Advanced:</strong> ${g.adv}</p>` : ""}<button class="btn sm" data-ask="Explain ${esc(g.term)} using a stock from Kosh">${ic("spark")} Explain with a real example</button></div></details>`).join("") : emptyState("search", "No terms found", "Try 'ratio' or 'debt'.");
      };
      if (pendingTerm) { $("#gq").value = D.glossary[pendingTerm].term; pendingTerm = null; }
      draw(); $("#gq").oninput = draw;
      if ($("#gq").value) { const d = $("#glist details"); if (d) d.open = true; }
    } else if (tab === "quiz") {
      const all = D.lessons.flatMap((l) => l.quiz.map((q, k) => ({ ...q, id: l.id + "-" + k })));
      body.innerHTML = `<div class="card" style="max-width:720px"><div class="spread" style="margin-bottom:10px"><h2>Quick quiz</h2><span class="tag" id="qscore"></span></div><div id="qlist">${all.map((q) => quizBlock(q, q.id)).join("")}</div><button class="btn" id="qreset">Reset answers</button></div>`;
      const score = () => { const el = $("#qscore"); if (!el) return; const ans = all.filter((q) => S.quiz[q.id] != null); el.textContent = `${ans.filter((q) => S.quiz[q.id] === q.a).length}/${all.length} correct`; };
      score(); body.addEventListener("click", (e) => { if (e.target.closest(".quiz-opt")) setTimeout(score); });
      $("#qreset").onclick = () => { all.forEach((q) => delete S.quiz[q.id]); save(); learn("quiz"); };
    } else if (tab === "scenarios") {
      body.innerHTML = `<div class="grid g3">${D.scenarios.map((s) => `<div class="card" data-scn="${s.id}"><div class="eyebrow">Scenario</div><h3 style="margin:6px 0 8px">${s.title}</h3><p>${s.setup}</p><div class="stack" style="gap:6px;margin-top:10px">${s.choices.map((c, i) => `<button class="quiz-opt" data-ch="${i}">${c.t}</button>`).join("")}</div><div class="chart-explain" hidden></div></div>`).join("")}</div>`;
      body.onclick = (e) => {
        const b = e.target.closest("[data-ch]"); if (!b) return;
        const card = b.closest("[data-scn]"); const s = D.scenarios.find((x) => x.id === card.dataset.scn); const ch = s.choices[+b.dataset.ch];
        $$(".quiz-opt", card).forEach((x) => x.classList.remove("correct", "wrong"));
        b.classList.add(ch.good ? "correct" : "wrong");
        const out = $(".chart-explain", card); out.hidden = false; out.innerHTML = `<strong class="${ch.good ? "up" : "down"}">${ch.good ? "Good thinking." : "Think again."}</strong> ${ch.r}`;
      };
    } else if (tab === "calc") {
      body.innerHTML = `<div class="grid g2">
        <section class="card"><div class="card-head"><h2>SIP calculator ${info("sip")}</h2></div>
          ${range("sip-amt", "Monthly investment", 500, 50000, 500, 5000, "₹")}${range("sip-r", "Expected yearly return", 1, 20, 0.5, 12, "%")}${range("sip-y", "Years", 1, 40, 1, 10, " yrs")}
          <div class="divider"></div><div class="grid g3"><div><div class="note">You invest</div><div class="calc-out" id="sip-inv"></div></div><div><div class="note">Est. gains</div><div class="calc-out up" id="sip-gain"></div></div><div><div class="note">Total value</div><div class="calc-out" id="sip-tot"></div></div></div>
          <div class="bar-split" style="margin-top:12px"><i id="sip-b1" style="background:var(--c2)"></i><i id="sip-b2" style="background:var(--c1)"></i></div><div class="chart" id="sip-chart" style="margin-top:12px"></div>
          <p class="note">Assumes a constant return — real returns vary year to year.</p></section>
        <section class="card"><div class="card-head"><h2>Lump sum & CAGR ${info("cagr")}</h2></div>
          ${range("ls-amt", "Amount invested", 1000, 1000000, 1000, 100000, "₹")}${range("ls-r", "Yearly return", -10, 25, 0.5, 10, "%")}${range("ls-y", "Years", 1, 30, 1, 5, " yrs")}
          <div class="divider"></div><div class="calc-out" id="ls-out"></div><p id="ls-note" class="muted"></p>
          <div class="divider"></div><h3 style="margin-bottom:8px">Rule of 72</h3><p class="muted" id="r72"></p></section>
        <section class="card"><div class="card-head"><h2>Risk vs return explorer ${info("beta")}</h2></div>
          ${range("rr-ret", "Expected yearly return", 2, 20, 0.5, 12, "%")}${range("rr-vol", "Volatility", 2, 50, 1, 25, "%")}${range("rr-amt", "Invested", 10000, 1000000, 10000, 100000, "₹")}
          <div class="divider"></div><p id="rr-out"></p><div class="chart" id="rr-chart"></div><p class="note">Range ≈ return ± 2 × volatility covers roughly 95% of one-year outcomes in a simple normal model. Real markets have fatter tails.</p></section>
        <section class="card"><div class="card-head"><h2>P/E & fair value playground ${info("pe")}</h2></div>
          <div class="field" style="margin-bottom:10px"><label for="pe-sym">Start from a demo stock</label><select class="input" id="pe-sym">${M.companies.map((c) => `<option value="${c.sym}">${c.sym} — ${esc(c.name)}</option>`).join("")}</select></div>
          ${range("pe-g", "Profit growth per year", -10, 40, 1, 15, "%")}${range("pe-x", "P/E in 3 years", 5, 80, 1, 25, "×")}
          <div class="divider"></div><p id="pe-out"></p><p class="note">Implied price = today's EPS grown for 3 years × your exit P/E. A teaching tool, not a price target.</p></section>
        <section class="card" style="grid-column:1/-1"><div class="card-head"><h2>Inflation: the silent tax ${info("inflation")}</h2><span class="tag up" id="inf-tag">Real data · World Bank</span></div>
          <div class="grid g2" style="align-items:start"><div><div class="chart" id="inf-chart"></div><p class="note" id="inf-src">Loading India's consumer price inflation…</p></div>
            <div><div class="grid g3" style="align-items:end"><div class="field"><label for="inf-amt">Cost today (₹)</label><input class="input num" id="inf-amt" inputmode="numeric" value="100000"></div><div class="field"><label for="inf-y">Years ahead</label><input class="input num" id="inf-y" inputmode="numeric" value="10"></div><div class="field"><label for="inf-r">Inflation %/yr</label><input class="input num" id="inf-r" inputmode="decimal" value=""></div></div>
              <div class="field" style="margin-top:10px"><label for="inf-fd">Your FD / savings rate %/yr</label><input class="input num" id="inf-fd" inputmode="decimal" value="7"></div>
              <div id="inf-out" style="margin-top:12px"></div></div></div></section>
        <section class="card" style="grid-column:1/-1"><div class="card-head"><h2>What you actually keep: charges & tax</h2><span class="tag info">India · listed shares, delivery</span></div>
          <div class="grid g4" style="align-items:end">
            <div class="field"><label for="tx-bp">Buy price (₹)</label><input class="input num" id="tx-bp" inputmode="decimal" value="500"></div>
            <div class="field"><label for="tx-sp">Sell price (₹)</label><input class="input num" id="tx-sp" inputmode="decimal" value="650"></div>
            <div class="field"><label for="tx-q">Shares</label><input class="input num" id="tx-q" inputmode="numeric" value="100"></div>
            <div class="field"><label for="tx-b">Brokerage per order</label><select class="input" id="tx-b"><option value="0">₹0 (many discount brokers)</option><option value="20" selected>₹20</option></select></div>
          </div>
          ${range("tx-m", "Months held", 1, 36, 1, 8, " mo")}
          <div class="grid g2" style="align-items:start"><div class="table-wrap"><table class="t" id="tx-table"></table></div><div id="tx-out"></div></div>
          <p class="note">Simplified, using rules for listed equity from 23 July 2024: short-term (≤12 months) gains taxed at 20%; long-term at 12.5% above ₹1.25 lakh a year; plus 4% cess. STT 0.1% on each side, stamp duty 0.015% on buy, exchange and SEBI fees, 18% GST on fees, and about ₹16 DP charge per sale. It ignores surcharge, losses you can set off and your other gains. Rates and broker charges change, so check them before relying on this.</p></section>
      </div>`;
      const v = (id) => +$("#" + id).value;
      const upd = () => {
        $$("[data-rv]").forEach((o) => { const inp = $("#" + o.dataset.rv); o.textContent = (inp.dataset.pre === "₹" ? F.inr(+inp.value, 0) : inp.value + inp.dataset.pre); });
        const P = v("sip-amt"), r = v("sip-r") / 1200, n = v("sip-y") * 12;
        const fv = r ? P * ((Math.pow(1 + r, n) - 1) / r) * (1 + r) : P * n, inv = P * n;
        $("#sip-inv").textContent = F.inr(inv, 0); $("#sip-gain").textContent = F.inr(fv - inv, 0); $("#sip-tot").textContent = F.inr(fv, 0);
        $("#sip-b1").style.cssText = `display:block;background:var(--c2);width:${(inv / fv) * 100}%`; $("#sip-b2").style.cssText = `display:block;background:var(--c1);flex:1`;
        const yrs = v("sip-y"); const lbl = [], a = [], b = [];
        const step = Math.max(1, Math.ceil(yrs / 8));
        for (let y = step; y <= yrs; y += step) { const m = y * 12; lbl.push("Y" + y); a.push(P * m); b.push((r ? P * ((Math.pow(1 + r, m) - 1) / r) * (1 + r) : P * m) - P * m); }
        C.bars($("#sip-chart"), { labels: lbl, groups: [{ name: "Invested", color: "var(--c2)", values: a }, { name: "Gains", color: "var(--c1)", values: b }], fmt: (x) => F.inr(x, 0), height: 150 });
        const L = v("ls-amt"), lr = v("ls-r") / 100, ly = v("ls-y"); const lf = L * Math.pow(1 + lr, ly);
        $("#ls-out").textContent = F.inr(lf, 0);
        $("#ls-note").innerHTML = `${F.inr(L, 0)} growing at ${v("ls-r")}% a year for ${ly} years ${lf >= L ? "grows" : "shrinks"} by <strong class="${F.cls(lf - L)}">${F.pct((lf / L - 1) * 100, 1)}</strong> in total. That's the power (or cost) of compounding.`;
        $("#r72").innerHTML = lr > 0 ? `At ${v("ls-r")}% a year, money roughly doubles every <strong>${(72 / v("ls-r")).toFixed(1)} years</strong> (72 ÷ ${v("ls-r")}).` : "With zero or negative returns, money never doubles.";
        const R = v("rr-ret"), V = v("rr-vol"), A = v("rr-amt");
        const lo = R - 2 * V, hi = R + 2 * V;
        $("#rr-out").innerHTML = `In a typical year you might expect between <strong class="${F.cls(lo)}">${F.pct(lo, 0)}</strong> and <strong class="up">${F.pct(hi, 0)}</strong> — i.e. ${F.inr(A * (1 + lo / 100), 0)} to ${F.inr(A * (1 + hi / 100), 0)}. ${V > 30 ? "That's a wide range: a bad year could hurt a lot." : V < 10 ? "A narrow range — steadier, usually with lower returns." : ""}`;
        const pts = []; for (let x = -60; x <= 80; x += 2) pts.push({ t: x, p: Math.exp(-((x - R) ** 2) / (2 * V * V)) });
        $("#rr-chart").innerHTML = `<svg viewBox="0 0 300 80" height="80" style="width:100%"><path d="${pts.map((p, i) => `${i ? "L" : "M"}${((p.t + 60) / 140) * 300},${76 - p.p * 70}`).join("")}" fill="none" stroke="var(--c1)" stroke-width="2"/><line x1="${(60 / 140) * 300}" x2="${(60 / 140) * 300}" y1="0" y2="80" stroke="var(--faint)" stroke-dasharray="3 3"/><text x="${(60 / 140) * 300 + 4}" y="12" font-size="9" fill="var(--faint)">0%</text></svg>`;
        const ps = $("#pe-sym").value, pm = M.metrics(ps), g = v("pe-g") / 100, x = v("pe-x");
        const eps3 = pm.eps * Math.pow(1 + g, 3), price3 = eps3 * x, ret = (price3 / pm.price - 1) * 100;
        $("#pe-out").innerHTML = `${ps} today: price ${F.inr(pm.price)}, EPS ${F.inr(pm.eps)}, P/E ${pm.pe ? pm.pe.toFixed(1) : "n/m"}.<br>If profit grows ${v("pe-g")}% a year, EPS in 3 years ≈ ${F.inr(eps3)}. At a P/E of ${x}, the implied price is <strong>${F.inr(price3)}</strong> — <strong class="${F.cls(ret)}">${F.pct(ret, 1)}</strong> from today. ${pm.pe && x < pm.pe ? "Notice: if the P/E shrinks, even good growth can mean weak returns." : ""}`;
      };
      const tax = () => {
        const n = (id) => Math.max(0, parseFloat(($("#" + id).value || "").replace(/[,₹\s]/g, "")) || 0);
        const bp = n("tx-bp"), sp = n("tx-sp"), q = Math.floor(n("tx-q")), mo = +$("#tx-m").value, bk = +$("#tx-b").value;
        if (!bp || !sp || !q) { $("#tx-out").innerHTML = `<p class="down">Enter buy price, sell price and shares.</p>`; $("#tx-table").innerHTML = ""; return; }
        const buyV = bp * q, sellV = sp * q, turn = buyV + sellV;
        const brk = bk * 2, stt = 0.001 * turn, stamp = 0.00015 * buyV, exch = 0.0000297 * turn, sebi = (turn * 10) / 1e7, gst = 0.18 * (brk + exch + sebi), dp = 15.93;
        const charges = brk + stt + stamp + exch + sebi + gst + dp;
        const gain = sellV - buyV - (charges - stt);
        const lt = mo > 12;
        const taxable = lt ? Math.max(0, gain - 125000) : Math.max(0, gain);
        const taxAmt = taxable * (lt ? 0.125 : 0.2) * 1.04;
        const paper = sellV - buyV, keep = paper - charges - taxAmt;
        const rows = [["Brokerage (2 orders)", brk], ["STT (0.1% each side)", stt], ["Stamp duty", stamp], ["Exchange + SEBI fees", exch + sebi], ["GST on fees", gst], ["DP charge", dp], [`${lt ? "LTCG 12.5%" : "STCG 20%"} + 4% cess`, taxAmt]];
        $("#tx-table").innerHTML = `<tbody><tr><td>Paper profit</td><td class="r num ${F.cls(paper)}">${F.signed(paper)}</td></tr>${rows.map(([l, v]) => `<tr><td class="muted">− ${l}</td><td class="r num">${F.inr(v)}</td></tr>`).join("")}<tr><td><strong>You keep</strong></td><td class="r num ${F.cls(keep)}"><strong>${F.signed(keep)}</strong></td></tr></tbody>`;
        const wait = !lt && gain > 0 ? (() => { const ltTax = Math.max(0, gain - 125000) * 0.125 * 1.04; return taxAmt - ltTax; })() : 0;
        $("#tx-out").innerHTML = `<div class="stat-mini"><span class="label">Share of profit you keep</span><span class="value ${F.cls(keep)}">${paper > 0 ? Math.max(0, (keep / paper) * 100).toFixed(1) + "%" : "—"}</span></div>
          <div class="chart-explain">${paper <= 0 ? "This is a loss. Charges still apply, but a capital loss can be set off against gains (not modelled here)." : lt ? `Held over 12 months, so this counts as <strong>long-term</strong>. The first ₹1.25 lakh of long-term gains each year is tax-free${gain <= 125000 ? ", so this gain owes no tax" : ""}.` : `Held 12 months or less, so this is <strong>short-term</strong> and taxed at 20%.${wait > 1 ? ` Holding past 12 months would have saved about <strong class="up">${F.inr(wait, 0)}</strong> in tax at the same price.` : ""}`} Frequent trading multiplies the charges, which is one more reason patience pays.</div>`;
      };
      const inflCalc = () => {
        const n = (id) => parseFloat(($("#" + id).value || "").replace(/[,₹\s]/g, ""));
        const amt = n("inf-amt"), y = n("inf-y"), r = n("inf-r"), fd = n("inf-fd");
        const out = $("#inf-out");
        if (!(amt > 0) || !(y > 0) || y > 60 || !(r >= 0) || r > 30) { out.innerHTML = `<p class="note">Enter a cost, years (1–60) and an inflation rate (0–30%).</p>`; return; }
        const fut = amt * Math.pow(1 + r / 100, y), power = amt / Math.pow(1 + r / 100, y);
        const real = fd >= 0 ? ((1 + fd / 100) / (1 + r / 100) - 1) * 100 : null;
        out.innerHTML = `<div class="grid g2" style="gap:10px"><div class="stat-mini"><span class="label">Same thing in ${y} yrs costs</span><span class="value">${F.inr(fut, 0)}</span></div><div class="stat-mini"><span class="label">${F.inr(amt, 0)} kept in cash will buy</span><span class="value down">${F.inr(power, 0)}</span><span class="note">worth of today's goods</span></div></div>
          ${real != null ? `<div class="chart-explain">A ${fd}% FD with ${r}% inflation gives a <strong>real</strong> return of <strong class="${F.cls(real)}">${F.pct(real, 2)}</strong> a year${real < 0 ? ": your money grows in rupees but buys less each year" : ""}. Tax on FD interest lowers this further.</div>` : ""}`;
      };
      window.KOSH_REAL.inflation().then((x) => {
        if (!$("#inf-chart")) return;
        const rows = x.rows.slice(-20);
        C.bars($("#inf-chart"), { labels: rows.map((r) => "'" + String(r[0]).slice(2)), groups: [{ name: "CPI inflation %", color: "var(--c4)", values: rows.map((r) => +r[1].toFixed(2)) }], fmt: (v) => v + "%", height: 180, label: "India CPI inflation by year" });
        $("#inf-src").innerHTML = `India's consumer price inflation, ${rows[0][0]}–${x.last[0]}. Latest: <strong>${x.last[1].toFixed(1)}%</strong> (${x.last[0]}); 10-year average ${x.avg10.toFixed(1)}%. Source: ${esc(x.source)}${x.stale ? " (cached copy)" : ""}.`;
        if (!$("#inf-r").value) $("#inf-r").value = x.avg10.toFixed(1);
        inflCalc();
      }).catch(() => {
        if (!$("#inf-chart")) return;
        $("#inf-tag").className = "tag warn"; $("#inf-tag").textContent = "Live data unavailable";
        $("#inf-chart").innerHTML = ""; $("#inf-src").textContent = "Couldn't reach the World Bank data source right now (it needs the Kosh server and internet). Enter your own inflation estimate to use the calculator.";
        inflCalc();
      });
      body.addEventListener("input", () => { upd(); tax(); inflCalc(); }); body.addEventListener("change", () => { upd(); tax(); inflCalc(); }); upd(); tax(); inflCalc();
    }
  }
  function range(id, label, min, max, step, val, pre) {
    return `<div class="field" style="margin-bottom:10px"><div class="spread"><label for="${id}">${label}</label><span class="num" data-rv="${id}"></span></div><input type="range" id="${id}" min="${min}" max="${max}" step="${step}" value="${val}" data-pre="${pre}"></div>`;
  }
  function quizBlock(q, id) {
    const ans = S.quiz[id];
    return `<div class="quiz" data-qid="${id}" data-a="${q.a}" style="margin-bottom:14px"><p style="color:var(--text);font-weight:600">${q.q}</p>${q.opts.map((o, i) => `<button class="quiz-opt ${ans != null && i === q.a ? "correct" : ""} ${ans === i && i !== q.a ? "wrong" : ""}" data-opt="${i}" ${ans != null ? "disabled" : ""}>${o}</button>`).join("")}<div class="note qwhy" ${ans == null ? "hidden" : ""}>${ans === q.a ? "✓ Correct. " : "✗ Not quite. "}${q.why}</div></div>`;
  }

  /* ============ PORTFOLIO / SIMULATOR ============ */
  function portfolio() {
    let tf = "1M";
    content.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">Virtual Investment Simulator</div><h1>Your demo portfolio</h1><p>Started with ${F.inr(S.portfolio.start, 0)} of fictional money. Buy, sell and learn — nothing is real.</p></div>
        <div class="row"><a class="btn primary" href="#/markets">${ic("plus")} Find stocks</a><button class="btn ghost" id="pf-reset">Reset simulator</button></div></div>
      <div class="grid g4" id="pf-top" style="margin-bottom:16px"></div>
      <div class="grid g-main">
        <div class="stack" style="gap:16px">
          <section class="card"><div class="card-head"><h2>Holdings performance</h2>${seg("ptf", ["1W", "1M", "6M", "1Y"], tf)}</div><div class="chart" id="pf-chart"></div><div class="chart-explain" id="pf-explain"></div></section>
          <section class="card"><div class="card-head"><h2>Holdings</h2></div><div class="table-wrap"><table class="t" id="pf-table"></table></div></section>
          <section class="card"><div class="card-head"><h2>Transaction history</h2></div><div id="pf-tx"></div></section>
        </div>
        <div class="stack" style="gap:16px">
          <section class="card"><div class="card-head"><h2>Allocation by sector ${info("diversification")}</h2></div><div class="row" style="justify-content:center" id="pf-donut"></div><div class="legend" id="pf-leg" style="justify-content:center;margin-top:10px"></div></section>
          <section class="card ai"><div class="card-head"><h2>${ic("spark", 'width="18" height="18"')} Portfolio coach</h2><span class="ai-tag">AI</span></div><div id="pf-coach" class="ai-text"></div></section>
        </div>
      </div>`;
    const draw = (force) => {
      const p = portfolioState();
      $("#pf-top").innerHTML = [
        ["Total value", F.inr(p.total, 0), `<span class="${F.cls(p.overall)}">${F.pct(p.overall)} since start</span>`],
        ["Invested value", F.inr(p.invested, 0), `Cost ${F.inr(p.cost, 0)}`],
        ["Unrealised P&L", `<span class="${F.cls(p.pnl)}">${F.signed(p.pnl, 0)}</span>`, `<span class="${F.cls(p.pnlPct)}">${F.pct(p.pnlPct)}</span> · today <span class="${F.cls(p.day)}">${F.signed(p.day, 0)}</span>`],
        ["Virtual cash", F.inr(p.cash, 0), "Available to invest"],
      ].map(([l, v, s]) => `<div class="card stat"><div class="label">${l}</div><div class="value">${v}</div><div class="note">${s}</div></div>`).join("");
      setHTML("#pf-table", p.holdings.length ? `<thead><tr><th>Stock</th><th class="r">Qty</th><th class="r">Avg cost</th><th class="r">Price</th><th class="r">Value</th><th class="r">P&L</th><th class="r">Weight</th><th></th></tr></thead><tbody>` +
        p.holdings.sort((a, b) => b.value - a.value).map((h) => { const c = M.bySym(h.sym).c; return `<tr><td><a href="#/stock/${h.sym}" class="sym" style="color:var(--text);text-decoration:none">${logo(c)}<div><div class="sym-name">${h.sym}</div><div class="sym-sub">${esc(c.sector)}</div></div></a></td><td class="r num">${h.qty}</td><td class="r num">${F.inr(h.avg)}</td><td class="r">${priceCell(h.sym)}<div>${chgCell(h.sym)}</div></td><td class="r num">${F.inr(h.value, 0)}</td><td class="r"><span class="change ${F.cls(h.pnl)}">${F.signed(h.pnl, 0)}</span><div class="note ${F.cls(h.pnlPct)}">${F.pct(h.pnlPct)}</div></td><td class="r num">${((h.value / p.invested) * 100).toFixed(1)}%</td><td class="r"><div class="row" style="justify-content:flex-end;gap:4px;flex-wrap:nowrap"><button class="btn sm" data-trade="${h.sym}" data-side="BUY">Buy</button><button class="btn sm" data-trade="${h.sym}" data-side="SELL">Sell</button></div></td></tr>`; }).join("") + "</tbody>"
        : `<tbody><tr><td>${emptyState("wallet", "No holdings yet", "Open any stock and press “Buy (demo)” to place a simulated order.")}</td></tr></tbody>`, force);
      const sectors = {};
      p.holdings.forEach((h) => { const s = M.bySym(h.sym).c.sector; sectors[s] = (sectors[s] || 0) + h.value; });
      if (p.cash > 0) sectors["Cash"] = p.cash;
      const pal = ["var(--c1)", "var(--c2)", "var(--c3)", "var(--c4)", "var(--c5)", "var(--gold)", "var(--down)", "var(--faint)"];
      const items = Object.entries(sectors).map(([label, value], i) => ({ label, value, color: label === "Cash" ? "var(--surface-3)" : pal[i % pal.length] }));
      C.donut($("#pf-donut"), { items, center: ["Total", F.compact(p.total)] });
      $("#pf-leg").innerHTML = items.map((i) => `<span><i style="background:${i.color}"></i>${esc(i.label)} ${((i.value / p.total) * 100).toFixed(0)}%</span>`).join("");
      // coach
      const tips = [];
      const nSect = Object.keys(sectors).filter((s) => s !== "Cash").length;
      const top = p.holdings[0];
      if (!p.holdings.length) tips.push("You're 100% in cash. Pick 3–5 companies from different sectors to see how diversification works.");
      else {
        if (top && top.value / p.invested > 0.4) tips.push(`<strong>Concentration:</strong> ${top.sym} is ${((top.value / p.invested) * 100).toFixed(0)}% of your invested money. If it fell 30%, your portfolio would drop ~${((top.value / p.invested) * 30).toFixed(0)}%.`);
        tips.push(`<strong>Diversification:</strong> you hold ${p.holdings.length} stock${p.holdings.length > 1 ? "s" : ""} across ${nSect} sector${nSect > 1 ? "s" : ""}. ${nSect < 3 ? "Adding different sectors reduces the chance one event hurts everything." : "Good spread across sectors."}`);
        const wr = p.holdings.reduce((a, h) => a + (h.value / p.invested) * AI.risk(h.sym).score, 0);
        tips.push(`<strong>Weighted risk score:</strong> ${wr.toFixed(0)}/100 — ${wr < 40 ? "on the cautious side" : wr < 62 ? "moderate" : "aggressive; expect big swings"}.`);
        const cashPct = (p.cash / p.total) * 100;
        tips.push(`<strong>Cash:</strong> ${cashPct.toFixed(0)}% of your portfolio. ${cashPct > 60 ? "Plenty of room to experiment." : cashPct < 5 ? "Little cash left — a buffer helps you avoid forced selling." : ""}`);
      }
      setHTML("#pf-coach", tips.map((t) => `<p>${t}</p>`).join("") + `<button class="btn sm" data-ask="How is my portfolio doing?">${ic("spark")} Ask the coach</button>`, force);
      setHTML("#pf-tx", S.portfolio.txns.length ? S.portfolio.txns.slice(0, 20).map((t) => `<div class="list-item"><span class="tag ${t.side === "BUY" ? "up" : "down"}">${t.side}</span><div class="grow"><div class="sym-name">${t.qty} × ${t.sym} @ ${F.inr(t.price)}</div><div class="note">${F.date(t.t, { day: "numeric", month: "short" })} ${F.time(t.t)}${t.note ? " · " + esc(t.note) : ""}</div></div><div class="end num">${F.inr(t.qty * t.price, 0)}</div></div>`).join("") : emptyState("wallet", "No transactions", "Your simulated orders will appear here."), force);
    };
    const drawChart = () => {
      const p = portfolioState();
      if (!p.holdings.length) { $("#pf-chart").innerHTML = emptyState("markets", "Nothing to chart yet", "Buy a demo stock to see performance."); $("#pf-explain").textContent = ""; return; }
      const base = p.holdings.map((h) => ({ h, s: M.series(h.sym, tf) }));
      const len = Math.min(...base.map((b) => b.s.length));
      const data = [];
      for (let i = 0; i < len; i++) data.push({ t: base[0].s[base[0].s.length - len + i].t, p: base.reduce((a, b) => a + b.h.qty * b.s[b.s.length - len + i].p, 0) });
      C.line($("#pf-chart"), { series: [{ name: "Holdings", color: data.at(-1).p >= data[0].p ? "var(--up)" : "var(--down)", data }], tf, height: 240, label: "Holdings value" });
      $("#pf-explain").innerHTML = `Value of your <em>current</em> holdings over ${tf}: ${F.inr(data[0].p, 0)} → ${F.inr(data.at(-1).p, 0)} (<span class="${F.cls(data.at(-1).p - data[0].p)}">${F.pct((data.at(-1).p / data[0].p - 1) * 100)}</span>). This shows how today's mix would have behaved, using simulated prices.`;
    };
    draw(); drawChart();
    $('[data-seg="ptf"]').onclick = (e) => { const b = e.target.closest("button"); if (!b) return; tf = b.dataset.v; $$('[data-seg="ptf"] button').forEach((x) => x.setAttribute("aria-pressed", String(x === b))); drawChart(); };
    $("#pf-reset").onclick = () => {
      const m = modal(`<div class="modal-head"><h2>Reset simulator?</h2><button class="icon-btn" data-close aria-label="Close">${ic("x")}</button></div><p class="muted">This clears your demo holdings and transactions and restores ${F.inr(S.portfolio.start, 0)} of virtual cash. Watchlist, alerts and lessons stay.</p><div class="row" style="justify-content:flex-end;margin-top:14px"><button class="btn" data-close>Cancel</button><button class="btn sell" id="do-reset">Reset</button></div>`);
      $("#do-reset", m).onclick = () => { S.portfolio = { start: 1000000, cash: 1000000, holdings: {}, txns: [] }; save(); m.close(); route(); toast("Simulator reset to ₹10,00,000 virtual cash."); };
    };
    page.live = () => { draw(); };
    page.onTrade = () => { draw(true); drawChart(); };
  }

  /* ============ WATCHLIST ============ */
  function watchlist() {
    content.innerHTML = `<div class="page-head"><div><div class="eyebrow">Tracking</div><h1>Watchlist</h1><p>Stocks you're following. Add from search, Markets or any stock page.</p></div>
      <div class="row"><select class="input" id="wl-add" aria-label="Add stock to watchlist" style="min-width:220px"><option value="">+ Add a stock…</option></select><button class="btn" data-alert-type="watch" data-alert="">${ic("bell")} Alert on big moves</button></div></div>
      <div class="card"><div id="wl-body"></div></div>`;
    const draw = () => {
      $("#wl-add").innerHTML = `<option value="">+ Add a stock…</option>` + M.companies.filter((c) => !isWatched(c.sym)).map((c) => `<option value="${c.sym}">${c.sym} — ${esc(c.name)}</option>`).join("");
      $("#wl-body").innerHTML = S.watchlist.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>Stock</th><th class="r">Price</th><th class="r">Day</th><th>1M</th><th class="r">P/E</th><th class="r">Risk</th><th></th></tr></thead><tbody>${S.watchlist.map((s) => { const c = M.bySym(s).c, m = M.metrics(s); return `<tr class="click" tabindex="0" data-go="#/stock/${s}"><td><div class="sym">${logo(c)}<div><div class="sym-name">${s}</div><div class="sym-sub">${esc(c.name)}</div></div></div></td><td class="r">${priceCell(s)}</td><td class="r">${chgCell(s)}</td><td>${C.spark(M.series(s, "1M"), m.ret1M >= 0 ? "var(--up)" : "var(--down)")}</td><td class="r num">${m.pe ? m.pe.toFixed(1) : "—"}</td><td class="r">${riskTag(s)}</td><td class="r"><button class="btn sm ghost" data-watch="${s}" aria-label="Remove ${s}">${ic("trash")} Remove</button></td></tr>`; }).join("")}</tbody></table></div>`
        : emptyState("star", "Your watchlist is empty", "Use “Add a stock” above, or tap ☆ anywhere in the app.");
    };
    draw();
    $("#wl-add").onchange = (e) => { const s = e.target.value; if (s) { toggleWatch(s); } };
    page.onWatch = draw;
  }

  /* ============ ALERTS ============ */
  const ALERT_TYPES = { above: "Price rises above", below: "Price falls below", pct: "Day move of at least ±", news: "New company news", watch: "Any watchlist stock moves ±", portfolio: "Portfolio value changes ±" };
  function alertText(a) {
    const s = a.sym ? `${a.sym} · ` : "";
    if (a.type === "above" || a.type === "below") return `${s}${ALERT_TYPES[a.type]} ${F.inr(a.value)}`;
    if (a.type === "news") return `${s}${ALERT_TYPES.news}`;
    if (a.type === "portfolio") return `${ALERT_TYPES.portfolio}${a.value}% from ${F.inr(a.base, 0)}`;
    return `${s}${ALERT_TYPES[a.type]}${a.value}%`;
  }
  function alerts() {
    content.innerHTML = `<div class="page-head"><div><div class="eyebrow">Smart alerts</div><h1>Alerts & notifications</h1><p>Get notified inside Kosh when simulated prices, news or your portfolio change.</p></div><button class="btn primary" data-alert="">${ic("plus")} New alert</button></div>
      <div class="grid g2"><section class="card"><div class="card-head"><h2>Your alerts</h2><span class="note">Checked on every simulated tick</span></div><div id="al-list"></div></section>
      <section class="card"><div class="card-head"><h2>Recent notifications</h2><button class="btn sm ghost" id="al-clear">Clear all</button></div><div id="al-notifs"></div></section></div>`;
    const draw = () => {
      $("#al-list").innerHTML = S.alerts.length ? S.alerts.map((a) => `<div class="list-item"><span class="tag ${a.fired ? "info" : a.active ? "up" : ""}">${a.fired ? "Triggered" : a.active ? "Active" : "Paused"}</span><div class="grow"><div style="font-weight:600">${alertText(a)}</div><div class="note">${a.fired ? "Fired " + F.time(a.fired) : "Created " + F.date(a.created, { day: "numeric", month: "short" })}</div></div>
        <div class="row" style="gap:4px;flex-wrap:nowrap">${a.fired ? `<button class="btn sm" data-rearm="${a.id}">Re-arm</button>` : `<button class="btn sm" data-toggle="${a.id}">${a.active ? "Pause" : "Resume"}</button>`}<button class="icon-btn" style="width:32px;height:32px" data-del="${a.id}" aria-label="Delete alert">${ic("trash")}</button></div></div>`).join("")
        : emptyState("bell", "No alerts yet", "Create one to be notified about price moves, news or portfolio changes.");
      $("#al-notifs").innerHTML = S.notifs.length ? S.notifs.slice(0, 15).map((n) => `<div class="notif"><span class="dot" style="color:var(--${n.kind === "down" ? "down" : n.kind === "up" ? "up" : "accent-text"});margin-top:6px"></span><div><div class="t">${esc(n.title)}</div><div class="d">${esc(n.body)}</div><div class="note">${F.time(n.t)}</div></div></div>`).join("") : emptyState("bell", "All quiet", "Notifications will show up here.");
    };
    draw();
    content.onclick = (e) => {
      const t = e.target.closest("[data-toggle],[data-del],[data-rearm]"); if (!t) return;
      const id = t.dataset.toggle || t.dataset.del || t.dataset.rearm;
      const a = S.alerts.find((x) => x.id === id);
      if (t.dataset.del) S.alerts = S.alerts.filter((x) => x.id !== id);
      else if (t.dataset.rearm) { a.fired = null; a.active = true; if (a.type === "portfolio") a.base = portfolioState().total; }
      else a.active = !a.active;
      save(); draw();
    };
    $("#al-clear").onclick = () => { S.notifs = []; save(); renderBadge(); draw(); };
    page.onAlerts = draw;
    page.cleanup = () => { content.onclick = null; };
  }
  function alertModal(sym, type) {
    sym = sym || page.sym || S.watchlist[0] || "NIMB";
    type = type || "above";
    const price = M.bySym(sym).price;
    const m = modal(`<div class="modal-head"><h2>Create alert</h2><button class="icon-btn" data-close aria-label="Close">${ic("x")}</button></div>
      <form id="af" class="stack" novalidate>
        <div class="field"><label for="a-type">Alert me when</label><select class="input" id="a-type">${Object.entries(ALERT_TYPES).map(([k, l]) => `<option value="${k}" ${k === type ? "selected" : ""}>${l.replace(/ ±$| at least ±$/, "")}${k === "pct" ? " (%)" : k === "watch" || k === "portfolio" ? " (%)" : ""}</option>`).join("")}</select></div>
        <div class="field" id="a-sym-f"><label for="a-sym">Stock</label><select class="input" id="a-sym">${M.companies.map((c) => `<option value="${c.sym}" ${c.sym === sym ? "selected" : ""}>${c.sym} — ${esc(c.name)}</option>`).join("")}</select></div>
        <div class="field" id="a-val-f"><label for="a-val" id="a-val-l">Value</label><input class="input" id="a-val" inputmode="decimal" /><div class="err" id="a-err"></div></div>
        <p class="note" id="a-hint"></p>
        <div class="row" style="justify-content:flex-end"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary">Create alert</button></div>
      </form>`);
    const sync = () => {
      const t = $("#a-type", m).value, s = $("#a-sym", m).value, p = M.bySym(s).price;
      $("#a-sym-f", m).hidden = t === "watch" || t === "portfolio";
      $("#a-val-f", m).hidden = t === "news";
      $("#a-val-l", m).textContent = t === "above" || t === "below" ? "Target price (₹)" : "Percent (%)";
      if (!$("#a-val", m).dataset.touched) $("#a-val", m).value = t === "above" ? (p * 1.01).toFixed(2) : t === "below" ? (p * 0.99).toFixed(2) : t === "news" ? "" : t === "portfolio" ? "0.5" : "1.5";
      $("#a-hint", m).textContent = t === "above" || t === "below" ? `${s} is at ${F.inr(p)} now (simulated).` : t === "news" ? "You'll be notified when a new demo scenario mentions this company." : t === "portfolio" ? `Current simulated value: ${F.inr(portfolioState().total, 0)}.` : t === "watch" ? `Watches: ${S.watchlist.join(", ") || "(empty watchlist)"}` : "Fires when the stock's change vs previous close crosses this size, up or down.";
    };
    sync();
    $("#a-type", m).onchange = () => { delete $("#a-val", m).dataset.touched; sync(); };
    $("#a-sym", m).onchange = () => { delete $("#a-val", m).dataset.touched; sync(); };
    $("#a-val", m).oninput = (e) => { e.target.dataset.touched = 1; $("#a-err", m).textContent = ""; };
    $("#af", m).onsubmit = (e) => {
      e.preventDefault();
      const t = $("#a-type", m).value, s = $("#a-sym", m).value, v = parseFloat($("#a-val", m).value);
      if (t !== "news" && (!isFinite(v) || v <= 0)) { $("#a-err", m).textContent = "Enter a positive number."; return; }
      if (t === "above" && v <= M.bySym(s).price) { $("#a-err", m).textContent = `Must be above the current price (${F.inr(M.bySym(s).price)}).`; return; }
      if (t === "below" && v >= M.bySym(s).price) { $("#a-err", m).textContent = `Must be below the current price (${F.inr(M.bySym(s).price)}).`; return; }
      if (t === "watch" && !S.watchlist.length) { $("#a-err", m).textContent = "Add stocks to your watchlist first."; return; }
      const a = { id: uid(), type: t, sym: t === "watch" || t === "portfolio" ? null : s, value: t === "news" ? null : v, active: true, created: Date.now() };
      if (t === "portfolio") a.base = portfolioState().total;
      S.alerts.unshift(a); save(); m.close(); award("alert");
      toast(`Alert created: ${esc(alertText(a))}`, "up");
      page.onAlerts && page.onAlerts();
    };
  }
  const watchFired = {};
  function checkAlerts() {
    let changed = false;
    for (const a of S.alerts) {
      if (!a.active || a.fired) continue;
      let hit = null;
      if (a.type === "above" || a.type === "below" || a.type === "pct") {
        const m = M.metrics(a.sym);
        if (a.type === "above" && m.price >= a.value) hit = [`${a.sym} crossed ${F.inr(a.value)}`, `Now ${F.inr(m.price)} (simulated).`, "up"];
        if (a.type === "below" && m.price <= a.value) hit = [`${a.sym} fell below ${F.inr(a.value)}`, `Now ${F.inr(m.price)} (simulated).`, "down"];
        if (a.type === "pct" && Math.abs(m.chgPct) >= a.value) hit = [`${a.sym} moved ${F.pct(m.chgPct)} today`, `Your ±${a.value}% alert triggered. Tap the stock to see why it may be moving.`, m.chgPct > 0 ? "up" : "down"];
      } else if (a.type === "watch") {
        for (const s of S.watchlist) {
          const m = M.metrics(s);
          if (Math.abs(m.chgPct) >= a.value && !watchFired[a.id + s]) { watchFired[a.id + s] = 1; hit = [`Watchlist: ${s} ${F.pct(m.chgPct)}`, `Crossed your ±${a.value}% watchlist alert.`, m.chgPct > 0 ? "up" : "down"]; a.sym = s; break; }
        }
      } else if (a.type === "portfolio") {
        const tot = portfolioState().total, ch = (tot / a.base - 1) * 100;
        if (Math.abs(ch) >= a.value) hit = [`Portfolio ${F.pct(ch)}`, `Your simulated portfolio moved from ${F.inr(a.base, 0)} to ${F.inr(tot, 0)}.`, ch > 0 ? "up" : "down"];
      }
      if (hit) {
        a.fired = Date.now(); changed = true;
        notify(hit[0], hit[1], hit[2], a.sym ? "#/stock/" + a.sym : "#/portfolio");
        if (a.type === "watch") a.sym = null;
      }
    }
    if (changed) { save(); page.onAlerts && page.onAlerts(); }
  }
  // Release demo news over the session so news alerts can be demonstrated.
  const t0 = Date.now();
  function releaseNews() {
    for (const n of extraNews) {
      if (!n.published && Date.now() - t0 >= n.at * 1000) {
        n.published = Date.now();
        const watching = S.alerts.filter((a) => a.type === "news" && a.active && !a.fired && n.syms.includes(a.sym));
        watching.forEach((a) => { a.fired = Date.now(); });
        if (watching.length) { save(); notify(`News: ${n.syms.join(", ")}`, n.h + " (demo scenario)", n.sent === "neg" ? "down" : "up", "#/news/" + n.id); }
        else if (n.syms.some(isWatched)) notify(`Watchlist news: ${n.syms.filter(isWatched).join(", ")}`, n.h + " (demo scenario)", n.sent === "neg" ? "down" : "up", "#/news/" + n.id);
        page.onNews && page.onNews(); page.onAlerts && page.onAlerts();
      }
    }
  }

  /* ============ ORDER TICKET ============ */
  function tradeModal(sym, side = "BUY") {
    const c = M.bySym(sym).c;
    let st = { side, step: "form" };
    const m = modal(`<div id="tk"></div>`);
    const holding = () => S.portfolio.holdings[sym]?.qty || 0;
    const FEE = 20;
    const draw = (qty = 1, err = "") => {
      const price = M.bySym(sym).price;
      const amt = qty * price;
      const tot = st.side === "BUY" ? amt + FEE : amt - FEE;
      $("#tk", m).innerHTML = st.step === "form" ? `
        <div class="modal-head"><div class="row">${logo(c)}<div><h2>${st.side === "BUY" ? "Buy" : "Sell"} ${c.sym}</h2><div class="note">${esc(c.name)}</div></div></div><button class="icon-btn" data-close aria-label="Close">${ic("x")}</button></div>
        <div class="seg" style="width:100%;margin-bottom:14px" role="group" aria-label="Order side"><button style="flex:1" data-side="BUY" aria-pressed="${st.side === "BUY"}">Buy</button><button style="flex:1" data-side="SELL" aria-pressed="${st.side === "SELL"}">Sell</button></div>
        <div class="grid g2" style="gap:10px;margin-bottom:12px"><div class="stat-mini"><span class="label">Market price</span><span class="value" data-p="${sym}">${F.inr(price)}</span></div><div class="stat-mini"><span class="label">${st.side === "BUY" ? "Virtual cash" : "You hold"}</span><span class="value">${st.side === "BUY" ? F.inr(S.portfolio.cash, 0) : holding() + " shares"}</span></div></div>
        <form id="tkf" class="stack" novalidate>
          <div class="field"><label for="tk-q">Quantity (shares)</label><div class="row" style="flex-wrap:nowrap"><button type="button" class="btn" data-q="-1" aria-label="Decrease">−</button><input class="input num" id="tk-q" type="text" inputmode="numeric" autocomplete="off" value="${qty}" style="text-align:center" /><button type="button" class="btn" data-q="1" aria-label="Increase">+</button>${st.side === "SELL" ? `<button type="button" class="btn sm ghost" data-q="max">All</button>` : ""}</div><div class="err" role="alert">${err}</div></div>
          <div class="stack" style="gap:4px;font-size:13px"><div class="spread"><span class="muted">Order value</span><span class="num">${F.inr(amt)}</span></div><div class="spread"><span class="muted">Illustrative charges</span><span class="num">${F.inr(FEE)}</span></div><div class="spread" style="font-weight:700"><span>${st.side === "BUY" ? "Total debit" : "Net credit"}</span><span class="num">${F.inr(tot)}</span></div></div>
          ${st.side === "BUY" && amt > 0 ? `<p class="note">${((amt / portfolioState().total) * 100).toFixed(1)}% of your portfolio. ${amt / portfolioState().total > 0.2 ? "⚠ That's a large single position — consider diversifying." : ""}</p>` : ""}
          <button class="btn ${st.side === "BUY" ? "buy" : "sell"}" style="width:100%">Review order</button>
          <p class="note" style="text-align:center">Simulated market order with virtual money. No real trade is placed.</p>
        </form>` : st.step === "review" ? `
        <div class="modal-head"><h2>Confirm demo order</h2><button class="icon-btn" data-close aria-label="Close">${ic("x")}</button></div>
        <div class="card" style="background:var(--surface-2)"><div class="spread"><span class="muted">Action</span><strong class="${st.side === "BUY" ? "up" : "down"}">${st.side} ${qty} × ${c.sym}</strong></div><div class="spread"><span class="muted">Price</span><span class="num">${F.inr(price)}</span></div><div class="spread"><span class="muted">Charges</span><span class="num">${F.inr(FEE)}</span></div><div class="divider"></div><div class="spread" style="font-weight:700"><span>${st.side === "BUY" ? "Total debit" : "Net credit"}</span><span class="num">${F.inr(tot)}</span></div></div>
        <p class="note" style="margin-top:10px">Price may move slightly before you confirm — the order fills at the simulated price at that moment.</p>
        <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn" id="tk-back">Back</button><button class="btn ${st.side === "BUY" ? "buy" : "sell"}" id="tk-ok">Confirm ${st.side === "BUY" ? "buy" : "sell"}</button></div>` : `
        <div style="text-align:center;padding:10px 0"><div class="brand-mark" style="margin:0 auto 12px;width:48px;height:48px;background:var(--up)">${ic("check", 'width="24" height="24"')}</div><h2>Demo order filled</h2><p class="muted">${st.fill}</p>
        <div class="row" style="justify-content:center;margin-top:14px"><button class="btn" data-close>Close</button><a class="btn primary" href="#/portfolio" data-close>View portfolio</a></div></div>`;
      const tkf = $("#tkf", m);
      if (tkf) {
        const qIn = $("#tk-q", m);
        qIn.focus(); qIn.select();
        qIn.oninput = () => { const v = qIn.value; const n = parseInt(v, 10); $("#tk", m).querySelector(".err").textContent = ""; if (n > 0) { const pos = qIn.selectionStart; draw(n); const ni = $("#tk-q", m); ni.value = v; ni.setSelectionRange(pos, pos); } };
        tkf.onsubmit = (e) => {
          e.preventDefault();
          const raw = qIn.value.trim(); const n = Number(raw);
          if (!/^\d+$/.test(raw) || n < 1) return draw(1, "Enter a whole number of shares (1 or more).");
          if (st.side === "BUY" && n * M.bySym(sym).price + FEE > S.portfolio.cash) return draw(n, `Not enough virtual cash. Max you can buy: ${Math.max(0, Math.floor((S.portfolio.cash - FEE) / M.bySym(sym).price))} shares.`);
          if (st.side === "SELL" && n > holding()) return draw(n, holding() ? `You only hold ${holding()} shares.` : `You don't hold any ${sym}.`);
          st.step = "review"; st.qty = n; draw(n);
        };
      }
      const back = $("#tk-back", m); if (back) back.onclick = () => { st.step = "form"; draw(st.qty); };
      const ok = $("#tk-ok", m);
      if (ok) ok.onclick = () => {
        const p = M.bySym(sym).price, n = st.qty, H = S.portfolio.holdings;
        if (st.side === "BUY") {
          if (n * p + FEE > S.portfolio.cash) { st.step = "form"; return draw(n, "Price moved — not enough cash now."); }
          const h = H[sym] || { qty: 0, avg: 0 };
          h.avg = +((h.qty * h.avg + n * p) / (h.qty + n)).toFixed(2); h.qty += n; H[sym] = h;
          S.portfolio.cash = +(S.portfolio.cash - n * p - FEE).toFixed(2);
        } else {
          if (n > holding()) { st.step = "form"; return draw(n, "Holding changed."); }
          const realised = (p - H[sym].avg) * n;
          H[sym].qty -= n; if (!H[sym].qty) delete H[sym];
          S.portfolio.cash = +(S.portfolio.cash + n * p - FEE).toFixed(2);
          st.realised = realised;
        }
        S.portfolio.txns.unshift({ id: uid(), t: Date.now(), sym, side: st.side, qty: n, price: +p.toFixed(2) });
        setTimeout(() => { award("first_trade"); if (new Set(Object.keys(S.portfolio.holdings).map((x) => M.bySym(x).c.sector)).size >= 4) award("diversified"); }, 600);
        save();
        st.fill = `${st.side === "BUY" ? "Bought" : "Sold"} ${n} ${sym} at ${F.inr(p)}${st.side === "SELL" ? ` · realised P&L <span class="${F.cls(st.realised)}">${F.signed(st.realised)}</span>` : ""}. Remaining virtual cash: ${F.inr(S.portfolio.cash, 0)}.`;
        st.step = "done"; draw();
        page.onTrade && page.onTrade();
      };
    };
    m.addEventListener("click", (e) => {
      const sd = e.target.closest("[data-side]"); if (sd && st.step === "form") { st.side = sd.dataset.side; draw(1); }
      const q = e.target.closest("[data-q]");
      if (q) { const cur = parseInt($("#tk-q", m).value, 10) || 0; const n = q.dataset.q === "max" ? holding() || 1 : Math.max(1, cur + +q.dataset.q); draw(n); }
    });
    draw(1);
  }

  /* ---------------- watchlist toggle ---------------- */
  function toggleWatch(s) {
    if (isWatched(s)) { S.watchlist = S.watchlist.filter((x) => x !== s); toast(`${s} removed from watchlist`); }
    else { S.watchlist.push(s); toast(`${s} added to watchlist ★`, "up"); }
    save();
    $$(`[data-watch="${s}"].star`).forEach((b) => { b.setAttribute("aria-pressed", String(isWatched(s))); b.setAttribute("aria-label", (isWatched(s) ? "Remove from" : "Add to") + " watchlist"); });
    page.onWatch && page.onWatch();
  }

  /* ---------------- search ---------------- */
  const qIn = $("#q"), sug = $("#suggest");
  let sel = -1, items = [];
  const pages = [["Dashboard", "#/"], ["My Plan", "#/journey"], ["Crash Test", "#/crash"], ["Live League", "#/league"], ["Tip Check", "#/tipcheck"], ["Time Machine", "#/timemachine"], ["Mutual Funds (real data)", "#/funds"], ["Live Headlines", "#/headlines"], ["Markets", "#/markets"], ["Compare", "#/compare"], ["News & Insights", "#/news"], ["Learning Centre", "#/learn"], ["Calculators", "#/learn/calc"], ["Simulator", "#/portfolio"], ["Watchlist", "#/watchlist"], ["Alerts", "#/alerts"]];
  function renderSuggest() {
    const q = qIn.value.trim().toLowerCase();
    if (!q) { sug.classList.remove("open"); $(".search").setAttribute("aria-expanded", "false"); return; }
    const st = M.companies.filter((c) => c.sym.toLowerCase().includes(q) || c.name.toLowerCase().includes(q) || c.sector.toLowerCase().includes(q)).slice(0, 6);
    const gt = Object.entries(D.glossary).filter(([k, g]) => g.term.toLowerCase().includes(q) || k === q).slice(0, 3);
    const pg = pages.filter(([l]) => l.toLowerCase().includes(q)).slice(0, 2);
    items = [...st.map((c) => ({ go: "#/stock/" + c.sym })), ...gt.map(([k]) => ({ term: k })), ...pg.map(([, h]) => ({ go: h })), { ask: qIn.value.trim() }];
    let i = 0;
    const opt = (inner) => `<div class="suggest-item" role="option" id="sg${i}" data-i="${i++}" aria-selected="false">${inner}</div>`;
    sug.innerHTML =
      (st.length ? `<div class="suggest-group">Stocks</div>` + st.map((c) => { const m = M.metrics(c.sym); return opt(`${logo(c)}<div style="flex:1;min-width:0"><div class="sym-name">${c.sym} <span class="muted" style="font-weight:400">${esc(c.name)}</span></div><div class="sym-sub">${esc(c.sector)}</div></div><div class="end"><div class="num">${F.inr(m.price)}</div><div class="change ${F.cls(m.chgPct)}">${F.pct(m.chgPct)}</div></div>`); }).join("") : "") +
      (gt.length ? `<div class="suggest-group">Learn the term</div>` + gt.map(([, g]) => opt(`<span class="info-btn" aria-hidden="true">i</span><div><div class="sym-name">${g.term}</div><div class="sym-sub">${esc(g.what.slice(0, 70))}…</div></div>`)).join("") : "") +
      (pg.length ? `<div class="suggest-group">Pages</div>` + pg.map(([l]) => opt(`<div class="sym-name">${l}</div>`)).join("") : "") +
      `<div class="suggest-group">Assistant</div>` + opt(`${ic("spark", 'width="16" height="16" style="color:var(--accent-text)"')}<div>Ask Kosh AI: “${esc(qIn.value.trim())}”</div>`);
    sel = -1; sug.classList.add("open"); $(".search").setAttribute("aria-expanded", "true");
  }
  function pick(i) {
    const it = items[i]; if (!it) return;
    qIn.value = ""; sug.classList.remove("open"); qIn.blur();
    if (it.go) location.hash = it.go;
    else if (it.term) { pendingTerm = it.term; if (location.hash === "#/learn/glossary") route(); else location.hash = "#/learn/glossary"; }
    else if (it.ask) askChat(it.ask);
  }
  qIn.addEventListener("input", renderSuggest);
  qIn.addEventListener("focus", renderSuggest);
  qIn.addEventListener("keydown", (e) => {
    const opts = $$(".suggest-item", sug);
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault(); if (!opts.length) return;
      sel = (sel + (e.key === "ArrowDown" ? 1 : -1) + opts.length) % opts.length;
      opts.forEach((o, k) => o.setAttribute("aria-selected", String(k === sel)));
      qIn.setAttribute("aria-activedescendant", "sg" + sel); opts[sel].scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") { e.preventDefault(); pick(sel >= 0 ? sel : 0); }
    else if (e.key === "Escape") { sug.classList.remove("open"); }
  });
  sug.addEventListener("mousedown", (e) => { const o = e.target.closest(".suggest-item"); if (o) { e.preventDefault(); pick(+o.dataset.i); } });
  qIn.addEventListener("blur", () => setTimeout(() => sug.classList.remove("open"), 120));
  document.addEventListener("keydown", (e) => { if (e.key === "/" && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { e.preventDefault(); qIn.focus(); } });

  /* ---------------- chat ---------------- */
  const chat = $("#chat"), chatBody = $("#chat-body");
  const chatHistory = [];
  function chatSym() {
    if (page.sym) return page.sym;
    return S.recent[0] || null;
  }
  function chatContext() {
    const s = chatSym();
    const ctx = $("#chat-ctx");
    ctx.innerHTML = `<span>Context:</span>${s ? `<span class="tag info">${s}</span>` : `<span class="tag">General</span>`}<span class="tag">${S.mode}</span>`;
  }
  function suggestions(n = 5) {
    const s = chatSym();
    const qs = s ? [`Why is ${s} going up or down?`, `What does P/E ratio mean?`, `What are the risks of investing in ${s}?`, `Explain ${s}'s financial performance in simple language`, `Compare ${s} vs ${s === "KSHT" ? "NIMB" : "KSHT"}`] : ["What does P/E ratio mean?", "What is the difference between stocks and mutual funds?", "Explain Nimbus Cloud simply", "How is my portfolio doing?"];
    return `<div class="chips">${qs.slice(0, n).map((q) => `<button class="chip" data-chatq="${esc(q)}">${esc(q)}</button>`).join("")}</div>`;
  }
  function addMsg(html, who, meta = "") {
    const d = document.createElement("div");
    d.className = "msg " + who;
    d.innerHTML = html + (meta ? `<div class="meta">${meta}</div>` : "");
    chatBody.appendChild(d); chatBody.scrollTop = chatBody.scrollHeight;
    return d;
  }
  function openChat() {
    chat.hidden = false; $("#chat-fab").hidden = true; chatContext();
    if (!chatBody.children.length) {
      addMsg(`<p>Hi, I'm <strong>Kosh AI</strong>. I explain stocks, terms and risks in plain language using the data on screen — I don't give buy/sell advice.</p>${suggestions()}`, "bot");
    }
    AI.checkLLM().then((l) => { $("#chat-engine").textContent = l.available ? `LLM via server (${l.model}) · grounded in demo data` : "Local explainer engine · runs in your browser"; });
    setTimeout(() => $("#chat-in").focus(), 50);
  }
  function closeChat() { chat.hidden = true; $("#chat-fab").hidden = false; }
  async function askChat(q) {
    if (!q) return;
    openChat();
    addMsg(esc(q), "user");
    const wait = addMsg(`<span class="typing">Thinking</span>`, "bot");
    const t0 = performance.now();
    const res = await AI.ask(q, { sym: chatSym(), mode: S.mode, portfolio: portfolioState(), history: chatHistory });
    await new Promise((r) => setTimeout(r, Math.max(0, 450 - (performance.now() - t0))));
    wait.remove();
    chatHistory.push({ role: "user", content: q }, { role: "assistant", content: res.html.replace(/<[^>]+>/g, " ").slice(0, 600) });
    addMsg(res.html + `<div style="margin-top:8px">${suggestions(3)}</div>`, "bot", `${esc(res.engine || "")}${res.sources ? " · Sources: " + res.sources.join(", ") : ""}`);
  }
  $("#chat-fab").onclick = openChat;
  $("#chat-close").onclick = closeChat;
  $("#chat-form").onsubmit = (e) => { e.preventDefault(); const v = $("#chat-in").value.trim(); $("#chat-in").value = ""; askChat(v); };
  chatBody.addEventListener("click", (e) => { const c = e.target.closest("[data-chatq]"); if (c) askChat(c.dataset.chatq); });

  /* ---------------- global delegation ---------------- */
  document.addEventListener("click", (e) => {
    const t = e.target;
    if (pop && !t.closest(".popover") && !t.closest("[data-term]")) closePop();
    if (t.closest(".popover .icon-btn")) return closePop();
    const term = t.closest("[data-term]"); if (term) { e.stopPropagation(); e.preventDefault(); return openPop(term, term.dataset.term); }
    const w = t.closest("[data-watch]"); if (w) { e.stopPropagation(); return toggleWatch(w.dataset.watch); }
    const tr = t.closest("[data-trade]"); if (tr) { e.stopPropagation(); return tradeModal(tr.dataset.trade, tr.dataset.side); }
    const al = t.closest("[data-alert]"); if (al) { e.stopPropagation(); return alertModal(al.dataset.alert, al.dataset.alertType); }
    const ask = t.closest("[data-ask]"); if (ask) { closePop(); return askChat(ask.dataset.ask); }
    const opt = t.closest(".quiz-opt[data-opt]");
    if (opt) {
      const qd = opt.closest(".quiz"), i = +opt.dataset.opt, a = +qd.dataset.a;
      S.quiz[qd.dataset.qid] = i; save();
      const allQ = D.lessons.flatMap((l) => l.quiz.map((q, k) => [l.id + "-" + k, q.a]));
      if (allQ.filter(([id, a]) => S.quiz[id] === a).length >= 5) award("quiz_ace");
      $$(".quiz-opt", qd).forEach((b, k) => { b.disabled = true; if (k === a) b.classList.add("correct"); if (k === i && i !== a) b.classList.add("wrong"); });
      const why = $(".qwhy", qd); why.hidden = false; why.textContent = (i === a ? "✓ Correct. " : "✗ Not quite. ") + why.textContent.replace(/^[✓✗][^.]*\.\s*/, "");
      return;
    }
    const go = t.closest("[data-go]"); if (go && (go.matches(".heat-tile") || !t.closest("a,button,input,select,label"))) { location.hash = go.dataset.go; $("#notif-panel").hidden = true; return; }
    const md = t.closest("[data-mode]"); if (md) { S.mode = md.dataset.mode; save(); setModeButtons(); chatContext(); toast(`Explanations set to ${S.mode}.`); if (/learn\/glossary/.test(location.hash)) route(); return; }
    const ts = t.closest("[data-theme-set]"); if (ts) { S.theme = ts.dataset.themeSet; save(); applyTheme(); return; }
    if (t.closest("#theme-btn")) { S.theme = { system: "light", light: "dark", dark: "system" }[S.theme] || "system"; save(); applyTheme(); toast(`Appearance: ${THEMES[S.theme][0]}${S.theme === "system" ? " (follows your device)" : ""}`); return; }
    if (t.closest("#bell")) { const p = $("#notif-panel"); p.hidden = !p.hidden; $("#bell").setAttribute("aria-expanded", String(!p.hidden)); if (!p.hidden) renderNotifPanel(); return; }
    if (t.closest("#mark-read")) { S.notifs.forEach((n) => (n.read = true)); save(); renderBadge(); renderNotifPanel(); return; }
    if (!t.closest("#notif-panel")) $("#notif-panel").hidden = true;
    if (t.closest("#menu-btn") || t.closest("#bnav-more")) return openSidebar();
    if (t.closest(".scrim")) return closeSidebar();
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closePop(); $("#notif-panel").hidden = true; closeSidebar(); if (!chat.hidden && document.activeElement && chat.contains(document.activeElement)) closeChat(); } });
  // Rows with data-go should be keyboard reachable
  document.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.matches("[data-go]")) location.hash = e.target.dataset.go; });

  function openSidebar() { $("#sidebar").classList.add("open"); if (!$(".scrim")) { const s = document.createElement("div"); s.className = "scrim"; document.body.appendChild(s); } }
  function closeSidebar() { $("#sidebar").classList.remove("open"); const s = $(".scrim"); if (s) s.remove(); }

  /* ---------------- live updates ---------------- */
  function liveUpdate() {
    $$("[data-p]").forEach((el) => { el.textContent = F.inr(M.bySym(el.dataset.p).price); });
    $$("[data-c]").forEach((el) => { const m = M.metrics(el.dataset.c); el.textContent = F.pct(m.chgPct); el.className = "change " + F.cls(m.chgPct); });
    $$("[data-tick]").forEach((el) => (el.textContent = F.time(M.lastTick())));
    $("#tick-time").textContent = F.time(M.lastTick());
    if (page.live && !document.querySelector(".overlay")) page.live();
    checkAlerts(); releaseNews();
  }
  M.onTick(liveUpdate);
  M.start(4000);
  document.addEventListener("visibilitychange", () => (document.hidden ? M.stop() : M.start(4000)));

  const UI = { ic, toast, modal, esc, award, info, save, S: () => S };
  window.addEventListener("hashchange", route);
  route();
})();
