/* Lightweight SVG charts with hover tooltips. No dependencies. */
window.KC = (() => {
  const F = window.KF;
  const NS = "http://www.w3.org/2000/svg";
  const cssVar = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

  function niceTicks(min, max, n = 4) {
    if (min === max) { min -= 1; max += 1; }
    const span = max - min, step0 = span / n;
    const mag = Math.pow(10, Math.floor(Math.log10(step0)));
    const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => s >= step0) || step0;
    const out = [];
    for (let v = Math.ceil(min / step) * step; v <= max + 1e-9; v += step) out.push(+v.toFixed(10));
    return out;
  }

  const observers = new WeakMap();
  function mount(el, draw) {
    draw();
    if (observers.has(el)) observers.get(el).disconnect();
    let w = el.clientWidth;
    const ro = new ResizeObserver(() => { if (Math.abs(el.clientWidth - w) > 4) { w = el.clientWidth; draw(); } });
    ro.observe(el);
    observers.set(el, ro);
  }

  /**
   * line(el, { series: [{name, color, data:[{t,p,v}]}], height, volume, percent, tf, area })
   * percent: plot % change from first point (for comparisons).
   */
  function line(el, opts) {
    mount(el, () => drawLine(el, opts));
  }
  function drawLine(el, o) {
    const W = Math.max(el.clientWidth, 260), H = o.height || 260;
    const volH = o.volume ? 54 : 0;
    const pad = { l: 8, r: 58, t: 10, b: 24 + volH };
    const series = o.series.map((s) => ({
      ...s,
      pts: o.percent ? s.data.map((d) => ({ ...d, y: (d.p / s.data[0].p - 1) * 100 })) : s.data.map((d) => ({ ...d, y: d.p })),
    }));
    const n = Math.max(...series.map((s) => s.pts.length));
    let lo = Infinity, hi = -Infinity;
    series.forEach((s) => s.pts.forEach((p) => { lo = Math.min(lo, p.y); hi = Math.max(hi, p.y); }));
    const padY = (hi - lo) * 0.08 || 1;
    lo -= padY; hi += padY;
    const x = (i, len) => pad.l + (i / Math.max(len - 1, 1)) * (W - pad.l - pad.r);
    const y = (v) => pad.t + (1 - (v - lo) / (hi - lo)) * (H - pad.t - pad.b);
    const ticks = niceTicks(lo, hi, 4);
    const fmtY = (v) => (o.percent ? (v > 0 ? "+" : "") + v.toFixed(v % 1 ? 1 : 0) + "%" : v >= 10000 ? Math.round(v).toLocaleString("en-IN") : v.toLocaleString("en-IN", { maximumFractionDigits: v < 100 ? 2 : 0 }));
    const fmtT = o.fmtT || ((t) => (o.tf === "1D" ? F.time(t) : o.tf === "1W" ? F.date(t, { weekday: "short", day: "numeric" }) : o.tf === "ALL" || o.tf === "1Y" || o.tf === "6M" ? F.date(t, { month: "short", year: "2-digit" }) : F.date(t, { day: "numeric", month: "short" })));
    const grid = "var(--border)", muted = "var(--faint)";

    let svg = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="${F.esc(o.label || "Price chart")}">`;
    svg += `<defs>${series.map((s, i) => `<linearGradient id="g${i}-${el.id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.color}" stop-opacity=".28"/><stop offset="1" stop-color="${s.color}" stop-opacity="0"/></linearGradient>`).join("")}</defs>`;
    ticks.forEach((t) => {
      svg += `<line x1="${pad.l}" x2="${W - pad.r}" y1="${y(t)}" y2="${y(t)}" stroke="${grid}" />`;
      svg += `<text x="${W - pad.r + 8}" y="${y(t) + 4}" font-size="11" fill="${muted}" font-family="var(--num)" style="font-variant-numeric:tabular-nums">${fmtY(t)}</text>`;
    });
    if (o.percent) svg += `<line x1="${pad.l}" x2="${W - pad.r}" y1="${y(0)}" y2="${y(0)}" stroke="${muted}" stroke-dasharray="3 4" />`;
    // x labels
    const ref = series[0].pts;
    const nx = Math.max(2, Math.min(5, ref.length, Math.floor((W - pad.l - pad.r) / 95)));
    for (let k = 0; k < nx; k++) {
      const i = Math.round((k / (nx - 1 || 1)) * (ref.length - 1));
      const anchor = k === 0 ? "start" : k === nx - 1 ? "end" : "middle";
      svg += `<text x="${x(i, ref.length)}" y="${H - volH - 6}" font-size="11" fill="${muted}" text-anchor="${anchor}">${fmtT(ref[i].t)}</text>`;
    }
    // prev close reference for 1D single series
    if (o.refLine != null && !o.percent) {
      svg += `<line x1="${pad.l}" x2="${W - pad.r}" y1="${y(o.refLine)}" y2="${y(o.refLine)}" stroke="${muted}" stroke-dasharray="2 4" /><text x="${pad.l + 4}" y="${y(o.refLine) - 4}" font-size="10" fill="${muted}">Prev close</text>`;
    }
    series.forEach((s, i) => {
      const d = s.pts.map((p, j) => `${j ? "L" : "M"}${x(j, s.pts.length).toFixed(1)},${y(p.y).toFixed(1)}`).join("");
      if (o.area !== false && series.length === 1) {
        svg += `<path d="${d}L${x(s.pts.length - 1, s.pts.length)},${H - pad.b}L${pad.l},${H - pad.b}Z" fill="url(#g${i}-${el.id})" />`;
      }
      svg += `<path d="${d}" fill="none" stroke="${s.color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" />`;
    });
    if (o.volume) {
      const v = series[0].pts;
      const maxV = Math.max(...v.map((p) => p.v || 0)) || 1;
      const bw = Math.max(1, (W - pad.l - pad.r) / v.length - 1);
      const base = H - 4;
      v.forEach((p, j) => {
        const h = ((p.v || 0) / maxV) * (volH - 12);
        const up = j === 0 || p.p >= v[j - 1].p;
        svg += `<rect x="${x(j, v.length) - bw / 2}" y="${base - h}" width="${bw}" height="${h}" fill="${up ? "var(--up)" : "var(--down)"}" opacity=".45" />`;
      });
      svg += `<text x="${W - pad.r + 8}" y="${base - volH + 16}" font-size="10" fill="${muted}">Volume</text>`;
    }
    (o.marks || []).forEach((m) => { const p = series[0].pts[m.i]; if (p) svg += `<circle cx="${x(m.i, series[0].pts.length)}" cy="${y(p.y)}" r="4" fill="${m.color}" stroke="${"var(--surface)"}" stroke-width="1.5" />`; });
    svg += `<line class="xh" x1="0" x2="0" y1="${pad.t}" y2="${H - pad.b}" stroke="${muted}" stroke-dasharray="3 3" opacity="0" />`;
    series.forEach((s, i) => { svg += `<circle class="dot${i}" r="4" fill="${s.color}" stroke="${"var(--surface)"}" stroke-width="2" opacity="0" />`; });
    svg += `<rect class="hit" x="${pad.l}" y="0" width="${W - pad.l - pad.r}" height="${H}" fill="transparent" />`;
    svg += `</svg><div class="tip" role="status"></div>`;
    el.innerHTML = svg;

    const svgEl = el.querySelector("svg"), tip = el.querySelector(".tip"), xh = el.querySelector(".xh");
    const move = (clientX) => {
      const r = svgEl.getBoundingClientRect();
      const px = ((clientX - r.left) / r.width) * W;
      const len = ref.length;
      const i = Math.max(0, Math.min(len - 1, Math.round(((px - pad.l) / (W - pad.l - pad.r)) * (len - 1))));
      const xx = x(i, len);
      xh.setAttribute("x1", xx); xh.setAttribute("x2", xx); xh.setAttribute("opacity", 1);
      let html = `<div class="faint">${o.fmtT ? o.fmtT(ref[i].t) : o.tf === "1D" ? F.time(ref[i].t) : F.date(ref[i].t, { day: "numeric", month: "short", year: "numeric", ...(o.tf === "1W" ? { hour: "2-digit", minute: "2-digit" } : {}) })}</div>`;
      series.forEach((s, k) => {
        const p = s.pts[Math.min(i, s.pts.length - 1)];
        const c = el.querySelector(".dot" + k);
        c.setAttribute("cx", x(Math.min(i, s.pts.length - 1), s.pts.length)); c.setAttribute("cy", y(p.y)); c.setAttribute("opacity", 1);
        html += `<div><span style="color:${s.color}">●</span> ${series.length > 1 ? F.esc(s.name) + " " : ""}<b class="num">${o.percent ? F.pct(p.y) : F.inr(p.p)}</b>${!o.percent && s.pts[0] ? ` <span class="${F.cls(p.p - s.pts[0].p)}">${F.pct((p.p / s.pts[0].p - 1) * 100)}</span>` : ""}</div>`;
      });
      if (o.volume && ref[i].v) html += `<div class="faint">Vol ${F.compact(ref[i].v)}</div>`;
      tip.innerHTML = html;
      tip.style.left = Math.min(Math.max((xx / W) * r.width, 70), r.width - 70) + "px";
      tip.style.top = "20px";
      tip.classList.add("show");
      if (o.onHover) o.onHover(i);
    };
    const leave = () => { tip.classList.remove("show"); xh.setAttribute("opacity", 0); series.forEach((_, k) => el.querySelector(".dot" + k).setAttribute("opacity", 0)); };
    svgEl.addEventListener("mousemove", (e) => move(e.clientX));
    svgEl.addEventListener("touchmove", (e) => { move(e.touches[0].clientX); }, { passive: true });
    svgEl.addEventListener("mouseleave", leave);
    svgEl.addEventListener("touchend", leave);
  }

  /** bars(el, { labels, groups:[{name,color,values}], height, fmt }) */
  function bars(el, o) { mount(el, () => drawBars(el, o)); }
  function drawBars(el, o) {
    const W = Math.max(el.clientWidth, 240), H = o.height || 200;
    const pad = { l: 8, r: 8, t: 18, b: 24 };
    const all = o.groups.flatMap((g) => g.values);
    const max = Math.max(0, ...all), min = Math.min(0, ...all);
    const y = (v) => pad.t + (1 - (v - min) / (max - min || 1)) * (H - pad.t - pad.b);
    const gw = (W - pad.l - pad.r) / o.labels.length;
    // bar width scales down with space (gap = 30% of slot), never below 2px
    const bw = Math.max(2, Math.min(28, (gw * 0.7) / o.groups.length));
    const labelEvery = Math.max(1, Math.ceil(30 / gw)); // ~30px per label so text never overlaps
    const muted = "var(--faint)";
    let svg = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="${F.esc(o.label || "Bar chart")}">`;
    svg += `<line x1="${pad.l}" x2="${W - pad.r}" y1="${y(0)}" y2="${y(0)}" stroke="${"var(--border-strong)"}" />`;
    o.labels.forEach((lab, i) => {
      const cx = pad.l + gw * i + gw / 2;
      o.groups.forEach((g, k) => {
        const v = g.values[i];
        const bx = cx - (bw * o.groups.length) / 2 + k * bw;
        const y0 = y(Math.max(0, v)), h = Math.abs(y(v) - y(0));
        svg += `<rect x="${bx + 0.5}" y="${y0}" width="${Math.max(1, bw - 1)}" height="${Math.max(h, 1)}" rx="${Math.min(3, bw / 3)}" fill="${v < 0 ? "var(--down)" : g.color}"><title>${F.esc(g.name)} ${lab}: ${o.fmt ? o.fmt(v) : v}</title></rect>`;
      });
      if (i % labelEvery === 0 || i === o.labels.length - 1 && (o.labels.length - 1) % labelEvery >= labelEvery / 2) svg += `<text x="${cx}" y="${H - 6}" font-size="11" fill="${muted}" text-anchor="middle">${F.esc(lab)}</text>`;
    });
    svg += `</svg>`;
    el.innerHTML = svg;
  }

  /** donut(el, { items:[{label,value,color}], center }) */
  function donut(el, o) {
    const size = o.size || 180, r = size / 2 - 12, cx = size / 2, cy = size / 2;
    const tot = o.items.reduce((a, i) => a + i.value, 0) || 1;
    let a0 = -Math.PI / 2;
    let svg = `<svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" role="img" aria-label="Allocation chart">`;
    if (o.items.length === 1) svg += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${o.items[0].color}" stroke-width="22" />`;
    else o.items.forEach((it) => {
      const a1 = a0 + (it.value / tot) * Math.PI * 2;
      const large = a1 - a0 > Math.PI ? 1 : 0;
      svg += `<path d="M${cx + r * Math.cos(a0)},${cy + r * Math.sin(a0)} A${r},${r} 0 ${large} 1 ${cx + r * Math.cos(a1)},${cy + r * Math.sin(a1)}" fill="none" stroke="${it.color}" stroke-width="22"><title>${F.esc(it.label)}: ${((it.value / tot) * 100).toFixed(1)}%</title></path>`;
      a0 = a1;
    });
    if (o.center) svg += `<text x="${cx}" y="${cy - 2}" text-anchor="middle" font-size="12" fill="${"var(--muted)"}">${F.esc(o.center[0])}</text><text x="${cx}" y="${cy + 16}" text-anchor="middle" font-size="14" font-weight="600" fill="${"var(--text)"}" font-family="var(--num)" style="font-variant-numeric:tabular-nums">${F.esc(o.center[1])}</text>`;
    svg += `</svg>`;
    el.innerHTML = svg;
  }

  function spark(data, color, w = 90, h = 30) {
    const ps = data.map((d) => d.p);
    const lo = Math.min(...ps), hi = Math.max(...ps);
    const d = ps.map((p, i) => `${i ? "L" : "M"}${((i / (ps.length - 1)) * w).toFixed(1)},${(h - 2 - ((p - lo) / (hi - lo || 1)) * (h - 4)).toFixed(1)}`).join("");
    return `<svg class="spark" viewBox="0 0 ${w} ${h}" aria-hidden="true"><path d="${d}" fill="none" stroke="${color}" stroke-width="1.6" /></svg>`;
  }

  return { line, bars, donut, spark };
})();
