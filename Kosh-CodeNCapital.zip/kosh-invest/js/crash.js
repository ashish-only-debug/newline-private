/*
 * Crash Test + Bias Mirror + Live League.
 * A scripted 60-day market crash and recovery, played in ~90 seconds. Players trade under
 * pressure; afterwards the Bias Mirror turns their own trades into an "Investor DNA" report.
 * Every player in a league gets the exact same market (deterministic paths), so results are comparable.
 * All prices and news are fictional.
 */
window.KOSH_CRASH = (() => {
  const F = window.KF, C = window.KC;
  const DAYS = 60, START_CASH = 100000, FEE = 20, LOT = 10000;
  const CRASH = [11, 34]; // sell-off window
  const QUALITY = ["IDX", "NIMB", "KSHT"];

  const ASSETS = [
    { id: "IDX", name: "Index fund (sim NIFTY)", short: "Index fund", start: 100, color: "var(--c2)", wig: 0.012,
      blurb: "One fund that owns the whole market — instant diversification.",
      kf: [[0, 1], [10, 1.05], [12, 1.0], [20, 0.86], [28, 0.76], [34, 0.78], [45, 0.92], [60, 1.06]] },
    { id: "SETU", name: "Setu Payments", short: "SETU", start: 488, color: "#c4b5fd", wig: 0.03,
      blurb: "Hot fintech everyone is talking about. Very volatile.",
      kf: [[0, 1], [5, 1.12], [10, 1.32], [12, 1.18], [20, 0.85], [28, 0.62], [34, 0.66], [45, 0.8], [60, 0.88]] },
    { id: "NIMB", name: "Nimbus Cloud", short: "NIMB", start: 1868, color: "var(--c1)", wig: 0.018,
      blurb: "Quality IT company with steady profits and almost no debt.",
      kf: [[0, 1], [10, 1.04], [12, 0.98], [20, 0.84], [28, 0.74], [34, 0.77], [45, 0.95], [60, 1.14]] },
    { id: "KSHT", name: "Kshetra Agro Foods", short: "KSHT", start: 642, color: "var(--c4)", wig: 0.008,
      blurb: "Makes flour and oil — people buy staples in any economy.",
      kf: [[0, 1], [10, 1.02], [12, 1.0], [20, 0.95], [28, 0.9], [34, 0.92], [45, 0.98], [60, 1.05]] },
    { id: "AKSH", name: "Akash Telecom", short: "AKSH", start: 96.4, color: "#fde68a", wig: 0.025,
      blurb: "Turnaround telecom carrying a lot of debt.",
      kf: [[0, 1], [10, 1.03], [12, 0.95], [20, 0.8], [23, 0.78], [26, 0.62], [34, 0.58], [45, 0.6], [60, 0.55]] },
  ];
  const byId = Object.fromEntries(ASSETS.map((a) => [a.id, a]));

  const EVENTS = [
    { d: 0, type: "calm", h: "Market open. Build your portfolio — then hold on tight.", sub: "Day 0" },
    { d: 3, type: "hype", h: "Setu Payments' app downloads hit a record; social media is buzzing", sub: "Demo scenario" },
    { d: 8, type: "hype", h: "SETU up 25% in 8 days — “everyone is buying” posts trend online", sub: "Demo scenario" },
    { d: 11, type: "shock", h: "Global sell-off on recession fears — markets tumble", sub: "Demo scenario" },
    { d: 16, type: "shock", h: "Five straight days of losses; commentators predict “worse to come”", sub: "Demo scenario" },
    { d: 24, type: "fund", h: "Akash Telecom misses a debt payment; credit rating cut", sub: "Company news — the business itself is in trouble" },
    { d: 28, type: "shock", h: "Simulated NIFTY down 24% from its peak — “bear market” headlines everywhere", sub: "Maximum fear" },
    { d: 33, type: "good", h: "Central bank (demo) signals rate cuts; selling slows", sub: "Demo scenario" },
    { d: 40, type: "good", h: "Nimbus Cloud reports steady profits despite the slowdown", sub: "Company news" },
    { d: 50, type: "good", h: "Recovery broadens — the index regains most of its losses", sub: "Demo scenario" },
    { d: 58, type: "fund", h: "Akash Telecom issues new shares to repay debt — existing holders diluted", sub: "Company news" },
  ];

  /* ---------- deterministic price paths ---------- */
  function rng(seed) {
    let h = 2166136261;
    for (let i = 0; i < seed.length; i++) h = Math.imul(h ^ seed.charCodeAt(i), 16777619);
    let a = h >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function interp(kf, d) {
    for (let i = 1; i < kf.length; i++) {
      if (d <= kf[i][0]) {
        const [d0, v0] = kf[i - 1], [d1, v1] = kf[i];
        const f = (d - d0) / (d1 - d0), s = f * f * (3 - 2 * f);
        return v0 + (v1 - v0) * s;
      }
    }
    return kf.at(-1)[1];
  }
  const PATH = {};
  for (const a of ASSETS) {
    const r = rng("crash:" + a.id);
    const ph = [r() * 6.28, r() * 6.28, r() * 6.28], pr = [3 + r() * 2, 7 + r() * 3, 13 + r() * 5];
    PATH[a.id] = Array.from({ length: DAYS + 1 }, (_, d) => {
      const damp = Math.min(1, d / 3, (DAYS - d) / 3);
      const n = Math.sin((2 * Math.PI * d) / pr[0] + ph[0]) * 0.5 + Math.sin((2 * Math.PI * d) / pr[1] + ph[1]) * 0.35 + Math.sin((2 * Math.PI * d) / pr[2] + ph[2]) * 0.15 + (r() - 0.5) * 0.8;
      return a.start * interp(a.kf, d) * (1 + a.wig * n * damp);
    });
  }
  const price = (id, d) => PATH[id][Math.max(0, Math.min(DAYS, d))];
  const idxBench = (d) => START_CASH * (price("IDX", d) / price("IDX", 0));

  /* ---------- game engine ---------- */
  function newGame(mode) {
    return { mode, phase: "setup", day: 0, cash: START_CASH, units: Object.fromEntries(ASSETS.map((a) => [a.id, 0])), trades: [], snaps: [], panic: [], startUnits: null, startCash: null };
  }
  const holdVal = (g, id, d = g.day) => g.units[id] * price(id, d);
  const value = (g, d = g.day) => g.cash + ASSETS.reduce((s, a) => s + holdVal(g, a.id, d), 0);
  function snap(g) {
    const v = value(g);
    g.snaps[g.day] = { day: g.day, value: v, cash: g.cash, w: Object.fromEntries(ASSETS.map((a) => [a.id, v ? holdVal(g, a.id) / v : 0])) };
  }
  function trade(g, id, side, amount) {
    const p = price(id, g.day), fee = g.phase === "run" ? FEE : 0;
    if (side === "BUY") {
      const amt = Math.min(amount, g.cash - fee);
      if (amt < 500) return { ok: false, msg: "Not enough cash." };
      g.units[id] += amt / p; g.cash -= amt + fee;
      if (g.phase === "run") g.trades.push({ day: g.day, id, side, amount: amt, price: p, units: amt / p });
    } else {
      const have = g.units[id] * p;
      if (have < 1) return { ok: false, msg: `You don't hold ${byId[id].short}.` };
      const amt = amount === "all" ? have : Math.min(amount, have);
      const u = amount === "all" ? g.units[id] : amt / p;
      g.units[id] -= u; if (g.units[id] < 1e-9) g.units[id] = 0;
      g.cash += amt - fee;
      if (g.phase === "run") g.trades.push({ day: g.day, id, side, amount: amt, price: p, units: u });
    }
    if (g.phase === "run") snap(g);
    return { ok: true };
  }
  function startRun(g) { g.phase = "run"; g.day = 0; g.startUnits = { ...g.units }; g.startCash = g.cash; snap(g); }
  function advance(g) { if (g.day >= DAYS) return false; g.day++; snap(g); if (g.day >= DAYS) g.phase = "done"; return true; }

  /* ---------- Bias Mirror ---------- */
  function analyze(g) {
    const end = (id) => price(id, DAYS);
    const flags = [];
    const final = value(g, DAYS);
    const held = g.startCash + ASSETS.reduce((s, a) => s + g.startUnits[a.id] * end(a.id), 0);
    const tr = g.trades;
    const fees = tr.length * FEE;
    const inCrash = (t) => t.day >= CRASH[0] && t.day <= CRASH[1];
    const dumpDays = new Set([...g.panic, ...tr.filter((t) => t.side === "SELL" && t.id !== "AKSH" && inCrash(t)).map((t) => t.day)]);

    // Panic selling of recoverable holdings during the market-wide fall
    const panicSells = tr.filter((t) => t.side === "SELL" && t.id !== "AKSH" && inCrash(t) && t.price < byId[t.id].start * 0.97);
    const pSold = panicSells.reduce((s, t) => s + t.amount, 0);
    const pWorth = panicSells.reduce((s, t) => s + t.units * end(t.id), 0);
    if (pSold > 2000 && pWorth - pSold > 1000) {
      const avgDrop = panicSells.reduce((s, t) => s + (t.price / byId[t.id].start - 1) * t.amount, 0) / pSold * 100;
      flags.push({ key: "panic", kind: "bad", w: 22, impact: -(pWorth - pSold),
        title: g.panic.length ? `Panic selling — you hit “Sell everything” on day ${g.panic[0]}` : "Panic selling",
        what: `You sold ${F.inr(pSold, 0)} of ${[...new Set(panicSells.map((t) => byId[t.id].short))].join(", ")} during the sell-off, when prices were down about ${Math.abs(avgDrop).toFixed(0)}%. By day 60 those same shares were worth ${F.inr(pWorth, 0)} — selling cost you <strong>${F.inr(pWorth - pSold, 0)}</strong>.`,
        why: "Those prices fell because the whole market fell, not because the businesses broke. Selling in a market-wide panic turns a temporary dip into a permanent loss.",
        habit: "Before selling in a fall, ask: did the business change, or only the price?" });
    }
    // Sold the broken business (good)
    const akSells = tr.filter((t) => t.side === "SELL" && t.id === "AKSH" && t.day >= 24 && !dumpDays.has(t.day));
    const akSold = akSells.reduce((s, t) => s + t.amount, 0);
    if (akSold > 3000) {
      const saved = akSold - akSells.reduce((s, t) => s + t.units * end("AKSH"), 0);
      flags.push({ key: "fund", kind: "good", w: 8, impact: saved,
        title: "Sold on real news, not on fear",
        what: `You sold ${F.inr(akSold, 0)} of Akash Telecom after its debt default on day 24. It kept falling to ${F.inr(end("AKSH"))} — you avoided <strong>${F.inr(saved, 0)}</strong> of further losses.`,
        why: "Selling because the business itself broke is very different from selling because the market dipped. You spotted the difference.",
        habit: "Keep separating price noise from business news." });
    }
    // FOMO: bought the hype
    const fomo = tr.filter((t) => t.side === "BUY" && t.id === "SETU" && t.day <= 12 && t.price >= byId.SETU.start * 1.12);
    const fAmt = fomo.reduce((s, t) => s + t.amount, 0);
    if (fAmt >= 5000) {
      const fNow = fomo.reduce((s, t) => s + t.units * end("SETU"), 0);
      const rise = (fomo[0].price / byId.SETU.start - 1) * 100;
      flags.push({ key: "fomo", kind: "bad", w: 12, impact: fNow - fAmt,
        title: "Chasing the hype (FOMO)",
        what: `You bought ${F.inr(fAmt, 0)} of SETU after it had already jumped ${rise.toFixed(0)}% on social-media buzz. By day 60 those shares were worth ${F.inr(fNow, 0)} (${F.pct((fNow / fAmt - 1) * 100, 0)}).`,
        why: "By the time everyone is talking about a stock, the easy gains are usually already in the price — and hype stocks fall hardest when sentiment turns.",
        habit: "Write down why you're buying before you buy. “It's going up” isn't a reason." });
    }
    // Falling knife
    const knife = tr.filter((t) => t.side === "BUY" && t.id === "AKSH" && t.day >= 24);
    const kAmt = knife.reduce((s, t) => s + t.amount, 0);
    if (kAmt >= 5000) {
      const kNow = knife.reduce((s, t) => s + t.units * end("AKSH"), 0);
      flags.push({ key: "knife", kind: "bad", w: 12, impact: kNow - kAmt,
        title: "Catching a falling knife",
        what: `You bought ${F.inr(kAmt, 0)} of Akash Telecom after it defaulted on its debt. It never recovered: by day 60 those shares were worth ${F.inr(kNow, 0)}.`,
        why: "A lower price is only a bargain if the business is still healthy. Here the bad news was about the company itself, not the market.",
        habit: "Buy dips in strong businesses; avoid dips caused by broken ones." });
    }
    // Concentration
    let maxW = 0, maxId = null, maxDay = 0;
    g.snaps.forEach((s) => s && ASSETS.forEach((a) => { if (a.id !== "IDX" && s.w[a.id] > maxW) { maxW = s.w[a.id]; maxId = a.id; maxDay = s.day; } }));
    if (maxW > 0.4) {
      // Measure only the fall the player actually lived through while holding it.
      let endHeld = DAYS;
      for (let d = maxDay + 1; d <= DAYS; d++) if (g.snaps[d] && g.snaps[d].w[maxId] < 0.05) { endHeld = d; break; }
      const p0 = price(maxId, maxDay);
      const ddHeld = (Math.min(...PATH[maxId].slice(maxDay, endHeld + 1)) / p0 - 1) * 100;
      const ddAll = (Math.min(...PATH[maxId].slice(maxDay)) / p0 - 1) * 100;
      flags.push({ key: "conc", kind: "bad", w: 12, impact: null,
        title: "All eggs in one basket",
        what: `On day ${maxDay}, ${byId[maxId].name} made up <strong>${(maxW * 100).toFixed(0)}%</strong> of your portfolio. ${ddHeld <= -10 ? `While you held it, it fell as much as ${Math.abs(ddHeld).toFixed(0)}%, pulling your whole portfolio down about ${Math.abs(ddHeld * maxW).toFixed(0)}% from that one stock alone.` : ddAll <= -10 ? `You sold it before its big fall (it later dropped ${Math.abs(ddAll).toFixed(0)}% from that point), so this time it didn't hurt. But that much in one stock means a single surprise can.` : "This time it didn't fall much, but one surprise could have."}`,
        why: "One stock can drop 40% for reasons nobody predicted. Spreading money out means no single surprise can sink you.",
        habit: "Keep any single stock under ~20–25%. Index funds do the spreading for you." });
    } else if (g.snaps[1] && ASSETS.filter((a) => g.startUnits[a.id] > 0).length >= 3) {
      flags.push({ key: "div", kind: "good", w: 6, impact: null, title: "Well diversified",
        what: `No single stock ever made up more than ${(maxW * 100).toFixed(0)}% of your portfolio.`, why: "When one holding had bad news, the rest cushioned the blow.", habit: "Keep it up." });
    }
    // Overtrading
    if (tr.length > 15) flags.push({ key: "over", kind: "bad", w: 8, impact: -fees,
      title: "Overtrading", what: `You made ${tr.length} trades in 60 days and paid ${F.inr(fees, 0)} in charges.`,
      why: "Frequent trading usually means reacting to noise — and every trade has a cost.", habit: "Make a plan, then trade only when something important changes." });
    // Sideliner
    const rec = g.snaps.slice(29).filter(Boolean);
    const cashShare = rec.reduce((s, x) => s + x.cash / x.value, 0) / (rec.length || 1);
    if (cashShare > 0.5) {
      const idxGain = (price("IDX", DAYS) / price("IDX", 29) - 1) * 100;
      flags.push({ key: "side", kind: "bad", w: 10, impact: null,
        title: "Sat out the recovery",
        what: `During the recovery (days 29–60) about ${(cashShare * 100).toFixed(0)}% of your money sat in cash. The index rose ${idxGain.toFixed(0)}% in that time.`,
        why: "The best days often come right after the worst ones. Waiting for “safety” usually means buying back higher.",
        habit: "Time in the market beats timing the market." });
    }
    // Bought the dip in quality
    const dip = tr.filter((t) => t.side === "BUY" && QUALITY.includes(t.id) && t.day >= 18 && t.day <= 38);
    const dAmt = dip.reduce((s, t) => s + t.amount, 0);
    if (dAmt >= 10000) {
      const dNow = dip.reduce((s, t) => s + t.units * end(t.id), 0);
      flags.push({ key: "dip", kind: "good", w: 10, impact: dNow - dAmt,
        title: "Bought the dip in quality",
        what: `You invested ${F.inr(dAmt, 0)} into ${[...new Set(dip.map((t) => byId[t.id].short))].join(", ")} while prices were low. By day 60 those shares were worth ${F.inr(dNow, 0)} (<strong>${F.pct((dNow / dAmt - 1) * 100, 0)}</strong>).`,
        why: "Buying healthy businesses when others are scared is how long-term investors are rewarded.", habit: "Keep some cash ready for opportunities." });
    }
    // Steady hands
    // "Steady" = no fear-selling during the sell-off (selling Akash after its own bad news on day 24 doesn't count)
    const soldInCrash = tr.some((t) => t.side === "SELL" && inCrash(t) && !(t.id === "AKSH" && t.day >= 24 && !dumpDays.has(t.day)));
    const investedAtShock = g.snaps[CRASH[0]] ? 1 - g.snaps[CRASH[0]].cash / g.snaps[CRASH[0]].value : 0;
    if (!soldInCrash && investedAtShock >= 0.6) flags.push({ key: "steady", kind: "good", w: 8, impact: null,
      title: "Steady hands", what: `You were ${(investedAtShock * 100).toFixed(0)}% invested when the sell-off began and didn't sell in fear while the market fell 24%.`,
      why: "Staying calm through a crash is the hardest — and most valuable — investing skill.", habit: "Remember this feeling next time headlines scream." });

    const bad = flags.filter((f) => f.kind === "bad"), good = flags.filter((f) => f.kind === "good");
    const score = Math.max(5, Math.min(99, Math.round(72 - bad.reduce((s, f) => s + f.w, 0) + good.reduce((s, f) => s + f.w, 0))));
    const ARCH = {
      panic: ["The Panic Seller", "Sells when headlines get scary — and usually near the bottom."],
      fomo: ["The FOMO Chaser", "Buys what's already popular — often near the top."],
      knife: ["The Falling-Knife Catcher", "Sees “cheap” where others see danger, even when the business is broken."],
      conc: ["The All-In Gambler", "Bets big on one idea. Thrilling until it isn't."],
      side: ["The Sideliner", "Plays it so safe that the recovery passes by."],
      over: ["The Overtrader", "Always doing something — and paying for it."],
    };
    const worst = bad.slice().sort((a, b) => b.w - a.w)[0];
    const [arch, archSub] = worst ? ARCH[worst.key]
      : good.some((f) => f.key === "dip") ? ["The Bargain Hunter", "Calm in a crash, and brave enough to buy quality when it's cheap."]
      : ["The Steady Hand", "Doesn't flinch at headlines. The rarest investor type."];
    return { flags: [...bad, ...good], score, arch, archSub, final, ret: (final / START_CASH - 1) * 100, held, idx: idxBench(DAYS), fees, trades: tr.length };
  }

  /* ---------- UI ---------- */
  const evTag = { calm: ["", "Market"], hype: ["warn", "Hype"], shock: ["down", "Market shock"], fund: ["down", "Company news"], good: ["up", "Good news"] };
  const curEvent = (d) => EVENTS.filter((e) => e.d <= d).at(-1);

  /**
   * play(root, opts) runs one game.
   *  opts.mode: "solo" | "league"
   *  opts.dayMs: ms per simulated day (solo)
   *  opts.clock: () => { phase: "setup"|"run", day, setupLeft } (league; overrides local timing)
   *  opts.onDay(g), opts.onEnd(g, report)
   * Returns a cleanup function.
   */
  function play(root, opts, UI) {
    const { ic, toast } = UI;
    const g = newGame(opts.mode);
    let timer = null, paused = false, lastEvent = -1, dayMs = opts.dayMs || 1500;

    const assetRows = () => ASSETS.map((a) => `
      <tr data-row="${a.id}">
        <td><div class="sym"><span class="logo" style="background:${a.color}">${a.id.slice(0, 2)}</span><div><div class="sym-name">${a.short}</div><div class="sym-sub crash-blurb" style="white-space:normal;max-width:260px">${a.blurb}</div></div></div></td>
        <td class="r num" data-cp="${a.id}"></td><td class="r" data-cc="${a.id}"></td><td class="r num" data-ch="${a.id}"></td>
        <td class="r"><div class="asset-actions"><button class="btn sm buy" data-b="${a.id}">+₹10k</button><button class="btn sm" data-s="${a.id}">−₹10k</button><button class="btn sm ghost" data-sa="${a.id}">Sell all</button></div></td>
      </tr>`).join("");

    function shell() {
      const setup = g.phase === "setup";
      root.innerHTML = `
        <div class="page-head"><div><div class="eyebrow">${opts.mode === "league" ? "Live league" : "Crash Test"} · simulated market</div>
          <h1>${setup ? "Build your starting portfolio" : "Survive the market"}</h1>
          <p>${setup ? `You have ${F.inr(START_CASH, 0)} of virtual money. Spread it however you like — then 60 market days play out in about ${Math.round((DAYS * dayMs) / 1000)} seconds.` : "Trade if you want to. Or don't. Your choices are being recorded for your Bias Mirror report."}</p></div>
          ${setup ? (opts.mode === "solo" ? `<div class="row"><select class="input" id="cr-speed" aria-label="Speed" style="width:auto"><option value="1500">Normal · 90 s</option><option value="3000">Relaxed · 3 min</option><option value="800">Fast · 48 s</option></select><button class="btn primary" id="cr-start">Start the market ▶</button></div>` : `<div class="stat-mini" style="min-width:150px"><span class="label">Market opens in</span><span class="value" id="cr-count">—</span></div>`) : `<button class="panic-btn" id="cr-panic">SELL EVERYTHING</button>`}
        </div>
        ${setup ? `<div class="card" style="margin-bottom:16px"><div class="row"><span class="muted">Quick picks:</span><button class="btn sm" data-preset="bal">Balanced (20% each)</button><button class="btn sm" data-preset="idx">All index fund</button><button class="btn sm" data-preset="hot">All on the hot stock</button><button class="btn sm ghost" data-preset="clear">Clear</button></div></div>` : `
        <div class="card" style="margin-bottom:16px"><div class="crash-top">
          <div><div class="note">Day</div><div class="value num" style="font-size:24px;font-weight:700"><span id="cr-day">0</span>/${DAYS}</div></div>
          <div><div class="note">Portfolio value</div><div class="num" style="font-size:24px;font-weight:700" id="cr-val"></div></div>
          <div><div class="note">Since start</div><div class="change" style="font-size:18px" id="cr-ret"></div></div>
          <div><div class="note">Cash</div><div class="num" style="font-size:18px" id="cr-cash"></div></div>
          ${opts.mode === "solo" ? `<button class="btn" id="cr-pause">Pause</button>` : ""}
        </div><div class="progress" style="margin-top:12px"><i id="cr-prog"></i></div></div>
        <div class="news-banner" id="cr-news" role="status" aria-live="polite" style="margin-bottom:16px"></div>`}
        <div class="grid ${setup ? "" : "g-main"}" style="align-items:start">
          <div class="stack" style="gap:16px">
            ${setup ? `<div class="card"><div class="card-head"><h2>Your allocation</h2><span class="note" id="cr-left"></span></div><div class="bar-split" id="cr-alloc" style="height:16px"></div><div class="legend" id="cr-alloc-leg" style="margin-top:8px"></div></div>` : `<section class="card cr-chart-card"><div class="card-head"><h2>You vs the index</h2><div class="legend"><span><i style="background:var(--accent)"></i>You</span><span><i style="background:var(--c2)"></i>Index buy &amp; hold</span></div></div><div class="chart" id="cr-chart"></div></section>`}
            <section class="card"><div class="table-wrap"><table class="t"><thead><tr><th>Asset</th><th class="r">Price</th><th class="r">Since day 0</th><th class="r">Your holding</th><th class="r">${setup ? "Allocate" : `Trade <span class="faint">(₹${FEE} per trade)</span>`}</th></tr></thead><tbody>${assetRows()}</tbody></table></div></section>
          </div>
          ${setup ? "" : `<aside class="card"><div class="card-head"><h2>Market feed</h2></div><div id="cr-feed"></div><p class="note">The coach stays quiet until the end — trust your instincts. All news is fictional.</p></aside>`}
        </div>`;
    }

    function update() {
      ASSETS.forEach((a) => {
        const p = price(a.id, g.day), ch = (p / a.start - 1) * 100, h = holdVal(g, a.id);
        const set = (sel, html) => { const el = root.querySelector(sel); if (el) el.innerHTML = html; };
        set(`[data-cp="${a.id}"]`, F.inr(p));
        set(`[data-cc="${a.id}"]`, `<span class="change ${F.cls(ch)}">${F.pct(ch, 1)}</span>`);
        set(`[data-ch="${a.id}"]`, h > 0.5 ? F.inr(h, 0) : `<span class="faint">—</span>`);
        const sb = root.querySelector(`[data-s="${a.id}"]`), sa = root.querySelector(`[data-sa="${a.id}"]`);
        if (sb) sb.disabled = h < 1; if (sa) sa.disabled = h < 1;
      });
      if (g.phase === "setup") {
        const v = value(g);
        root.querySelector("#cr-left").textContent = `Cash left: ${F.inr(g.cash, 0)}`;
        const parts = ASSETS.map((a) => ({ a, w: holdVal(g, a.id) / v })).filter((x) => x.w > 0.001);
        root.querySelector("#cr-alloc").innerHTML = parts.map((x) => `<i style="display:block;width:${x.w * 100}%;background:${x.a.color}"></i>`).join("");
        root.querySelector("#cr-alloc-leg").innerHTML = parts.map((x) => `<span><i style="background:${x.a.color}"></i>${x.a.short} ${(x.w * 100).toFixed(0)}%</span>`).join("") + `<span><i style="background:var(--surface-3)"></i>Cash ${((g.cash / v) * 100).toFixed(0)}%</span>`;
        return;
      }
      const v = value(g), ret = (v / START_CASH - 1) * 100;
      root.querySelector("#cr-day").textContent = g.day;
      root.querySelector("#cr-val").textContent = F.inr(v, 0);
      const r = root.querySelector("#cr-ret"); r.textContent = F.pct(ret, 1); r.className = "change " + F.cls(ret);
      root.querySelector("#cr-cash").textContent = F.inr(g.cash, 0);
      root.querySelector("#cr-prog").style.width = (g.day / DAYS) * 100 + "%";
      const ev = curEvent(g.day);
      if (ev && ev.d !== lastEvent) {
        lastEvent = ev.d;
        const nb = root.querySelector("#cr-news");
        nb.className = "news-banner " + ev.type;
        nb.innerHTML = `<span class="tag ${evTag[ev.type][0]}">${evTag[ev.type][1]}</span><div><strong>Day ${ev.d}: ${ev.h}</strong><div class="note">${ev.sub}</div></div>`;
        void nb.offsetWidth; nb.classList.add("flash");
        root.querySelector("#cr-feed").innerHTML = EVENTS.filter((e) => e.d <= g.day).reverse().map((e) => `<div class="list-item"><span class="tag ${evTag[e.type][0]}">D${e.d}</span><div class="grow" style="font-size:13px">${e.h}</div></div>`).join("");
      }
      const s = g.snaps.filter(Boolean);
      const chartEl = root.querySelector("#cr-chart");
      if (chartEl && !chartEl.matches(":hover")) {
        C.line(chartEl, {
          series: [{ name: "You", color: "var(--accent)", data: s.map((x) => ({ t: x.day, p: x.value })) }, { name: "Index", color: "var(--c2)", data: s.map((x) => ({ t: x.day, p: idxBench(x.day) })) }],
          height: 220, fmtT: (d) => "Day " + d, area: false, label: "Your portfolio vs index",
          marks: g.trades.map((t) => ({ i: s.findIndex((x) => x.day === t.day), color: t.side === "BUY" ? "var(--up)" : "var(--down)" })),
        });
      }
    }

    function finish() {
      clearInterval(timer); timer = null;
      const rep = analyze(g);
      try { localStorage.setItem("kosh.crash", JSON.stringify({ arch: rep.arch, score: rep.score, ret: rep.ret, at: Date.now() })); } catch {}
      opts.onEnd && opts.onEnd(g, rep);
      UI.award && (UI.award("crash"), rep.score >= 80 && UI.award("steady"));
      report(root, g, rep, opts, UI);
    }

    function stepTo(day) {
      let moved = false;
      while (g.day < day && g.phase === "run") { advance(g); moved = true; opts.onDay && opts.onDay(g); }
      if (moved) update();
      if (g.phase === "done") finish();
    }

    function begin() {
      startRun(g); shell(); update();
      if (opts.mode === "solo") {
        timer = setInterval(() => { if (!paused) stepTo(g.day + 1); }, dayMs);
      }
    }

    root.onclick = (e) => {
      const t = e.target.closest("button"); if (!t || g.phase === "done") return;
      let res = null;
      if (t.dataset.b) res = trade(g, t.dataset.b, "BUY", LOT);
      else if (t.dataset.s) res = trade(g, t.dataset.s, "SELL", LOT);
      else if (t.dataset.sa) res = trade(g, t.dataset.sa, "SELL", "all");
      else if (t.dataset.preset) {
        ASSETS.forEach((a) => { if (g.units[a.id]) trade(g, a.id, "SELL", "all"); });
        const plan = { bal: ASSETS.map((a) => [a.id, 20000]), idx: [["IDX", START_CASH]], hot: [["SETU", START_CASH]], clear: [] }[t.dataset.preset];
        plan.forEach(([id, amt]) => trade(g, id, "BUY", amt));
        update(); return;
      } else if (t.id === "cr-start") { dayMs = +root.querySelector("#cr-speed").value; begin(); return; }
      else if (t.id === "cr-pause") { paused = !paused; t.textContent = paused ? "Resume" : "Pause"; return; }
      else if (t.id === "cr-panic") {
        const any = ASSETS.some((a) => holdVal(g, a.id) > 1);
        if (!any) { toast("You're already all in cash."); return; }
        g.panic.push(g.day);
        ASSETS.forEach((a) => { if (holdVal(g, a.id) > 1) trade(g, a.id, "SELL", "all"); });
        toast(`Sold everything on day ${g.day}.`, "down"); update(); return;
      }
      if (res) { if (!res.ok) toast(res.msg); update(); }
    };

    shell(); update();
    let leagueTimer = null;
    if (opts.clock) {
      leagueTimer = setInterval(() => {
        const c = opts.clock();
        if (g.phase === "setup") {
          const el = root.querySelector("#cr-count"); if (el) el.textContent = Math.max(0, Math.ceil(c.setupLeft / 1000)) + " s";
          if (c.phase === "run") begin();
        }
        if (g.phase === "run") stepTo(Math.min(DAYS, c.day));
      }, 200);
    }
    return () => { clearInterval(timer); clearInterval(leagueTimer); root.onclick = null; };
  }

  function report(root, g, rep, opts, UI) {
    const { ic } = UI;
    const max = Math.max(rep.final, rep.held, rep.idx, START_CASH);
    const bench = [["You", rep.final, "var(--accent)"], ["Your day-0 mix, untouched", rep.held, "var(--c3)"], ["Index buy & hold", rep.idx, "var(--c2)"], ["Stayed in cash", START_CASH, "var(--faint)"]];
    const diff = rep.final - rep.held;
    root.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">Bias Mirror · your Investor DNA</div><h1>${rep.arch}</h1><p>${rep.archSub}</p></div>
        <div class="row">${opts.mode === "solo" ? `<button class="btn primary" id="cr-again">Play again</button><a class="btn" href="#/league">Play with a group</a>` : ""}<button class="btn ghost" id="cr-copy">Copy result</button></div></div>
      ${opts.mode === "league" ? `<div class="card" id="cr-rank" style="margin-bottom:16px"></div>` : ""}
      <div class="grid g-main" style="align-items:start">
        <div class="stack" style="gap:16px">
          <section class="card">
            <div class="row" style="gap:24px;align-items:center">
              <div class="score-ring" style="--v:${rep.score}" role="img" aria-label="Discipline score ${rep.score} out of 100"><div>${rep.score}</div></div>
              <div style="flex:1;min-width:220px"><div class="note">Discipline score</div><p style="margin:4px 0 10px">Measures <em>how</em> you invested, not luck. Ended at <strong class="num">${F.inr(rep.final, 0)}</strong> (<span class="${F.cls(rep.ret)}">${F.pct(rep.ret, 1)}</span>) after ${rep.trades} trade${rep.trades === 1 ? "" : "s"}.</p>
                <p class="muted" style="margin:0">Your trades during the crash ${diff >= 0 ? "<strong class=\"up\">earned</strong>" : "<strong class=\"down\">cost</strong>"} you <strong>${F.inr(Math.abs(diff), 0)}</strong> compared with simply holding the portfolio you built on day 0.</p></div>
            </div>
            <div class="divider"></div>
            ${bench.map(([l, v, c]) => `<div class="bench-row"><span class="note">${l}</span><div class="bench-bar"><i style="width:${(v / max) * 100}%;background:${c}"></i></div><span class="num r">${F.inr(v, 0)}</span></div>`).join("")}
          </section>
          <section class="card"><div class="card-head"><h2>What your trades say about you</h2></div>
            ${rep.flags.length ? `<div class="stack">${rep.flags.map((f) => `<div class="flag ${f.kind}"><div class="spread"><strong>${f.kind === "bad" ? "▼" : "▲"} ${f.title}</strong>${f.impact != null ? `<span class="change ${F.cls(f.impact)}">${F.signed(f.impact, 0)}</span>` : ""}</div><p style="margin:6px 0">${f.what}</p><p class="muted" style="margin:0 0 4px"><strong style="color:var(--text)">Why it matters:</strong> ${f.why}</p><p class="note" style="margin:0">Habit to build: ${f.habit}</p></div>`).join("")}</div>`
              : `<p class="muted">You barely traded, and your starting mix carried you. That's a legitimate strategy — next time try spreading across more assets and see how it changes the ride.</p>`}
          </section>
        </div>
        <div class="stack" style="gap:16px">
          <section class="card"><div class="card-head"><h2>Your 60 days</h2></div><div class="chart" id="cr-rchart"></div><div class="legend" style="margin-top:6px"><span><i style="background:var(--accent)"></i>You</span><span><i style="background:var(--c2)"></i>Index</span><span><i style="background:var(--up)"></i>Buy</span><span><i style="background:var(--down)"></i>Sell</span></div></section>
          <section class="card"><div class="card-head"><h2>The lesson in this crash</h2></div>
            <ul class="bullets"><li>The index fell <strong>24%</strong> and then finished <strong>+6%</strong>. Patience was paid.</li><li><strong>Akash Telecom</strong> was the trap: its fall came from company news (a debt default), so it never recovered.</li><li><strong>SETU</strong> was the hype trap: up 32% on buzz, then down 53% from its peak.</li><li>Telling <em>price noise</em> from <em>business news</em> is the core skill.</li></ul>
            <a class="btn sm" href="#/learn">${ic("learn")} Risk & diversification lessons</a></section>
        </div>
      </div>
      <p class="note" style="margin-top:16px">Fictional scenario for learning. Real markets don't follow a script, and past recoveries don't guarantee future ones.</p>`;
    const s = g.snaps.filter(Boolean);
    C.line(root.querySelector("#cr-rchart"), {
      series: [{ name: "You", color: "var(--accent)", data: s.map((x) => ({ t: x.day, p: x.value })) }, { name: "Index", color: "var(--c2)", data: s.map((x) => ({ t: x.day, p: idxBench(x.day) })) }],
      height: 200, fmtT: (d) => "Day " + d, area: false, label: "Your 60 days",
      marks: g.trades.map((t) => ({ i: t.day, color: t.side === "BUY" ? "var(--up)" : "var(--down)" })),
    });
    root.onclick = (e) => {
      if (e.target.closest("#cr-again")) opts.again && opts.again();
      if (e.target.closest("#cr-copy")) {
        const txt = `My Kosh Crash Test result: ${rep.arch} — discipline ${rep.score}/100, return ${F.pct(rep.ret, 1)}. Biggest lesson: ${(rep.flags.find((f) => f.kind === "bad") || rep.flags[0] || { title: "stay the course" }).title}.`;
        navigator.clipboard?.writeText(txt).then(() => UI.toast("Result copied."), () => UI.toast(txt));
      }
    };
  }

  /* ---------- Solo page ---------- */
  function mountSolo(root, UI) {
    let cleanup = null;
    const intro = () => {
      const last = (() => { try { return JSON.parse(localStorage.getItem("kosh.crash")); } catch { return null; } })();
      root.innerHTML = `
        <div class="hero"><div class="eyebrow">Behaviour, not just data</div><h1 style="font-size:32px;margin:6px 0 10px">Crash Test</h1>
          <p style="max-width:640px;font-size:15px">Most beginners don't lose money because they lack information. They lose it because they <strong>panic-sell in crashes</strong>, <strong>chase hype</strong> and <strong>put everything in one stock</strong>. Crash Test puts you inside a 60-day market crash and recovery, about 90 seconds of pressure. Then the <strong>Bias Mirror</strong> shows you, with your own numbers, which habits helped and which hurt.</p>
          <div class="row" style="margin-top:14px"><button class="btn primary" id="cr-go">Start Crash Test ▶</button><a class="btn" href="#/league">Play live with a group</a></div>
          ${last ? `<p class="note" style="margin-top:12px">Your last result: <strong>${F.esc(last.arch)}</strong> · discipline ${last.score}/100 · ${F.pct(last.ret, 1)}</p>` : ""}</div>
        <div class="grid g3">
          <div class="card"><div class="eyebrow">1 · Build</div><h3 style="margin:6px 0">Spread ₹1,00,000</h3><p class="muted">Five assets: a hyped fintech, a debt-heavy telecom, a steady staples maker, a quality IT firm, and an index fund.</p></div>
          <div class="card"><div class="eyebrow">2 · Survive</div><h3 style="margin:6px 0">Live through a crash</h3><p class="muted">Headlines flash, prices fall 24%, social media panics. Buy, sell or hit the big red button — it's your call.</p></div>
          <div class="card"><div class="eyebrow">3 · Reflect</div><h3 style="margin:6px 0">See your Investor DNA</h3><p class="muted">Panic selling, FOMO, concentration, overtrading: each one measured in rupees from your own trades.</p></div>
        </div>`;
      root.querySelector("#cr-go").onclick = start;
    };
    const start = () => { cleanup && cleanup(); cleanup = play(root, { mode: "solo", dayMs: 1500, again: start }, UI); };
    intro();
    return () => { cleanup && cleanup(); root.onclick = null; };
  }

  /* ---------- League ---------- */
  async function api(path, body) {
    const r = await fetch("/api/league" + path, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : { cache: "no-store" });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "Request failed");
    return j;
  }
  const ss = { get: (k) => { try { return JSON.parse(sessionStorage.getItem(k)); } catch { return null; } }, set: (k, v) => { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch {} } };

  function mountLeague(root, arg, UI) {
    // On a hosted (serverless) deployment there is no long-running server to hold rooms.
    if (window.KOSH_HOSTED === undefined) {
      const startHash = location.hash; let inner = null, dead = false;
      root.innerHTML = `<div class="card">${'<div class="skeleton" style="height:22px"></div>'}</div>`;
      fetch("/api/info", { cache: "no-store" }).then((r) => r.json()).then((j) => { window.KOSH_HOSTED = !!j.hosted; }).catch(() => { window.KOSH_HOSTED = false; })
        .then(() => { if (!dead && location.hash === startHash) inner = mountLeague(root, arg, UI); });
      return () => { dead = true; inner && inner(); };
    }
    if (window.KOSH_HOSTED) {
      root.innerHTML = `
        <div class="page-head"><div><div class="eyebrow">Live classroom league</div><h1>Play the crash together</h1><p>Everyone plays the same market at the same moment, with a live leaderboard on the projector.</p></div></div>
        <div class="grid g2">
          <section class="card"><h2 style="margin-bottom:8px">Runs from the presenter's laptop</h2><p class="muted">A league room has to live on one continuously running server, so it works when the Kosh server runs on a laptop (<code>node server.js</code>) and players join over the same Wi-Fi. This hosted demo runs on serverless functions, which can't hold a shared room.</p></section>
          <section class="card"><h2 style="margin-bottom:8px">Try it solo here</h2><p class="muted">The Crash Test uses the exact same market and Bias Mirror report. Only the shared leaderboard is missing.</p><a class="btn primary" href="#/crash">${UI.ic("zap")} Start the Crash Test</a></section>
        </div>`;
      return () => {};
    }
    const { ic, toast } = UI;
    const esc = F.esc;
    const [codeRaw, role] = (arg || "").split("/");
    const code = (codeRaw || "").toUpperCase();
    let poll = null, gameCleanup = null, off = 0;
    const now = () => Date.now() + off;
    const stop = () => { clearInterval(poll); gameCleanup && gameCleanup(); root.onclick = null; root.onsubmit = null; };
    const offline = (e) => { root.innerHTML = `<div class="card empty"><h2>League needs the Kosh server</h2><p>Start it with <code>node server.js</code> and open the site from that address. (${esc(e.message)})</p><a class="btn" href="#/crash">Play solo instead</a></div>`; };
    const sync = (j) => { off = j.serverNow - Date.now(); return j; };

    if (!code) {
      root.innerHTML = `
        <div class="page-head"><div><div class="eyebrow">Live classroom league</div><h1>Play the crash together</h1><p>Everyone gets the same market at the same moment. The projector shows a live leaderboard, ranked by return <em>and</em> by discipline.</p></div></div>
        <div class="grid g2">
          <section class="card"><h2 style="margin-bottom:8px">Host a room</h2><p class="muted">For the presenter. Put this screen on the projector; players join from their phones on the same Wi-Fi.</p><button class="btn primary" id="lg-host">${ic("plus")} Create room</button></section>
          <section class="card"><h2 style="margin-bottom:8px">Join a room</h2><form id="lg-join" class="stack" novalidate><div class="field"><label for="lg-code">Room code</label><input class="input mono" id="lg-code" maxlength="4" autocomplete="off" style="text-transform:uppercase" placeholder="ABCD"></div><div class="err" id="lg-err" style="color:var(--down);font-size:12px"></div><button class="btn primary">Continue</button></form></section>
        </div>`;
      root.onclick = async (e) => {
        if (!e.target.closest("#lg-host")) return;
        try { const j = await api("", { action: "create" }); ss.set("kosh.host." + j.code, j.hostKey); location.hash = `#/league/${j.code}/host`; } catch (err) { offline(err); }
      };
      root.onsubmit = (e) => { e.preventDefault(); const c = root.querySelector("#lg-code").value.trim().toUpperCase(); if (!/^[A-Z]{4}$/.test(c)) { root.querySelector("#lg-err").textContent = "Enter the 4-letter code."; return; } location.hash = "#/league/" + c; };
      return stop;
    }

    /* ----- Host (projector) ----- */
    if (role === "host") {
      const key = ss.get("kosh.host." + code);
      if (!key) { root.innerHTML = `<div class="card empty"><h2>You're not the host of room ${esc(code)}</h2><p>Hosting works from the browser that created the room.</p><a class="btn" href="#/league/${esc(code)}">Join as a player</a></div>`; return stop; }
      let info = null, lastStatus = "";
      fetch("/api/info").then((r) => r.json()).then((j) => { info = j; render(window.__room); }).catch(() => {});
      const joinUrl = () => {
        const base = info && info.lan && info.lan[0] && /localhost|127\.0\.0\.1/.test(location.hostname) ? info.lan[0] : location.origin;
        return `${base}/#/league/${code}`;
      };
      const render = (room) => {
        if (!room) return;
        const st = room.status;
        const players = room.players;
        if (st === "lobby") {
          if (lastStatus !== "lobby" || !root.querySelector("#lg-qr")) {
            root.innerHTML = `<div class="grid g2" style="align-items:center">
              <div><div class="eyebrow">Join on your phone</div><div class="room-code">${esc(code)}</div><p class="join-url" id="lg-url"></p><p class="muted">Same Wi-Fi as this laptop. Open the link or scan the code, then enter a nickname.</p>
                <button class="btn primary" id="lg-start" style="margin-top:8px">Start round ▶</button> <span class="note" id="lg-pc"></span></div>
              <div style="text-align:center"><div class="qr" id="lg-qr"></div></div></div>
              <section class="card" style="margin-top:20px"><div class="card-head"><h2>Players</h2></div><div class="row" id="lg-players"></div></section>`;
            root.querySelector("#lg-url").textContent = joinUrl();
            drawQR(root.querySelector("#lg-qr"), joinUrl());
          }
          root.querySelector("#lg-url").textContent = joinUrl();
          root.querySelector("#lg-pc").textContent = `${players.length} joined`;
          root.querySelector("#lg-start").disabled = !players.length;
          root.querySelector("#lg-players").innerHTML = players.length ? players.map((p) => `<span class="tag">${esc(p.name)}</span>`).join("") : `<span class="muted">Waiting for players…</span>`;
        } else {
          const t = now() - room.startAt - room.setupMs;
          const day = Math.max(0, Math.min(DAYS, Math.floor(t / room.dayMs)));
          const setupLeft = -t;
          const ev = curEvent(day);
          const done = st === "done";
          const byRet = players.slice().sort((a, b) => (b.value || START_CASH) - (a.value || START_CASH));
          const byDisc = players.filter((p) => p.done).sort((a, b) => b.score - a.score);
          root.innerHTML = `
            <div class="page-head"><div><div class="eyebrow">Room ${esc(code)} · round ${room.round}</div><h1>${done ? "Final results" : setupLeft > 0 ? `Building portfolios… ${Math.ceil(setupLeft / 1000)} s` : `Day ${day} of ${DAYS}`}</h1></div>
              ${done ? `<button class="btn primary" id="lg-reset">New round</button>` : ""}</div>
            ${!done && setupLeft <= 0 ? `<div class="news-banner ${ev.type}" style="margin-bottom:16px"><span class="tag ${evTag[ev.type][0]}">${evTag[ev.type][1]}</span><strong style="font-size:18px">${ev.h}</strong></div><div class="progress" style="margin-bottom:16px"><i style="width:${(day / DAYS) * 100}%"></i></div>` : ""}
            <div class="grid ${done ? "g2" : ""}">
              <section class="card"><div class="card-head"><h2>${done ? "🏆 Best return" : "Live leaderboard"}</h2><span class="note">${players.length} players</span></div>
                ${byRet.map((p, i) => { const r = ((p.value || START_CASH) / START_CASH - 1) * 100; return `<div class="lb-row"><span class="num faint">${i + 1}</span><strong>${esc(p.name)}</strong><span class="num r">${F.inr(p.value || START_CASH, 0)}</span><span class="change r ${F.cls(r)}">${F.pct(r, 1)}</span></div>`; }).join("")}</section>
              ${done ? `<section class="card ai"><div class="card-head"><h2>🧠 Most disciplined</h2><span class="note">Return can be luck. Discipline isn't.</span></div>
                ${byDisc.length ? byDisc.map((p, i) => `<div class="lb-row"><span class="num faint">${i + 1}</span><div><strong>${esc(p.name)}</strong><div class="note">${esc(p.arch || "")}</div></div><span class="num r">${p.score}/100</span><span></span></div>`).join("") : `<p class="muted">Waiting for reports…</p>`}</section>` : ""}
            </div>`;
        }
        lastStatus = st;
      };
      const tick = async () => { try { const j = sync(await api("/" + code)); window.__room = j; render(j); } catch (err) { offline(err); clearInterval(poll); } };
      tick(); poll = setInterval(tick, 1000);
      root.onclick = async (e) => {
        try {
          if (e.target.closest("#lg-start")) { await api(`/${code}/start`, { hostKey: key }); tick(); }
          if (e.target.closest("#lg-reset")) { await api(`/${code}/reset`, { hostKey: key }); lastStatus = ""; tick(); }
        } catch (err) { toast(esc(err.message)); }
      };
      return stop;
    }

    /* ----- Player ----- */
    let me = ss.get("kosh.player." + code);
    let playingRound = null;
    const joinForm = (msg = "") => {
      root.innerHTML = `<div class="card" style="max-width:420px;margin:40px auto"><div class="eyebrow">Room ${esc(code)}</div><h2 style="margin:6px 0 12px">Pick a nickname</h2>
        <form id="lg-name" class="stack" novalidate><input class="input" id="lg-nick" maxlength="20" autocomplete="nickname" placeholder="e.g. Bull Run Bhavya" aria-label="Nickname"><div class="err" id="lg-err" style="color:var(--down);font-size:12px">${esc(msg)}</div><button class="btn primary">Join</button></form>
        <p class="note" style="margin-top:10px">Your nickname and results appear on the shared screen. Don't use your full name.</p></div>`;
      root.querySelector("#lg-nick").focus();
    };
    const waiting = (room) => {
      root.innerHTML = `<div class="card empty" style="max-width:480px;margin:40px auto"><div class="eyebrow">Room ${esc(code)}</div><h2 style="margin:8px 0">You're in, ${esc(me.name)}!</h2><p>Waiting for the host to start… <span id="lg-n">${room.players.length}</span> players joined.</p><p class="note">Tip: you'll have 20 seconds to build your portfolio before the market opens.</p></div>`;
    };
    const startGame = (room) => {
      playingRound = room.round;
      clearInterval(poll);
      let lastSent = -1;
      const clock = () => {
        const t = now() - room.startAt - room.setupMs;
        return { phase: t >= 0 ? "run" : "setup", day: Math.floor(t / room.dayMs), setupLeft: -t };
      };
      gameCleanup = play(root, {
        mode: "league", clock,
        onDay: (g) => { if (g.day !== lastSent) { lastSent = g.day; api(`/${code}/update`, { playerId: me.playerId, token: me.token, value: Math.round(value(g)), day: g.day }).catch(() => {}); } },
        onEnd: (g, rep) => {
          api(`/${code}/update`, { playerId: me.playerId, token: me.token, value: Math.round(rep.final), day: DAYS, score: rep.score, arch: rep.arch, done: true }).catch(() => {});
          const rankLoop = async () => {
            try {
              const j = sync(await api("/" + code));
              const el = root.querySelector("#cr-rank");
              if (j.round !== playingRound && j.status === "lobby") { clearInterval(poll); gameCleanup && gameCleanup(); gameCleanup = null; waiting(j); poll = setInterval(playerTick, 1000); return; }
              if (el) {
                const byRet = j.players.slice().sort((a, b) => (b.value || 0) - (a.value || 0));
                const byDisc = j.players.filter((p) => p.done).sort((a, b) => b.score - a.score);
                const r1 = byRet.findIndex((p) => p.id === me.playerId) + 1, r2 = byDisc.findIndex((p) => p.id === me.playerId) + 1;
                el.innerHTML = `<div class="row" style="justify-content:space-around;text-align:center"><div><div class="note">Return rank</div><div class="num" style="font-size:26px;font-weight:700">#${r1} <span class="note">of ${j.players.length}</span></div></div><div><div class="note">Discipline rank</div><div class="num" style="font-size:26px;font-weight:700">${r2 ? "#" + r2 : "…"} <span class="note">of ${byDisc.length} finished</span></div></div></div><p class="note" style="text-align:center;margin:8px 0 0">Stay on this page — a new round will load automatically when the host starts one.</p>`;
              }
            } catch {}
          };
          rankLoop(); poll = setInterval(rankLoop, 2000);
        },
      }, UI);
    };
    const playerTick = async () => {
      try {
        const room = sync(await api("/" + code));
        if (!room.players.some((p) => p.id === me.playerId)) { me = null; ss.set("kosh.player." + code, null); clearInterval(poll); joinForm("You were removed or the room restarted — join again."); return; }
        if (room.status === "running" && playingRound !== room.round) startGame(room);
        else if (room.status === "lobby") { if (!root.querySelector("#lg-n")) waiting(room); else root.querySelector("#lg-n").textContent = room.players.length; }
        else if (room.status === "done" && playingRound !== room.round) root.innerHTML = `<div class="card empty" style="max-width:480px;margin:40px auto"><h2>This round already finished</h2><p>Wait here — you'll join the next round when the host starts it.</p></div>`;
      } catch (err) { clearInterval(poll); offline(err); }
    };
    root.onsubmit = async (e) => {
      e.preventDefault();
      const name = root.querySelector("#lg-nick").value.trim();
      if (name.length < 2) { root.querySelector("#lg-err").textContent = "At least 2 characters."; return; }
      try { const j = await api(`/${code}/join`, { name }); me = { playerId: j.playerId, token: j.token, name: j.name }; ss.set("kosh.player." + code, me); playerTick(); poll = setInterval(playerTick, 1000); }
      catch (err) { root.querySelector("#lg-err").textContent = err.message; }
    };
    if (me) { playerTick(); poll = setInterval(playerTick, 1000); }
    else api("/" + code).then((r) => { sync(r); joinForm(); }).catch((err) => (/not found/i.test(err.message) ? (root.innerHTML = `<div class="card empty"><h2>Room ${esc(code)} not found</h2><p>Check the code with your host.</p><a class="btn" href="#/league">Back</a></div>`) : offline(err)));
    return stop;
  }

  function drawQR(el, text) {
    const render = () => { try { const q = window.qrcode(0, "M"); q.addData(text); q.make(); el.innerHTML = q.createSvgTag({ cellSize: 7, margin: 2, scalable: false }); } catch { el.innerHTML = ""; el.style.display = "none"; } };
    if (window.qrcode) return render();
    const s = document.createElement("script");
    s.src = "https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js";
    s.onload = render; s.onerror = () => { el.style.display = "none"; };
    document.head.appendChild(s);
  }

  return { mountSolo, mountLeague, analyze, newGame, startRun, advance, trade, value, price, ASSETS, DAYS };
})();
