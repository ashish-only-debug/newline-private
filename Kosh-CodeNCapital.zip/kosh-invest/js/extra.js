/*
 * Kosh extras: Tip Check (scam / pump-and-dump detector), Time Machine (what-if investing),
 * My Plan (risk profile, goal planner, badges & levels).
 */
window.KOSH_EXTRA = (() => {
  const M = window.KOSH_MARKET, F = window.KF, C = window.KC;
  const esc = F.esc;

  /* ================= Badges ================= */
  const BADGES = [
    ["profile", "Know thyself", "Complete your risk profile", "#/journey"],
    ["student", "First lesson", "Finish any lesson", "#/learn"],
    ["scholar", "Scholar", "Finish all lessons", "#/learn"],
    ["quiz_ace", "Quiz ace", "Answer 5 quiz questions correctly", "#/learn/quiz"],
    ["crash", "Crash survivor", "Finish a Crash Test", "#/crash"],
    ["steady", "Diamond hands", "Score 80+ discipline in a Crash Test", "#/crash"],
    ["tipcheck", "Scam spotter", "Check a stock tip with Tip Check", "#/tipcheck"],
    ["timemachine", "Time traveller", "Run a Time Machine scenario", "#/timemachine"],
    ["first_trade", "First trade", "Place a demo order in the Simulator", "#/markets"],
    ["diversified", "Diversifier", "Hold stocks from 4+ sectors", "#/portfolio"],
    ["researcher", "Researcher", "Tick every item on a stock's research checklist", "#/markets"],
    ["comparer", "Side by side", "Compare companies", "#/compare"],
    ["news", "Informed", "Open an AI news impact analysis", "#/news"],
    ["alert", "On watch", "Create an alert", "#/alerts"],
    ["goal", "Planner", "Plan a savings goal", "#/journey"],
    ["funds", "Fund explorer", "Open a real mutual fund in the Fund Explorer", "#/funds"],
    ["headlines", "News reader", "Read today's live market headlines", "#/headlines"],
  ];
  const LEVELS = [[0, "Rookie"], [300, "Learner"], [700, "Investor"], [1100, "Pro"], [1400, "Mentor"]];
  function level(badges) {
    const xp = Object.keys(badges || {}).length * 100;
    let i = 0; while (i + 1 < LEVELS.length && xp >= LEVELS[i + 1][0]) i++;
    const next = LEVELS[i + 1];
    return { xp, name: LEVELS[i][1], idx: i, next: next ? next[1] : null, toNext: next ? next[0] - xp : 0, pct: next ? ((xp - LEVELS[i][0]) / (next[0] - LEVELS[i][0])) * 100 : 100 };
  }

  /* ================= Tip Check ================= */
  const RULES = [
    { key: "guarantee", w: 30, label: "Guaranteed or risk-free returns",
      re: /\b(guarantee[ds]?|assured|100\s?%\s?(sure|safe|profit|guaranteed)|risk[\s-]?free|no[\s-]?loss|zero[\s-]?risk|sure[\s-]?shot|fixed (daily|weekly|monthly) (return|profit))\b/gi,
      why: "Nobody can guarantee stock returns. SEBI-registered advisers aren't allowed to promise them. This is the most common sign of fraud." },
    { key: "insider", w: 25, label: "Claims of insider or secret information",
      re: /\b(insider|inside (news|info|information|tip)|operator|operators|sources say|confidential|secret (tip|stock|news)|big news (coming|soon)|before (the )?(announcement|news) (comes|is out))\b/gi,
      why: "Trading on real insider information is illegal. “Operator” stocks usually mean someone is manipulating the price, and the people who buy late are the ones who lose." },
    { key: "unreal", w: 20, label: "Unrealistic return claims",
      re: /\b(\d{1,2}x|double (your )?money|multi[\s-]?bagger|jackpot|\d{2,4}\s?%\s?(return|profit|gain|upside)?\s?(in|within)\s?\d*\s?(day|days|week|weeks|month|months))\b/gi,
      why: "Broad markets have historically returned around 10–14% a year. Promises of 50% in weeks only come true by luck, or because someone is pumping the stock." },
    { key: "pay", w: 20, label: "Asks you to pay or join a paid group",
      re: /\b(vip|premium (group|tips|channel)|paid (group|tips|channel)|join (our |my )?(telegram|whatsapp|group|channel)|subscription|send (₹|rs\.?|inr)?\s?\d+|upi|pay (now|first|₹|rs)|dm (me|now)|registration fee|joining fee)\b/gi,
      why: "Scammers make money from fees or by selling to their followers. Genuine research doesn't need you to pay into a stranger's UPI ID." },
    { key: "urgency", w: 15, label: "Pressure to act immediately",
      re: /\b(buy now|today only|last chance|before it'?s too late|hurry|limited (time|seats|offer)|don'?t miss|act fast|right now|immediately|urgent|tomorrow it will|rocket|to the moon)\b|🚀|🔥{2,}/gi,
      why: "Urgency stops you from checking facts. Real opportunities don't disappear in an hour, but pump-and-dumps do." },
    { key: "penny", w: 10, label: "Penny or obscure stock signals",
      re: /\b(penny|small[\s-]?cap gem|hidden gem|low[\s-]?price(d)? (stock|share)|under ₹?\s?\d{1,2}\b|sme (stock|ipo))\b/gi,
      why: "Tiny, thinly traded stocks are easy to push up with a few buyers and then dump. That is how pump-and-dump schemes work." },
    { key: "private", w: 10, label: "Secrecy or exclusivity",
      re: /\b(don'?t share|only for you|exclusive|members only|keep (it|this) (secret|private)|forward (to|this))\b/gi,
      why: "Real analysis is happy to be checked. Secrecy is a way to avoid scrutiny." },
    { key: "emotion", w: 10, label: "Get-rich-quick emotion",
      re: /\b(life[\s-]?changing|become rich|get rich|retire early|lottery|easy money|quit your job|dream (car|house|life))\b/gi,
      why: "Appeals to dreams and FOMO replace evidence with emotion." },
  ];
  const GOOD = [
    { key: "fund", label: "Talks about fundamentals", re: /\b(revenue|net profit|operating profit|profit (margin|growth|grew)|earnings (growth|per share)|margins?|debt|cash flow|valuation|p\/e|pe ratio|balance sheet|order book|eps)\b/gi },
    { key: "risk", label: "Mentions risk honestly", re: /\b(risk|could fall|may fall|downside|not (financial|investment) advice|do your own research|dyor|volatile|stop[\s-]?loss)\b/gi },
    { key: "source", label: "Cites verifiable sources", re: /\b(annual report|quarterly results|exchange filing|investor presentation|bse filing|nse filing|concall|earnings call)\b/gi },
    { key: "reg", label: "Shows a SEBI registration number", re: /\b(INA|INH)\d{9}\b/g },
  ];
  const SAMPLES = [
    ["WhatsApp forward", "🚀🚀 URGENT!! Operator stock ALERT 🔥🔥 Buy MAHAGROW INFRA at ₹8 before the big news comes tomorrow. Target ₹40 in 2 weeks — 400% profit GUARANTEED, sure shot multibagger. Insider info from our sources. Join our VIP Telegram group, fees ₹2,999 by UPI. Don't share this, only for you!"],
    ["Instagram finfluencer", "This hidden gem small-cap could be life-changing 💸 I bought it today, already up 18%. It will double your money in 3 months, trust me. Don't miss it — link in bio to join my premium channel. Not financial advice 😉"],
    ["Analyst-style note", "Kshetra Agro Foods (KSHT): revenue grew ~7% a year over FY22–FY26 with steady margins and low debt. The P/E of ~40 is high for single-digit growth, so the downside risk if growth slows is meaningful. Read the latest quarterly results and annual report before deciding. Do your own research."],
  ];
  function analyzeTip(text) {
    const hits = [], marks = [];
    for (const r of RULES) {
      const found = [...text.matchAll(r.re)].map((m) => ({ s: m.index, e: m.index + m[0].length, t: m[0] }));
      if (found.length) { hits.push({ ...r, found }); found.forEach((f) => marks.push({ ...f, kind: "bad" })); }
    }
    const goods = [];
    for (const g of GOOD) {
      const found = [...text.matchAll(g.re)].map((m) => ({ s: m.index, e: m.index + m[0].length, t: m[0] }));
      if (found.length) { goods.push({ ...g, found }); found.forEach((f) => marks.push({ ...f, kind: "good" })); }
    }
    const caps = (text.match(/\b[A-Z]{4,}\b/g) || []).filter((w) => !/^(INA|INH|SEBI|NSE|BSE|IPO|EPS|UPI|VIP|SME)/.test(w) && !M.bySym(w)).length;
    const excl = (text.match(/!{2,}/g) || []).length;
    let score = hits.reduce((s, h) => s + h.w, 0) + Math.min(10, caps * 2 + excl * 3) - goods.reduce((s, g) => s + (g.key === "reg" ? 6 : 5), 0);
    score = Math.max(0, Math.min(100, score));
    const band = score >= 60 ? ["Very high risk", "down", "This has several hallmarks of a pump-and-dump or advisory scam. Don't send money and don't buy on this basis."]
      : score >= 35 ? ["High risk", "down", "Multiple warning signs. Treat this as marketing, not research."]
      : score >= 15 ? ["Caution", "warn", "Some red flags. Verify everything independently before acting."]
      : ["Few red flags found", "up", "No major scam patterns detected. That doesn't make it a good investment: still check the fundamentals."];
    const syms = M.companies.filter((c) => new RegExp("\\b(" + c.sym + "|" + c.name.split(" ")[0] + ")\\b", "i").test(text)).map((c) => c.sym);
    // highlighted html (non-overlapping, earliest first)
    marks.sort((a, b) => a.s - b.s || b.e - a.e);
    let html = "", pos = 0;
    for (const m of marks) { if (m.s < pos) continue; html += esc(text.slice(pos, m.s)) + `<mark class="${m.kind}">${esc(text.slice(m.s, m.e))}</mark>`; pos = m.e; }
    html += esc(text.slice(pos));
    return { score, band, hits, goods, html, syms, caps, excl };
  }
  function tipcheck(root, UI) {
    root.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">Protect yourself</div><h1>Tip Check</h1><p>Got a “sure-shot” stock tip on WhatsApp, Telegram or Instagram? Paste it here. Kosh highlights the pump-and-dump warning signs and explains each one.</p></div></div>
      <div class="grid g-main" style="align-items:start">
        <div class="stack" style="gap:16px">
          <section class="card">
            <div class="field"><label for="tc-in">The tip or message</label><textarea class="input" id="tc-in" rows="6" placeholder="Paste the message here…" style="resize:vertical"></textarea></div>
            <div class="row" style="margin-top:10px"><button class="btn primary" id="tc-go">Check this tip</button><span class="note">Try an example:</span>${SAMPLES.map((s, i) => `<button class="chip" data-sample="${i}">${s[0]}</button>`).join("")}</div>
            <p class="note" style="margin-top:8px">Checked entirely in your browser. Nothing you paste is sent anywhere.</p>
          </section>
          <div id="tc-out"></div>
        </div>
        <aside class="stack" style="gap:16px">
          <section class="card"><div class="card-head"><h2>${UI.ic("shield", 'width="18" height="18"')} Before acting on any tip</h2></div>
            <ol class="bullets" style="padding-left:20px"><li>Check that the adviser is SEBI-registered. Search the registration number (INA… or INH…) on <strong>sebi.gov.in</strong>.</li><li>Look up the company's own results and filings on the NSE or BSE website, not in the message.</li><li>Ask why <em>this</em> person is telling <em>you</em>. What do they gain?</li><li>Never pay a stranger's UPI ID for “guaranteed” tips.</li><li>If you were cheated: complain on SEBI SCORES (<strong>scores.sebi.gov.in</strong>), and report fraud at <strong>cybercrime.gov.in</strong> or helpline <strong>1930</strong>.</li></ol></section>
          <section class="card"><div class="card-head"><h2>How a pump-and-dump works</h2></div>
            <div class="stack" style="gap:8px">${[["1", "Operators quietly buy a tiny, cheap stock."], ["2", "They flood groups with “guaranteed multibagger” tips."], ["3", "Followers buy and the price shoots up."], ["4", "Operators sell everything to those followers."], ["5", "The price collapses. Late buyers are left holding the loss."]].map(([n, t]) => `<div class="row" style="flex-wrap:nowrap;align-items:flex-start"><span class="tag ${n === "5" ? "down" : n === "4" ? "warn" : ""}">${n}</span><span>${t}</span></div>`).join("")}</div>
            <div class="chart" id="tc-pump" style="margin-top:10px"></div></section>
        </aside>
      </div>`;
    // illustrative pump & dump curve
    const pts = []; for (let d = 0; d <= 40; d++) { const p = d < 10 ? 8 + d * 0.05 : d < 22 ? 8.5 + (d - 10) ** 1.7 * 0.55 : Math.max(5, 32 - (d - 22) * 2.4 + Math.sin(d) * 0.8); pts.push({ t: d, p }); }
    C.line(root.querySelector("#tc-pump"), { series: [{ name: "Illustrative price", color: "var(--down)", data: pts }], height: 140, fmtT: (d) => "Day " + d, label: "Illustrative pump and dump" });
    const run = () => {
      const text = root.querySelector("#tc-in").value.trim();
      const out = root.querySelector("#tc-out");
      if (text.length < 15) { out.innerHTML = `<div class="card empty">Paste a longer message (at least a sentence) to check it.</div>`; return; }
      const r = analyzeTip(text);
      out.innerHTML = `
        <section class="card">
          <div class="row" style="gap:20px;align-items:center">
            <div class="score-ring" style="--v:${r.score};background:conic-gradient(var(--${r.band[1]}) calc(var(--v) * 1%), var(--surface-3) 0)" role="img" aria-label="Scam risk ${r.score} of 100"><div>${r.score}</div></div>
            <div style="flex:1;min-width:220px"><div class="note">Scam-pattern score</div><h2 class="${r.band[1]}" style="margin:2px 0 6px">${r.band[0]}</h2><p class="muted" style="margin:0">${r.band[2]}</p></div>
          </div>
          <div class="divider"></div>
          <div class="eyebrow" style="margin-bottom:6px">Your message, annotated</div>
          <div class="tip-text">${r.html}</div>
          <div class="legend" style="margin-top:8px"><span><i style="background:var(--down)"></i>Red flag</span><span><i style="background:var(--up)"></i>Good sign</span></div>
        </section>
        ${r.hits.length ? `<section class="card"><div class="card-head"><h2>Red flags (${r.hits.length})</h2></div><div class="stack">${r.hits.map((h) => `<div class="flag bad"><div class="spread"><strong>▼ ${h.label}</strong><span class="tag down">+${h.w}</span></div><p style="margin:6px 0">Found: ${[...new Set(h.found.map((f) => "“" + esc(f.t) + "”"))].slice(0, 4).join(", ")}</p><p class="muted" style="margin:0">${h.why}</p></div>`).join("")}</div></section>` : ""}
        ${r.goods.length ? `<section class="card"><div class="card-head"><h2>Good signs</h2></div><div class="stack">${r.goods.map((g) => `<div class="flag good"><strong>▲ ${g.label}</strong> <span class="note">${[...new Set(g.found.map((f) => esc(f.t)))].slice(0, 4).join(", ")}</span>${g.key === "reg" ? `<p class="note" style="margin:4px 0 0">A number alone proves nothing. Scammers copy real ones, so check the name matches on sebi.gov.in.</p>` : ""}</div>`).join("")}</div></section>` : ""}
        ${r.syms.length ? `<section class="card"><div class="card-head"><h2>Check the facts yourself</h2></div><p class="muted">This message mentions companies in Kosh's demo universe. Look at their real numbers before trusting the claim:</p><div class="row">${r.syms.map((s) => `<a class="btn sm" href="#/stock/${s}">${s}: fundamentals & risk</a>`).join("")}</div></section>` : ""}
        <p class="note">Tip Check looks for common scam patterns. It can't verify facts, so a low score doesn't make a tip good and a high score doesn't prove fraud.</p>`;
      UI.award("tipcheck");
    };
    root.onclick = (e) => {
      const s = e.target.closest("[data-sample]");
      if (s) { root.querySelector("#tc-in").value = SAMPLES[+s.dataset.sample][1]; run(); }
      if (e.target.closest("#tc-go")) run();
    };
    return () => { root.onclick = null; };
  }

  /* ================= Time Machine ================= */
  function timemachine(root, UI) {
    const opts = [["NIFTY", "Simulated NIFTY 50 index"], ...M.companies.map((c) => [c.sym, `${c.sym} — ${c.name}`])];
    const st = { sym: "NIFTY", amt: 100000, yrs: 3, fd: 7 };
    root.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">What if…?</div><h1>Time Machine</h1><p>Go back in time and invest. See what you'd have now, and how much the ride would have <em>hurt</em> along the way.</p></div><span class="tag warn">Simulated history</span></div>
      <div class="card" style="margin-bottom:16px"><div class="grid g4" style="align-items:end">
        <div class="field"><label for="tm-sym">Invest in</label><select class="input" id="tm-sym">${opts.map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join("")}</select></div>
        <div class="field"><label for="tm-amt">Total amount</label><select class="input" id="tm-amt">${[10000, 50000, 100000, 500000].map((a) => `<option value="${a}" ${a === st.amt ? "selected" : ""}>${F.inr(a, 0)}</option>`).join("")}</select></div>
        <div class="field"><div class="spread"><label for="tm-yrs">How long ago</label><span class="num" id="tm-yrs-l"></span></div><input type="range" id="tm-yrs" min="0.5" max="5" step="0.5" value="${st.yrs}"></div>
        <div class="field"><div class="spread"><label for="tm-fd">Bank FD rate to compare</label><span class="num" id="tm-fd-l"></span></div><input type="range" id="tm-fd" min="4" max="9" step="0.25" value="${st.fd}"></div>
      </div></div>
      <div id="tm-out"></div>`;
    const series = (sym) => sym === "NIFTY" ? M.indexSeries(M.indexDefs[0], "ALL") : M.series(sym, "ALL");
    const draw = () => {
      st.sym = root.querySelector("#tm-sym").value; st.amt = +root.querySelector("#tm-amt").value;
      st.yrs = +root.querySelector("#tm-yrs").value; st.fd = +root.querySelector("#tm-fd").value;
      root.querySelector("#tm-yrs-l").textContent = st.yrs + (st.yrs === 1 ? " year" : " years");
      root.querySelector("#tm-fd-l").textContent = st.fd + "%";
      const all = series(st.sym);
      const n = Math.min(all.length - 1, Math.round(st.yrs * 252));
      const s = all.slice(all.length - 1 - n);
      const name = st.sym === "NIFTY" ? "the simulated NIFTY 50" : M.bySym(st.sym).c.name;
      // lump sum
      const units = st.amt / s[0].p;
      const lump = s.map((x) => ({ t: x.t, p: units * x.p }));
      let peak = lump[0].p, mdd = 0, mddAt = lump[0].t, low = lump[0], under = 0;
      lump.forEach((x) => { peak = Math.max(peak, x.p); const dd = x.p / peak - 1; if (dd < mdd) { mdd = dd; mddAt = x.t; } if (x.p < low.p) low = x; if (x.p < st.amt) under++; });
      const final = lump.at(-1).p;
      const cagr = Math.pow(final / st.amt, 1 / st.yrs) - 1;
      // SIP: same total, monthly
      const months = Math.max(1, Math.floor(n / 21) + 1), m = st.amt / months;
      let su = 0, inv = 0;
      const sip = s.map((x, i) => { if (i % 21 === 0 && inv < st.amt - 1) { su += m / x.p; inv += m; } return { t: x.t, p: su * x.p, inv }; });
      const sipFinal = sip.at(-1).p;
      const fd = s.map((x, i) => ({ t: x.t, p: st.amt * Math.pow(1 + st.fd / 100, i / 252) }));
      const fdFinal = fd.at(-1).p;
      // panic at the bottom then FD
      const lowIdx = lump.indexOf(low);
      const panic = low.p * Math.pow(1 + st.fd / 100, (lump.length - 1 - lowIdx) / 252);
      const best = [["Lump sum", final, "var(--accent)"], ["Monthly SIP (same total)", sipFinal, "var(--c2)"], [`Bank FD at ${st.fd}%`, fdFinal, "var(--c4)"], ["Panicked at the bottom, then FD", panic, "var(--down)"]];
      const max = Math.max(...best.map((b) => b[1]));
      const winner = best.slice(0, 3).sort((a, b) => b[1] - a[1])[0][0];
      root.querySelector("#tm-out").innerHTML = `
        <div class="grid g4" style="margin-bottom:16px">
          <div class="card stat"><div class="label">You'd have today</div><div class="value">${F.inr(final, 0)}</div><div class="note"><span class="${F.cls(final - st.amt)}">${F.signed(final - st.amt, 0)}</span> · ${F.pct(cagr * 100, 1)}/yr</div></div>
          <div class="card stat"><div class="label">Worst moment ${UI.info("hi52")}</div><div class="value down">${F.pct(mdd * 100, 1)}</div><div class="note">from peak, on ${F.date(mddAt)}</div></div>
          <div class="card stat"><div class="label">Lowest value</div><div class="value">${F.inr(low.p, 0)}</div><div class="note">${low.p < st.amt ? `down ${F.inr(st.amt - low.p, 0)} on ${F.date(low.t)}` : "never below what you put in"}</div></div>
          <div class="card stat"><div class="label">Days underwater</div><div class="value">${under}</div><div class="note">of ${lump.length} trading days below ${F.inr(st.amt, 0)}</div></div>
        </div>
        <div class="grid g-main" style="align-items:start">
          <section class="card"><div class="card-head"><h2>Your money over time</h2><div class="legend"><span><i style="background:var(--accent)"></i>Lump sum</span><span><i style="background:var(--c2)"></i>SIP</span><span><i style="background:var(--c4)"></i>FD</span></div></div>
            <div class="chart" id="tm-chart"></div>
            <div class="chart-explain"><span class="ai-tag">${UI.ic("spark", 'width="12" height="12"')} The story</span><p style="margin:8px 0 0">On <strong>${F.date(s[0].t)}</strong> you put <strong>${F.inr(st.amt, 0)}</strong> into ${esc(name)}. ${mdd < -0.15 ? `Along the way it fell <strong class="down">${F.pct(mdd * 100, 0)}</strong> from its high (around ${F.date(mddAt, { month: "short", year: "numeric" })}). Would you have held on? ` : "It was a fairly smooth ride. "}${under > lump.length * 0.3 ? `You'd have spent <strong>${Math.round((under / lump.length) * 100)}%</strong> of the time looking at a loss. ` : ""}Today it's worth <strong>${F.inr(final, 0)}</strong>. ${panic < final ? `If you had panic-sold at the lowest point and moved to an FD, you'd have just <strong class="down">${F.inr(panic, 0)}</strong>.` : ""} Over this period, <strong>${winner}</strong> came out ahead.</p></div>
          </section>
          <section class="card"><div class="card-head"><h2>Four ways it could have gone</h2></div>
            ${best.map(([l, v, c]) => `<div class="bench-row" style="grid-template-columns:1fr 1fr 96px"><span class="note">${l}</span><div class="bench-bar"><i style="width:${(v / max) * 100}%;background:${c}"></i></div><span class="num r ${F.cls(v - st.amt)}">${F.inr(v, 0)}</span></div>`).join("")}
            <div class="divider"></div>
            <p class="muted" style="margin:0"><strong style="color:var(--text)">Lump sum vs SIP:</strong> a lump sum wins when prices mostly rise after you invest. A SIP spreads out your entry, buying more units when prices dip. It's smoother on the nerves, but can lag in a strong uptrend.</p>
          </section>
        </div>
        <p class="note" style="margin-top:12px">Based on Kosh's simulated price history for fictional companies. It ignores taxes and charges; see the tax calculator in the Learning Centre. Past performance, simulated or real, doesn't predict the future.</p>`;
      C.line(root.querySelector("#tm-chart"), { series: [{ name: "Lump sum", color: "var(--accent)", data: lump }, { name: "SIP", color: "var(--c2)", data: sip }, { name: "FD", color: "var(--c4)", data: fd }], tf: "1Y", height: 260, label: "Time machine chart" });
    };
    root.oninput = () => { draw(); UI.award("timemachine"); }; root.onchange = root.oninput;
    draw();
    return () => { root.oninput = null; root.onchange = null; };
  }

  /* ================= My Plan (risk profile, goals, badges) ================= */
  const QS = [
    ["When will you need this money?", ["Within 1 year", "1–3 years", "3–7 years", "7+ years"], [0, 1, 2, 3]],
    ["Your investments drop 20% in a month. You…", ["Sell everything", "Sell some", "Do nothing", "Invest more"], [0, 1, 2, 3]],
    ["Do you have 6 months of expenses saved as an emergency fund?", ["No", "Partly", "Yes"], [0, 1, 2]],
    ["Your income is…", ["None yet (student)", "Irregular", "Stable salary or allowance"], [0, 1, 2]],
    ["Your investing experience?", ["None", "FDs or mutual funds", "Bought stocks before"], [0, 1, 2]],
    ["Your main goal?", ["Protect what I have", "Steady growth", "Maximum long-term growth"], [0, 1, 3]],
  ];
  const PROFILES = {
    Conservative: { r: 7, v: 4, mix: [["FD / debt funds", 60, "var(--c4)"], ["Index funds", 25, "var(--c2)"], ["Gold", 10, "var(--gold)"], ["Individual stocks", 5, "var(--c1)"]], d: "Capital protection first. Slow and steady, with small swings." },
    Balanced: { r: 9, v: 9, mix: [["FD / debt funds", 40, "var(--c4)"], ["Index funds", 40, "var(--c2)"], ["Gold", 10, "var(--gold)"], ["Individual stocks", 10, "var(--c1)"]], d: "A mix of safety and growth. You can live with moderate dips." },
    Growth: { r: 11, v: 13, mix: [["FD / debt funds", 25, "var(--c4)"], ["Index funds", 50, "var(--c2)"], ["Gold", 10, "var(--gold)"], ["Individual stocks", 15, "var(--c1)"]], d: "Long horizon, comfortable with bumps along the way." },
    Aggressive: { r: 12, v: 16, mix: [["FD / debt funds", 15, "var(--c4)"], ["Index funds", 55, "var(--c2)"], ["Gold", 5, "var(--gold)"], ["Individual stocks", 25, "var(--c1)"]], d: "Maximum growth over many years. You can sit through 30%+ falls." },
  };
  function profileOf(ans) {
    const score = ans.reduce((s, a, i) => s + QS[i][2][a], 0);
    let p = score <= 5 ? "Conservative" : score <= 9 ? "Balanced" : score <= 12 ? "Growth" : "Aggressive";
    const notes = [];
    if (ans[0] === 0) { p = "Conservative"; notes.push("You need the money within a year, so stocks are too risky for it no matter how brave you feel."); }
    if (ans[1] === 0 && (p === "Growth" || p === "Aggressive")) { p = "Balanced"; notes.push("You said you'd sell everything in a 20% fall. A calmer mix helps you avoid locking in losses."); }
    if (ans[2] === 0) notes.push("Build an emergency fund first, in a savings account or liquid fund, so you're never forced to sell investments in a bad month.");
    return { score, p, notes, ...PROFILES[p] };
  }
  function journey(root, UI) {
    const S = UI.S();
    const answers = S.profile ? S.profile.ans.slice() : [];
    const render = () => {
      const lv = level(S.badges);
      const prof = S.profile ? profileOf(S.profile.ans) : null;
      root.innerHTML = `
        <div class="page-head"><div><div class="eyebrow">Personal</div><h1>My Plan</h1><p>Your risk profile, a goal plan and your progress, all in one place. Educational guidance, not advice.</p></div></div>
        <section class="card hero" style="margin-bottom:16px"><div class="row" style="gap:20px;align-items:center">
          <div class="score-ring" style="--v:${lv.pct}"><div style="font-size:16px;text-align:center;line-height:1.2">Lv ${lv.idx + 1}<br><span class="note">${lv.name}</span></div></div>
          <div style="flex:1;min-width:220px"><h2>${lv.xp} XP · ${Object.keys(S.badges).length}/${BADGES.length} badges</h2><p class="muted" style="margin:4px 0 0">${lv.next ? `${lv.toNext} XP to <strong>${lv.next}</strong>. Each badge is worth 100 XP.` : "Max level, nicely done!"}</p></div></div></section>
        <div class="grid g-main" style="align-items:start">
          <div class="stack" style="gap:16px">
            <section class="card" id="rp"><div class="card-head"><h2>${UI.ic("shield", 'width="18" height="18"')} Risk profile</h2>${prof ? `<button class="btn sm ghost" id="rp-redo">Retake</button>` : ""}</div><div id="rp-body"></div></section>
            <section class="card"><div class="card-head"><h2>Goal planner</h2></div>
              <div class="grid g3"><div class="field"><label for="gp-name">Goal</label><input class="input" id="gp-name" value="${esc(S.goal?.name || "New laptop")}" maxlength="40"></div>
                <div class="field"><label for="gp-amt">Target amount (₹)</label><input class="input num" id="gp-amt" inputmode="numeric" value="${S.goal?.amt || 80000}"></div>
                <div class="field"><label for="gp-cur">Already saved (₹)</label><input class="input num" id="gp-cur" inputmode="numeric" value="${S.goal?.cur ?? 5000}"></div></div>
              <div class="grid g2" style="margin-top:10px"><div class="field"><div class="spread"><label for="gp-yrs">Time to goal</label><span class="num" id="gp-yrs-l"></span></div><input type="range" id="gp-yrs" min="0.5" max="20" step="0.5" value="${S.goal?.yrs || 2}"></div>
                <div class="field"><label for="gp-inf">Inflation per year (%)</label><input class="input num" id="gp-inf" inputmode="decimal" value="${S.goal?.inf ?? ""}" placeholder="loading…"><span class="note" id="gp-inf-src"></span></div></div>
              <div id="gp-out" style="margin-top:12px"></div></section>
          </div>
          <section class="card"><div class="card-head"><h2>Badges</h2></div><div class="badge-grid">${BADGES.map(([id, n, how, link]) => `<a class="badge-tile ${S.badges[id] ? "got" : ""}" href="${link}" title="${esc(how)}"><span class="badge-ico">${S.badges[id] ? "🏅" : "🔒"}</span><strong>${n}</strong><span class="note">${how}</span></a>`).join("")}</div></section>
        </div>`;
      // risk profile body
      const body = root.querySelector("#rp-body");
      if (prof && answers.length === QS.length) {
        body.innerHTML = `<div class="row" style="gap:20px;align-items:center"><div id="rp-donut"></div><div style="flex:1;min-width:220px"><div class="note">Your profile</div><h2 style="color:var(--accent-text)">${prof.p}</h2><p class="muted">${prof.d}</p>
          <div class="legend">${prof.mix.map(([l, v, c]) => `<span><i style="background:${c}"></i>${l} ${v}%</span>`).join("")}</div></div></div>
          ${prof.notes.map((n) => `<div class="flag bad" style="margin-top:10px">${n}</div>`).join("")}
          <p class="note" style="margin-top:10px">An example mix for learning, not a recommendation. Assumes about ${prof.r}% a year long-term with typical yearly swings of ±${prof.v}%.</p>`;
        C.donut(body.querySelector("#rp-donut"), { items: prof.mix.map(([label, value, color]) => ({ label, value, color })), center: ["Example", "mix"], size: 160 });
      } else {
        const i = answers.length;
        body.innerHTML = `<div class="spread note" style="margin-bottom:6px"><span>Question ${i + 1} of ${QS.length}</span><span>${Math.round((i / QS.length) * 100)}%</span></div><div class="lesson-progress" style="margin-bottom:14px"><i style="width:${(i / QS.length) * 100}%"></i></div>
          <p style="font-weight:600;font-size:15px">${QS[i][0]}</p>${QS[i][1].map((o, k) => `<button class="quiz-opt" data-rp="${k}">${o}</button>`).join("")}${i ? `<button class="btn sm ghost" id="rp-back">Back</button>` : ""}`;
      }
      goal();
      setTimeout(fillInf);
    };
    const goal = () => {
      const prof = S.profile ? profileOf(S.profile.ans) : profileOf([2, 2, 2, 2, 1, 1]);
      const name = root.querySelector("#gp-name").value.trim() || "Goal";
      const amt = Math.max(0, parseFloat(root.querySelector("#gp-amt").value.replace(/[,₹\s]/g, "")) || 0);
      const cur = Math.max(0, parseFloat(root.querySelector("#gp-cur").value.replace(/[,₹\s]/g, "")) || 0);
      const yrs = +root.querySelector("#gp-yrs").value;
      root.querySelector("#gp-yrs-l").textContent = yrs + (yrs === 1 ? " year" : " years");
      const infRaw = root.querySelector("#gp-inf").value.trim();
      const inf = infRaw === "" ? 0 : Math.max(0, Math.min(25, parseFloat(infRaw) || 0));
      S.goal = { name, amt, cur, yrs, inf: infRaw === "" ? null : inf }; UI.save();
      const target = amt * Math.pow(1 + inf / 100, yrs);
      // short goals shouldn't be in equity
      const r = (yrs < 3 ? Math.min(prof.r, 7) : prof.r) / 100;
      const need = (rate) => { const rm = rate / 12, N = Math.round(yrs * 12); const fvCur = cur * Math.pow(1 + rate, yrs); const fac = rm ? ((Math.pow(1 + rm, N) - 1) / rm) * (1 + rm) : N; return Math.max(0, (target - fvCur) / fac); };
      const proj = (rate, m) => { const rm = rate / 12, N = Math.round(yrs * 12); return cur * Math.pow(1 + rate, yrs) + (rm ? m * ((Math.pow(1 + rm, N) - 1) / rm) * (1 + rm) : m * N); };
      const m = need(r);
      const lo = yrs < 3 ? r - 0.01 : r - 0.04, hi = yrs < 3 ? r + 0.01 : r + 0.03;
      const out = root.querySelector("#gp-out");
      if (!amt) { out.innerHTML = `<p class="err" style="color:var(--down)">Enter a target amount.</p>`; return; }
      if (cur * Math.pow(1 + r, yrs) >= target) { out.innerHTML = `<div class="flag good">You already have enough for <strong>${esc(name)}</strong>. Keep it somewhere safe until you need it.</div>`; return; }
      out.innerHTML = `${inf > 0 ? `<div class="chart-explain" style="margin:0 0 10px">At ${inf}% inflation, what costs <strong>${F.inr(amt, 0)}</strong> today will cost about <strong>${F.inr(target, 0)}</strong> in ${yrs} years. The plan below aims for that higher amount.</div>` : ""}<div class="grid g3"><div class="stat-mini"><span class="label">Save each month</span><span class="value">${F.inr(m, 0)}</span></div><div class="stat-mini"><span class="label">Assumed return</span><span class="value">${(r * 100).toFixed(1)}%/yr</span></div><div class="stat-mini"><span class="label">You'll put in</span><span class="value">${F.inr(cur + m * Math.round(yrs * 12), 0)}</span></div></div>
        <div class="chart-explain"><strong>Reality check:</strong> saving ${F.inr(m, 0)} a month, a weak market could leave you with <strong class="down">${F.inr(proj(lo, m), 0)}</strong> and a good one with <strong class="up">${F.inr(proj(hi, m), 0)}</strong> by the deadline. ${yrs < 3 ? "Because the goal is under 3 years away, Kosh assumes FD-like returns: money you need soon shouldn't ride the stock market." : `With ${yrs} years, a ${prof.p.toLowerCase()} mix can absorb dips, but plan a cushion in case the market is down when you need the money.`}</div>`;
    };
    root.onclick = (e) => {
      const o = e.target.closest("[data-rp]");
      if (o) { answers.push(+o.dataset.rp); if (answers.length === QS.length) { S.profile = { ans: answers.slice(), at: Date.now() }; UI.save(); UI.award("profile"); } render(); return; }
      if (e.target.closest("#rp-back")) { answers.pop(); render(); }
      if (e.target.closest("#rp-redo")) { answers.length = 0; S.profile = null; UI.save(); render(); }
    };
    root.oninput = (e) => { if (e.target.closest("[id^=gp-]")) { goal(); UI.award("goal"); } };
    render();
    function fillInf() {
      const el = root.querySelector("#gp-inf"); if (!el) return;
      window.KOSH_REAL.inflation().then((x) => {
        if (!document.body.contains(el)) return; // user left the page before data arrived
        const src = root.querySelector("#gp-inf-src"); if (!src) return;
        src.textContent = `India's average was ${x.avg10.toFixed(1)}% over ${x.span[0]}–${x.span[1]} (World Bank CPI${x.stale ? ", cached" : ""}).`;
        if (el.value === "") { el.value = x.avg10.toFixed(1); goal(); }
      }).catch(() => { const src = root.querySelector("#gp-inf-src"); if (src) src.textContent = "Live inflation data unavailable. Enter your own estimate."; if (el.value === "") el.placeholder = "e.g. 5"; });
    }
    return () => { root.onclick = null; root.oninput = null; };
  }

  return { BADGES, level, tipcheck, timemachine, journey, analyzeTip, profileOf };
})();
