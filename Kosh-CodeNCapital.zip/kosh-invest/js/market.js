/*
 * Simulated market: deterministic price history per company, derived metrics,
 * simulated intraday ticks and two simulated index levels. Nothing here is live data.
 */
window.KOSH_MARKET = (() => {
  const D = window.KOSH_DATA;
  const DAYS = 1260; // ~5 years of trading days
  const INTRA = 75; // 5-minute bars in a session

  function rngFor(seedStr) {
    let h = 1779033703 ^ seedStr.length;
    for (let i = 0; i < seedStr.length; i++) {
      h = Math.imul(h ^ seedStr.charCodeAt(i), 3432918353);
      h = (h << 13) | (h >>> 19);
    }
    let a = h >>> 0;
    const next = () => {
      a |= 0; a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    next.normal = () => {
      const u = Math.max(next(), 1e-9), v = next();
      return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
    };
    return next;
  }

  // Trading dates (weekdays) ending yesterday.
  function tradingDates(n) {
    const out = [];
    const d = new Date();
    d.setHours(15, 30, 0, 0);
    d.setDate(d.getDate() - 1);
    while (out.length < n) {
      const wd = d.getDay();
      if (wd !== 0 && wd !== 6) out.push(new Date(d));
      d.setDate(d.getDate() - 1);
    }
    return out.reverse();
  }
  const dates = tradingDates(DAYS);

  const session = (() => {
    const s = new Date(); s.setHours(9, 15, 0, 0);
    return s;
  })();

  const stocks = {};
  for (const c of D.companies) {
    const r = rngFor(c.sym);
    const mu = c.drift / 252, sd = c.vol / Math.sqrt(252);
    const todayRet = r.normal() * sd * 0.9 + mu;
    const prevClose = c.price / Math.exp(todayRet);
    // Build backwards from prevClose so the series ends exactly there.
    const closes = new Array(DAYS);
    const vols = new Array(DAYS);
    closes[DAYS - 1] = prevClose;
    const rets = [];
    for (let i = DAYS - 1; i > 0; i--) {
      // occasional regime shocks make charts feel realistic
      const shock = r() < 0.012 ? r.normal() * sd * 3 : 0;
      const ret = mu + sd * r.normal() + shock;
      rets[i] = ret;
      closes[i - 1] = closes[i] / Math.exp(ret);
    }
    rets[0] = 0;
    const baseVol = c.shares * 1e7 * 0.0012;
    for (let i = 0; i < DAYS; i++) {
      vols[i] = Math.round(baseVol * (0.55 + r() * 0.9) * (1 + 22 * Math.abs(rets[i] || 0)));
    }
    // Intraday bridge from prevClose to current price.
    const intra = [];
    let x = Math.log(prevClose);
    const target = Math.log(c.price);
    const isd = sd / Math.sqrt(INTRA) * 1.1;
    for (let k = 0; k < INTRA; k++) {
      const remaining = INTRA - 1 - k;
      if (k === 0) x = Math.log(prevClose) + r.normal() * isd;
      else x = x + (target - x) / (remaining + 1) + r.normal() * isd * Math.sqrt(remaining / INTRA);
      if (k === INTRA - 1) x = target;
      intra.push({
        t: new Date(session.getTime() + k * 5 * 60000),
        p: Math.exp(x),
        v: Math.round((baseVol / INTRA) * (0.5 + r()) * (k < 6 || k > INTRA - 6 ? 2.2 : 1)),
      });
    }
    stocks[c.sym] = {
      c, prevClose, price: c.price, open: intra[0].p,
      daily: closes.map((p, i) => ({ t: dates[i], p, v: vols[i] })),
      intra,
      tickRng: rngFor(c.sym + ":tick"),
      tickCount: 0,
    };
  }

  const companies = D.companies;
  const bySym = (s) => stocks[String(s).toUpperCase()];
  const all = () => companies.map((c) => stocks[c.sym]);

  // ---- derived metrics ----
  const cagr = (a, b, yrs) => (a > 0 && b > 0 ? Math.pow(b / a, 1 / yrs) - 1 : null);
  function stdev(arr) {
    const m = arr.reduce((s, x) => s + x, 0) / arr.length;
    return Math.sqrt(arr.reduce((s, x) => s + (x - m) ** 2, 0) / (arr.length - 1));
  }
  function metrics(sym) {
    const s = bySym(sym); const c = s.c;
    const price = s.price;
    const last = c.profit[c.profit.length - 1];
    const eps = last / c.shares;
    const yr = s.daily.slice(-252).map((d) => d.p).concat(price);
    const rets = [];
    for (let i = 1; i < yr.length; i++) rets.push(Math.log(yr[i] / yr[i - 1]));
    let peak = yr[0], mdd = 0;
    for (const p of yr) { peak = Math.max(peak, p); mdd = Math.min(mdd, p / peak - 1); }
    const p1m = s.daily[s.daily.length - 21].p;
    const revG = c.revenue[4] / c.revenue[3] - 1;
    const profG = c.profit[3] > 0 ? c.profit[4] / c.profit[3] - 1 : null;
    const mcap = price * c.shares;
    return {
      price, prevClose: s.prevClose,
      chg: price - s.prevClose, chgPct: (price / s.prevClose - 1) * 100,
      mcap, capClass: mcap > 60000 ? "Large-cap" : mcap > 35000 ? "Mid-cap" : "Small-cap",
      eps, pe: eps > 0 ? price / eps : null,
      revenue: c.revenue[4], profit: last,
      margin: (last / c.revenue[4]) * 100,
      de: c.lender ? null : c.debt / c.equity,
      deRaw: c.debt / c.equity,
      roe: (last / c.equity) * 100,
      divYield: (c.div / price) * 100,
      revCagr: cagr(c.revenue[0], c.revenue[4], 4),
      profitCagr: cagr(c.profit[0], c.profit[4], 4),
      revGrowth: revG, profitGrowth: profG,
      vol: stdev(rets) * Math.sqrt(252),
      hi52: Math.max(...yr), lo52: Math.min(...yr),
      ret1Y: (price / yr[0] - 1) * 100,
      ret1M: (price / p1m - 1) * 100,
      mdd: mdd * 100,
      avgVol: s.daily.slice(-20).reduce((a, d) => a + d.v, 0) / 20,
      dayVol: s.intra.reduce((a, d) => a + d.v, 0),
    };
  }
  function medianPE() {
    const pes = companies.map((c) => metrics(c.sym).pe).filter((x) => x != null).sort((a, b) => a - b);
    const m = Math.floor(pes.length / 2);
    return pes.length % 2 ? pes[m] : (pes[m - 1] + pes[m]) / 2;
  }

  // ---- series by timeframe ----
  const TF = { "1D": "1D", "1W": 5, "1M": 21, "6M": 126, "1Y": 252, "ALL": DAYS };
  function series(sym, tf) {
    const s = bySym(sym);
    if (tf === "1D") return s.intra.slice();
    if (tf === "1W") {
      // previous 4 days expanded to hourly-ish points + today's session sampled
      const r = rngFor(sym + ":1w");
      const out = [];
      const d = s.daily.slice(-5);
      for (let i = 1; i < d.length; i++) {
        const a = d[i - 1].p, b = d[i].p;
        for (let k = 0; k < 7; k++) {
          const f = k / 6;
          const t = new Date(d[i].t); t.setHours(9 + k, k === 0 ? 15 : 15, 0, 0);
          const noise = k === 0 || k === 6 ? 0 : r.normal() * Math.abs(b - a) * 0.35 + r.normal() * a * 0.002;
          out.push({ t, p: a + (b - a) * f + noise, v: Math.round(d[i].v / 7) });
        }
      }
      s.intra.forEach((x, i) => { if (i % 10 === 0 || i === s.intra.length - 1) out.push({ ...x, v: x.v * 10 }); });
      return out;
    }
    const n = TF[tf];
    const out = s.daily.slice(-n);
    out.push({ t: new Date(), p: s.price, v: s.intra.reduce((a, x) => a + x.v, 0) });
    return out;
  }

  // ---- simulated indices (built from the demo universe; labelled as simulated) ----
  const indexDefs = [
    { id: "NIFTY", name: "NIFTY 50", base: 23450, beta: 1 },
    { id: "SENSEX", name: "SENSEX", base: 77120, beta: 0.95 },
  ];
  function indexWeights() {
    const tot = companies.reduce((a, c) => a + c.price * c.shares, 0);
    return companies.map((c) => (c.price * c.shares) / tot);
  }
  const W = indexWeights();
  function indexRet(getP, getRef) {
    return companies.reduce((a, c, i) => a + W[i] * (getP(c.sym) / getRef(c.sym) - 1), 0);
  }
  function indexLevel(def) {
    const dayRet = indexRet((s) => bySym(s).price, (s) => bySym(s).prevClose) * def.beta;
    const prev = def.base / (1 + indexRet((s) => bySym(s).c.price, (s) => bySym(s).prevClose) * def.beta);
    const level = prev * (1 + dayRet);
    return { ...def, level, prev, chg: level - prev, chgPct: dayRet * 100 };
  }
  function indexSeries(def, tf) {
    const cur = indexLevel(def);
    if (tf === "1W") {
      const per = companies.map((c) => series(c.sym, "1W"));
      const len = Math.min(...per.map((p) => p.length));
      return per[0].slice(0, len).map((pt, k) => ({ t: pt.t, p: cur.prev * (1 + def.beta * companies.reduce((a, c, i) => a + W[i] * (per[i][k].p / bySym(c.sym).prevClose - 1), 0)) }));
    }
    if (tf === "1D") {
      return bySym(companies[0].sym).intra.map((_, k) => ({
        t: bySym(companies[0].sym).intra[k].t,
        p: cur.prev * (1 + def.beta * companies.reduce((a, c, i) => a + W[i] * ((bySym(c.sym).intra[k] || bySym(c.sym).intra.at(-1)).p / bySym(c.sym).prevClose - 1), 0)),
      }));
    }
    const n = TF[tf] || 252;
    const out = [];
    for (let j = DAYS - n; j < DAYS; j++) {
      const r = companies.reduce((a, c, i) => a + W[i] * (bySym(c.sym).daily[j].p / bySym(c.sym).prevClose - 1), 0);
      out.push({ t: dates[j], p: cur.prev * (1 + def.beta * r) });
    }
    out.push({ t: new Date(), p: cur.level });
    return out;
  }
  const indices = () => indexDefs.map(indexLevel);

  // ---- simulated ticks ----
  const listeners = new Set();
  let lastTick = new Date();
  function tick() {
    for (const s of all()) {
      const sd = s.c.vol / Math.sqrt(252) / Math.sqrt(INTRA) * 0.6;
      s.price = Math.max(0.5, s.price * Math.exp(s.tickRng.normal() * sd));
      s.tickCount++;
      const lastBar = s.intra[s.intra.length - 1];
      if (s.tickCount % 5 === 0 && s.intra.length < 260) {
        s.intra.push({ t: new Date(), p: s.price, v: Math.round(lastBar.v * (0.7 + s.tickRng() * 0.6)) });
      } else {
        lastBar.p = s.price;
      }
    }
    lastTick = new Date();
    listeners.forEach((fn) => { try { fn(); } catch (e) { console.error(e); } });
  }
  let timer = null;
  function start(ms = 4000) { if (!timer) timer = setInterval(tick, ms); }
  function stop() { clearInterval(timer); timer = null; }
  const onTick = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };

  return {
    companies, stocks, bySym, all, metrics, medianPE, series, TF: Object.keys(TF),
    indices, indexDefs, indexSeries, start, stop, onTick, tick,
    lastTick: () => lastTick, sessionStart: session,
  };
})();

/* ---------- formatting helpers ---------- */
window.KF = (() => {
  const inr = (n, d = 2) => (n == null || isNaN(n) ? "—" : "₹" + Number(n).toLocaleString("en-IN", { minimumFractionDigits: d, maximumFractionDigits: d }));
  const num = (n, d = 2) => (n == null || isNaN(n) ? "—" : Number(n).toLocaleString("en-IN", { minimumFractionDigits: d, maximumFractionDigits: d }));
  const cr = (n) => (n == null ? "—" : (n < 0 ? "−" : "") + "₹" + Math.abs(Math.round(n)).toLocaleString("en-IN") + " Cr");
  const pct = (n, d = 2, sign = true) => (n == null || isNaN(n) ? "—" : (sign && n > 0 ? "+" : n < 0 ? "−" : "") + Math.abs(n).toFixed(d) + "%");
  const signed = (n, d = 2) => (n > 0 ? "+" : n < 0 ? "−" : "") + "₹" + Math.abs(n).toLocaleString("en-IN", { minimumFractionDigits: d, maximumFractionDigits: d });
  const cls = (n) => (n > 0 ? "up" : n < 0 ? "down" : "");
  const compact = (n) => {
    if (n >= 1e7) return (n / 1e7).toFixed(2) + " Cr";
    if (n >= 1e5) return (n / 1e5).toFixed(2) + " L";
    return Math.round(n).toLocaleString("en-IN");
  };
  const date = (d, opts = { day: "numeric", month: "short", year: "numeric" }) => new Date(d).toLocaleDateString("en-IN", opts);
  const time = (d) => new Date(d).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  return { inr, num, cr, pct, signed, cls, compact, date, time, esc };
})();
