/*
 * Real-data features (need `node server.js`, which proxies and caches the sources):
 *  - Mutual Fund Explorer: real NAV history from AMFI via mfapi.in, returns, drawdown, SIP backtest (XIRR), compare.
 *  - Live Headlines: real headlines from Google News RSS, with plain-language glossary chips.
 *  - India inflation: World Bank CPI series, used by the inflation calculator and goal planner.
 * Nothing here is invented: if a source is down, the UI says so.
 */
window.KOSH_REAL = (() => {
  const F = window.KF, C = window.KC, D = window.KOSH_DATA;
  const esc = F.esc;
  const mem = new Map();

  async function get(path) {
    if (mem.has(path)) return mem.get(path);
    const pr = fetch(path, { cache: "no-store" }).then(async (r) => {
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || (r.status === 404 ? "This feature needs the Kosh server (node server.js)." : "Request failed"));
      return j;
    });
    mem.set(path, pr);
    pr.catch(() => mem.delete(path));
    return pr;
  }
  const skel = (n = 3, h = 18) => `<div class="stack" style="gap:8px">${Array.from({ length: n }, () => `<div class="skeleton" style="height:${h}px"></div>`).join("")}</div>`;
  const errBox = (msg, retry = true) => `<div class="card empty"><div style="font-weight:600;color:var(--text)">Couldn't load live data</div><p>${esc(msg)}</p>${retry ? `<button class="btn sm" data-retry>Try again</button>` : ""}</div>`;
  const iso = (d) => new Date(d + "T00:00:00Z"); // UTC, so date maths never shifts a day in IST
  const fmtD = (d) => F.date(iso(d));

  /* ---------- inflation (shared) ---------- */
  async function inflation() {
    const j = await get("/api/real/inflation");
    const rows = j.rows;
    const last = rows.at(-1);
    const ten = rows.slice(-10);
    const avg10 = ten.reduce((s, r) => s + r[1], 0) / ten.length;
    return { rows, last, avg10, span: [ten[0][0], last[0]], source: j.source, stale: j.stale };
  }

  /* ---------- NAV maths ---------- */
  function idxOnOrBefore(data, dateStr) {
    let lo = 0, hi = data.length - 1, ans = -1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (data[m][0] <= dateStr) { ans = m; lo = m + 1; } else hi = m - 1; }
    return ans;
  }
  const shift = (dateStr, months) => { const d = iso(dateStr); const day = d.getUTCDate(); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() + months); const dim = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate(); d.setUTCDate(Math.min(day, dim)); return d.toISOString().slice(0, 10); };
  function ret(data, years) {
    const last = data.at(-1);
    const target = shift(last[0], -Math.round(years * 12));
    if (data[0][0] > target) return null;
    const i = idxOnOrBefore(data, target);
    if (i < 0) return null;
    const r = last[1] / data[i][1];
    return years >= 1 ? (Math.pow(r, 1 / years) - 1) * 100 : (r - 1) * 100;
  }
  function stats(data) {
    let peak = data[0][1], mdd = 0, mddAt = data[0][0];
    for (const [d, v] of data) { peak = Math.max(peak, v); const dd = v / peak - 1; if (dd < mdd) { mdd = dd; mddAt = d; } }
    const yr = data.slice(-250), r = [];
    for (let i = 1; i < yr.length; i++) r.push(Math.log(yr[i][1] / yr[i - 1][1]));
    const mean = r.reduce((s, x) => s + x, 0) / (r.length || 1);
    const vol = Math.sqrt(r.reduce((s, x) => s + (x - mean) ** 2, 0) / Math.max(1, r.length - 1)) * Math.sqrt(250) * 100;
    return { mdd: mdd * 100, mddAt, vol };
  }
  function xirr(flows) {
    // flows: [{t: Date, v: number}] negative = invested
    const t0 = flows[0].t.getTime();
    const f = (r) => flows.reduce((s, x) => s + x.v / Math.pow(1 + r, (x.t - t0) / 31557600000), 0);
    const df = (r) => flows.reduce((s, x) => { const y = (x.t - t0) / 31557600000; return s - (y * x.v) / Math.pow(1 + r, y + 1); }, 0);
    let r = 0.1;
    for (let k = 0; k < 60; k++) { const d = df(r); if (!d) break; const nr = r - f(r) / d; if (!isFinite(nr)) break; if (Math.abs(nr - r) < 1e-7) return nr; r = Math.max(-0.99, nr); }
    return isFinite(r) && Math.abs(f(r)) < 1 ? r : null;
  }
  function sip(data, monthly, years) {
    const end = data.at(-1)[0];
    const start = shift(end, -Math.round(years * 12));
    if (data[0][0] > start) return null;
    let units = 0, invested = 0, month = start.slice(0, 7);
    const flows = [], path = [];
    let i = idxOnOrBefore(data, start); if (i < 0) i = 0;
    let nextBuy = start;
    for (; i < data.length; i++) {
      const [d, nav] = data[i];
      if (d >= nextBuy) { units += monthly / nav; invested += monthly; flows.push({ t: iso(d), v: -monthly }); nextBuy = shift(nextBuy, 1); }
      path.push({ t: iso(d), p: units * nav, inv: invested });
    }
    const value = units * data.at(-1)[1];
    flows.push({ t: iso(end), v: value });
    return { invested, value, xirr: xirr(flows), path, installments: flows.length - 1, start };
  }
  const thin = (arr, max = 700) => { if (arr.length <= max) return arr; const k = Math.ceil(arr.length / max); return arr.filter((_, i) => i % k === 0 || i === arr.length - 1); };

  /* ================= Mutual Fund Explorer ================= */
  const RANGES = [["1M", 1], ["6M", 6], ["1Y", 12], ["3Y", 36], ["5Y", 60], ["ALL", 0]];
  function funds(root, arg, UI) {
    const S = UI.S();
    S.funds = S.funds || []; S.fundCmp = S.fundCmp || [];
    let alive = true;
    const code = (arg || "").match(/^\d{3,7}$/) ? arg : null;
    const head = `<div class="page-head"><div><div class="eyebrow">Real data · AMFI NAVs</div><h1>Mutual Fund Explorer</h1><p>Search any Indian mutual fund. See its real NAV history and returns, then test a SIP on actual past prices.</p></div><span class="tag up"><span class="dot"></span> Live source</span></div>`;
    if (!code) {
      root.innerHTML = head + `
        <div class="grid g-main" style="align-items:start">
          <div class="stack" style="gap:16px">
            <section class="card"><div class="field"><label for="mf-q">Search funds</label><input class="input" id="mf-q" placeholder="e.g. Nifty 50 index, flexi cap, ELSS, liquid" autocomplete="off"></div>
              <div class="row" style="margin-top:10px"><span class="note">Try:</span>${["Nifty 50 Index Direct Growth", "Flexi Cap Direct Growth", "ELSS Direct Growth", "Liquid Fund Direct Growth", "Gold ETF Fund of Fund"].map((q) => `<button class="chip" data-q="${q}">${q}</button>`).join("")}</div>
              <div id="mf-res" style="margin-top:14px"></div></section>
          </div>
          <aside class="stack" style="gap:16px">
            <section class="card"><div class="card-head"><h2>My funds</h2></div><div id="mf-saved"></div></section>
            <section class="card"><div class="card-head"><h2>Reading fund names</h2></div><ul class="bullets">
              <li><strong>Direct vs Regular:</strong> same portfolio. Regular plans include a distributor commission, so the expense ratio is higher and long-term returns are a bit lower.</li>
              <li><strong>Growth vs IDCW:</strong> Growth reinvests gains, and the NAV keeps rising. IDCW pays some out, so its NAV history understates total return.</li>
              <li><strong>Index fund:</strong> copies an index such as the Nifty 50, usually at low cost.</li></ul></section>
          </aside>
        </div>`;
      const saved = () => { root.querySelector("#mf-saved").innerHTML = S.funds.length ? S.funds.map((f) => `<a class="list-item click" href="#/funds/${f.code}" style="color:var(--text);text-decoration:none"><div class="grow"><div style="font-weight:600;font-size:13px">${esc(f.name)}</div><div class="note">Code ${f.code}</div></div></a>`).join("") : `<p class="muted">Funds you save will appear here.</p>`; };
      saved();
      let t = null, seq = 0;
      const search = async (q) => {
        const out = root.querySelector("#mf-res");
        if (q.trim().length < 3) { out.innerHTML = `<p class="note">Type at least 3 characters.</p>`; return; }
        const my = ++seq;
        out.innerHTML = skel(5, 40);
        try {
          const j = await get("/api/real/mf/search?q=" + encodeURIComponent(q.trim()));
          if (!alive || my !== seq) return;
          out.innerHTML = j.results.length ? `<div class="note" style="margin-bottom:6px">${j.results.length} match${j.results.length > 1 ? "es" : ""}</div>` + j.results.map((r) => {
            const n = r.schemeName;
            const tags = [/direct/i.test(n) ? ["Direct", "up"] : /regular/i.test(n) ? ["Regular", "warn"] : null, /growth/i.test(n) ? ["Growth", "info"] : /idcw|dividend/i.test(n) ? ["IDCW", ""] : null].filter(Boolean);
            return `<a class="list-item click" href="#/funds/${r.schemeCode}" style="color:var(--text);text-decoration:none"><div class="grow"><div style="font-weight:600">${esc(n)}</div><div class="row" style="gap:4px;margin-top:4px">${tags.map(([l, c]) => `<span class="tag ${c}">${l}</span>`).join("")}<span class="note">Code ${r.schemeCode}</span></div></div><span class="faint">›</span></a>`;
          }).join("") : `<div class="empty">No funds found for “${esc(q)}”. Try a shorter name.</div>`;
        } catch (e) { if (alive && my === seq) out.innerHTML = errBox(e.message); }
      };
      root.querySelector("#mf-q").addEventListener("input", (e) => { clearTimeout(t); t = setTimeout(() => search(e.target.value), 350); });
      root.onclick = (e) => {
        const c = e.target.closest("[data-q]"); if (c) { root.querySelector("#mf-q").value = c.dataset.q; search(c.dataset.q); }
        if (e.target.closest("[data-retry]")) { mem.clear(); search(root.querySelector("#mf-q").value); }
      };
      root.querySelector("#mf-q").focus();
      return () => { alive = false; clearTimeout(t); root.onclick = null; };
    }

    // ----- detail -----
    root.innerHTML = head + skel(6, 28);
    let range = "3Y", amt = 5000, yrs = 3, fund = null, infl = null;
    const load = async () => {
      try {
        fund = await get("/api/real/mf/" + code);
        if (!alive) return;
        render();
        inflation().then((x) => { infl = x; if (alive) drawSip(); }).catch(() => { infl = false; if (alive) drawSip(); });
      } catch (e) {
        if (!alive) return;
        const nf = /No mutual fund/.test(e.message);
        root.innerHTML = head + (nf ? `<div class="card empty"><div style="font-weight:600;color:var(--text)">Fund not found</div><p>${esc(e.message)}</p><a class="btn sm primary" href="#/funds">Search funds</a></div>` : errBox(e.message));
      }
    };
    const render = () => {
      const { meta, data } = fund;
      const last = data.at(-1), prev = data.at(-2) || last;
      const chg = (last[1] / prev[1] - 1) * 100;
      const maxYrs = Math.floor((iso(last[0]) - iso(data[0][0])) / 31557600000);
      yrs = Math.min(yrs, Math.max(1, maxYrs));
      const isSaved = S.funds.some((f) => f.code === code), inCmp = S.fundCmp.includes(code);
      const ageDays = Math.round((Date.now() - iso(last[0])) / 864e5);
      root.innerHTML = `
        <div class="row" style="margin-bottom:10px"><a class="btn sm ghost" href="#/funds">← All funds</a></div>
        <div class="stock-head"><div><div class="eyebrow">${esc(meta.fund_house || "")}</div><h1 style="max-width:760px">${esc(meta.scheme_name)}</h1><div class="row muted" style="gap:6px;margin-top:6px"><span class="tag">${esc(meta.scheme_category || "Category n/a")}</span><span class="tag">Code ${esc(meta.scheme_code)}</span>${meta.isin_growth ? `<span class="tag">ISIN ${esc(meta.isin_growth)}</span>` : ""}</div></div>
          <div style="text-align:right"><div class="note">NAV on ${fmtD(last[0])}</div><div class="price-big">${F.inr(last[1], 4)}</div><div class="change ${F.cls(chg)}">${F.pct(chg)} vs previous NAV</div>${ageDays > 5 ? `<div class="tag warn" style="margin-top:4px">Last NAV is ${ageDays} days old</div>` : ""}</div></div>
        <div class="row" style="margin-bottom:16px"><button class="btn" id="f-save">${UI.ic("star")} ${isSaved ? "Saved" : "Save fund"}</button><button class="btn" id="f-cmp">${UI.ic("compare")} ${inCmp ? "In comparison" : "Add to comparison"}</button>${S.fundCmp.length ? `<a class="btn ghost" href="#/funds/${code}#cmp" id="f-go-cmp">Compare (${S.fundCmp.length})</a>` : ""}</div>
        <div class="grid g-main" style="align-items:start">
          <div class="stack" style="gap:16px">
            <section class="card"><div class="card-head"><h2>NAV history</h2>${UI.seg ? "" : ""}<div class="seg" data-seg="frange">${RANGES.map(([r]) => `<button data-v="${r}" aria-pressed="${r === range}">${r}</button>`).join("")}</div></div><div class="chart" id="f-chart"></div><div class="chart-explain" id="f-explain"></div></section>
            <section class="card"><div class="card-head"><h2>SIP backtest on real NAVs</h2><span class="note">Buys on the first NAV date of each month</span></div>
              <div class="grid g2"><div class="field"><div class="spread"><label for="f-amt">Monthly SIP</label><span class="num" id="f-amt-l"></span></div><input type="range" id="f-amt" min="500" max="50000" step="500" value="${amt}"></div>
              <div class="field"><div class="spread"><label for="f-yrs">Started</label><span class="num" id="f-yrs-l"></span></div><input type="range" id="f-yrs" min="1" max="${Math.max(1, Math.min(15, maxYrs))}" step="1" value="${yrs}" ${maxYrs < 1 ? "disabled" : ""}></div></div>
              <div id="f-sip" style="margin-top:12px"></div></section>
            <section class="card" id="cmp"><div class="card-head"><h2>Compare funds</h2><span class="note">Up to 3 · add from any fund page</span></div><div id="f-cmp-body"></div></section>
          </div>
          <div class="stack" style="gap:16px">
            <section class="card"><div class="card-head"><h2>Returns ${UI.info("cagr")}</h2><span class="note">Point-to-point</span></div><div id="f-ret"></div></section>
            <section class="card"><div class="card-head"><h2>Risk on real data ${UI.info("beta")}</h2></div><div id="f-risk"></div></section>
            <section class="card"><p class="note" style="margin:0">Source: ${esc(fund.source)}${fund.stale ? " (cached copy, source unavailable)" : ""}. History from ${fmtD(data[0][0])} (${data.length.toLocaleString("en-IN")} NAVs). Returns ignore exit load and tax. Past performance doesn't guarantee future returns.${/idcw|dividend/i.test(meta.scheme_name) ? " <strong>This is an IDCW plan: payouts lower the NAV, so these figures understate total return.</strong>" : ""}</p></section>
          </div>
        </div>`;
      const rr = [["1 month", 1 / 12], ["6 months", 0.5], ["1 year", 1], ["3 years", 3], ["5 years", 5], ["10 years", 10]];
      root.querySelector("#f-ret").innerHTML = `<table class="t"><tbody>${rr.map(([l, y]) => { const v = ret(data, y); return `<tr><td>${l}${y > 1 ? ' <span class="faint">(per year)</span>' : ""}</td><td class="r change ${F.cls(v)}">${v == null ? '<span class="faint">not enough history</span>' : F.pct(v, 2)}</td></tr>`; }).join("")}</tbody></table>`;
      const st = stats(data);
      root.querySelector("#f-risk").innerHTML = `<div class="grid g2" style="gap:10px"><div class="stat-mini"><span class="label">Volatility (last ~1Y)</span><span class="value">${st.vol.toFixed(1)}%</span></div><div class="stat-mini"><span class="label">Worst fall ever</span><span class="value down">${F.pct(st.mdd, 1)}</span></div></div><p class="note" style="margin-top:8px">The worst peak-to-trough fall bottomed on ${fmtD(st.mddAt)}. ${st.vol < 3 ? "Very low volatility, typical of liquid or debt funds." : st.vol < 12 ? "Moderate swings." : "Equity-like swings: expect years with losses."}</p>`;
      drawChart(); drawSip(); drawCmp();
    };
    const drawChart = () => {
      const { data } = fund;
      const months = RANGES.find((r) => r[0] === range)[1];
      const from = months ? shift(data.at(-1)[0], -months) : data[0][0];
      const s = data.slice(Math.max(0, idxOnOrBefore(data, from)));
      const pts = thin(s.map(([d, v]) => ({ t: iso(d), p: v })));
      if (pts.length < 2) { root.querySelector("#f-chart").innerHTML = `<p class="muted">Not enough data for this range.</p>`; return; }
      C.line(root.querySelector("#f-chart"), { series: [{ name: "NAV", color: pts.at(-1).p >= pts[0].p ? "var(--up)" : "var(--down)", data: pts }], tf: months && months <= 1 ? "1M" : "1Y", height: 260, label: "NAV history" });
      const ch = (s.at(-1)[1] / s[0][1] - 1) * 100;
      let hi = s[0], lo = s[0]; s.forEach((x) => { if (x[1] > hi[1]) hi = x; if (x[1] < lo[1]) lo = x; });
      root.querySelector("#f-explain").innerHTML = `Over this ${range === "ALL" ? "full history" : range} window the NAV moved <strong class="${F.cls(ch)}">${F.pct(ch)}</strong> (${F.inr(s[0][1], 2)} on ${fmtD(s[0][0])} → ${F.inr(s.at(-1)[1], 2)}). Highest ${F.inr(hi[1], 2)} on ${fmtD(hi[0])}, lowest ${F.inr(lo[1], 2)} on ${fmtD(lo[0])}.`;
    };
    const drawSip = () => {
      const el = root.querySelector("#f-sip"); if (!el || !fund) return;
      root.querySelector("#f-amt-l").textContent = F.inr(amt, 0) + "/month";
      root.querySelector("#f-yrs-l").textContent = yrs + (yrs === 1 ? " year ago" : " years ago");
      const r = sip(fund.data, amt, yrs);
      if (!r) { el.innerHTML = `<p class="muted">This fund doesn't have ${yrs} years of history yet.</p>`; return; }
      const gain = r.value - r.invested;
      const real = infl && r.xirr != null ? ((1 + r.xirr) / (1 + infl.avg10 / 100) - 1) * 100 : null;
      el.innerHTML = `<div class="grid g4" style="gap:10px"><div class="stat-mini"><span class="label">Invested</span><span class="value">${F.inr(r.invested, 0)}</span><span class="note">${r.installments} instalments</span></div><div class="stat-mini"><span class="label">Worth today</span><span class="value">${F.inr(r.value, 0)}</span></div><div class="stat-mini"><span class="label">Gain</span><span class="value ${F.cls(gain)}">${F.signed(gain, 0)}</span></div><div class="stat-mini"><span class="label">XIRR (yearly)</span><span class="value ${F.cls(r.xirr)}">${r.xirr == null ? "—" : F.pct(r.xirr * 100, 1)}</span></div></div>
        <div class="chart" id="f-sip-chart" style="margin-top:12px"></div>
        <div class="chart-explain">If you'd started ${F.inr(amt, 0)} a month on ${F.date(iso(r.start))}, you'd have put in ${F.inr(r.invested, 0)} and have <strong>${F.inr(r.value, 0)}</strong> today. ${real != null ? `After India's average consumer inflation of <strong>${infl.avg10.toFixed(1)}%</strong> a year (${infl.span[0]}–${infl.span[1]}, World Bank), your <strong>real</strong> return is about <strong class="${F.cls(real)}">${F.pct(real, 1)}</strong> a year.` : infl === false ? `<span class="faint">Inflation data couldn't be loaded right now, so the real (after-inflation) return isn't shown.</span>` : `<span class="faint">Loading inflation data…</span>`} <span class="faint">XIRR is the yearly return that accounts for when each instalment went in.</span></div>`;
      C.line(el.querySelector("#f-sip-chart"), { series: [{ name: "Value", color: "var(--accent)", data: thin(r.path) }, { name: "Invested", color: "var(--c2)", data: thin(r.path.map((x) => ({ t: x.t, p: x.inv }))) }], tf: "1Y", height: 200, area: false, label: "SIP value vs invested" });
    };
    const drawCmp = async () => {
      const el = root.querySelector("#f-cmp-body");
      if (S.fundCmp.length < 2) { el.innerHTML = `<p class="muted">${S.fundCmp.length ? "Add one more fund to compare." : "Add 2–3 funds with “Add to comparison”."}</p>${S.fundCmp.length ? `<button class="btn sm ghost" data-clear-cmp>Clear</button>` : ""}`; return; }
      el.innerHTML = skel(4, 24);
      try {
        const fs = await Promise.all(S.fundCmp.map((c) => get("/api/real/mf/" + c)));
        if (!alive) return;
        const start = fs.map((f) => f.data[0][0]).sort().at(-1);
        const from = [shift(fs[0].data.at(-1)[0], -36), start].sort().at(-1);
        const cols = ["var(--c1)", "var(--c2)", "var(--c3)"];
        const ser = fs.map((f, k) => { const s = f.data.slice(Math.max(0, idxOnOrBefore(f.data, from))); return { name: f.meta.scheme_name, color: cols[k], data: thin(s.map(([d, v]) => ({ t: iso(d), p: v })), 500) }; });
        el.innerHTML = `<div class="chart" id="f-cmp-chart"></div><div class="legend" style="margin:8px 0">${ser.map((s) => `<span><i style="background:${s.color}"></i>${esc(s.name.slice(0, 48))}${s.name.length > 48 ? "…" : ""}</span>`).join("")}</div>
          <div class="table-wrap"><table class="t"><thead><tr><th>Fund</th><th class="r">1Y</th><th class="r">3Y/yr</th><th class="r">5Y/yr</th><th class="r">Volatility</th><th class="r">Worst fall</th><th></th></tr></thead><tbody>${fs.map((f, k) => { const st = stats(f.data); const c = (v) => `<td class="r change ${F.cls(v)}">${v == null ? "—" : F.pct(v, 1)}</td>`; return `<tr><td style="white-space:normal;min-width:180px"><span style="color:${cols[k]}">●</span> <a href="#/funds/${f.meta.scheme_code}">${esc(f.meta.scheme_name)}</a></td>${c(ret(f.data, 1))}${c(ret(f.data, 3))}${c(ret(f.data, 5))}<td class="r num">${st.vol.toFixed(1)}%</td><td class="r num down">${F.pct(st.mdd, 0)}</td><td><button class="btn sm ghost" data-rm="${f.meta.scheme_code}">Remove</button></td></tr>`; }).join("")}</tbody></table></div>
          <p class="note">Chart starts ${fmtD(from)} (the latest common start within 3 years) and shows % change, so funds with different NAVs compare fairly.</p>`;
        C.line(el.querySelector("#f-cmp-chart"), { series: ser, percent: true, tf: "1Y", height: 240, label: "Fund comparison" });
      } catch (e) { if (alive) el.innerHTML = errBox(e.message); }
    };
    root.onclick = (e) => {
      if (e.target.closest("[data-retry]")) { mem.clear(); load(); return; }
      const b = e.target.closest('[data-seg="frange"] button'); if (b) { range = b.dataset.v; root.querySelectorAll('[data-seg="frange"] button').forEach((x) => x.setAttribute("aria-pressed", String(x === b))); drawChart(); return; }
      if (e.target.closest("#f-save")) {
        if (S.funds.some((f) => f.code === code)) S.funds = S.funds.filter((f) => f.code !== code);
        else S.funds.unshift({ code, name: fund.meta.scheme_name });
        S.funds = S.funds.slice(0, 20); UI.save(); render(); return;
      }
      if (e.target.closest("#f-cmp")) {
        if (S.fundCmp.includes(code)) S.fundCmp = S.fundCmp.filter((c) => c !== code);
        else { if (S.fundCmp.length >= 3) { UI.toast("You can compare up to 3 funds. Remove one first."); return; } S.fundCmp.push(code); }
        UI.save(); render(); if (S.fundCmp.length >= 2) root.querySelector("#cmp").scrollIntoView({ behavior: "smooth" }); return;
      }
      if (e.target.closest("#f-go-cmp")) { e.preventDefault(); root.querySelector("#cmp").scrollIntoView({ behavior: "smooth" }); return; }
      const rm = e.target.closest("[data-rm]"); if (rm) { S.fundCmp = S.fundCmp.filter((c) => c !== rm.dataset.rm); UI.save(); render(); return; }
      if (e.target.closest("[data-clear-cmp]")) { S.fundCmp = []; UI.save(); render(); }
    };
    root.oninput = (e) => {
      if (e.target.id === "f-amt") { amt = +e.target.value; drawSip(); }
      if (e.target.id === "f-yrs") { yrs = +e.target.value; drawSip(); }
    };
    load();
    UI.award && UI.award("funds");
    return () => { alive = false; root.onclick = null; root.oninput = null; };
  }

  /* ================= Live headlines ================= */
  const TOPICS = [["Markets", "sensex OR nifty"], ["RBI & rates", "RBI repo rate"], ["Inflation", "India inflation CPI"], ["IPOs", "IPO India"], ["Mutual funds", "mutual fund SIP India"], ["SEBI", "SEBI"], ["Budget & tax", "India income tax capital gains"]];
  const TERMS = [[/\brepo\b/i, "repo"], [/\binflation|\bcpi\b/i, "inflation"], [/\bipo\b/i, "ipo"], [/\bfii|\bfpi|foreign (institutional|portfolio)/i, "fii"], [/\bsensex|\bnifty/i, "index"], [/\bgdp\b/i, "gdp"], [/\bmutual fund|\bsip\b/i, "mf"], [/\bdividend/i, "divy"], [/\bsebi\b/i, "sebi"], [/\bcapital gains?|\bltcg|\bstcg/i, "cgt"], [/\bp\/e|price[- ]to[- ]earnings/i, "pe"], [/\bmarket cap/i, "mcap"]];
  function headlines(root, UI) {
    let alive = true, cur = TOPICS[0][1], seq = 0;
    root.innerHTML = `
      <div class="page-head"><div><div class="eyebrow">Real headlines</div><h1>Live Market Headlines</h1><p>Today's real financial news for India. Kosh doesn't rewrite or summarise it. It links you to the original and explains the jargon.</p></div><span class="tag up"><span class="dot"></span> Google News</span></div>
      <div class="card" style="margin-bottom:16px"><div class="row">${TOPICS.map(([l, q], i) => `<button class="chip" data-topic="${esc(q)}" aria-pressed="${i === 0}">${l}</button>`).join("")}
        <form id="hl-form" class="row hl-form" style="flex-wrap:nowrap"><input class="input" id="hl-q" placeholder="Search a company or topic" maxlength="80" aria-label="Search headlines"><button class="btn sm">Search</button></form></div></div>
      <div class="grid g-main" style="align-items:start"><div id="hl-list"></div>
        <aside class="stack" style="gap:16px"><section class="card"><div class="card-head"><h2>Reading news like an investor</h2></div><ol class="bullets" style="padding-left:20px"><li>Ask: does this change the company's <em>earnings</em>, or just today's mood?</li><li>Check the date. Old news gets recycled on social media.</li><li>One headline is never a reason to buy or sell. Look for the company's own filing.</li><li>Scary headlines sell clicks. Remember the Crash Test.</li></ol><a class="btn sm" href="#/crash">${UI.ic("zap")} Take the Crash Test</a></section>
        <section class="card"><p class="note" style="margin:0" id="hl-src">Headlines and links come from the Google News RSS feed. Kosh shows the headline, source and time, and opens the publisher's article. Nothing is generated.</p></section></aside></div>`;
    const load = async (q) => {
      const my = ++seq;
      const el = root.querySelector("#hl-list");
      el.innerHTML = `<div class="card">${skel(6, 46)}</div>`;
      try {
        const j = await get("/api/real/news?q=" + encodeURIComponent(q));
        if (!alive || my !== seq) return;
        const items = j.items.slice().sort((a, b) => (b.published || 0) - (a.published || 0));
        el.innerHTML = items.length ? `<div class="card"><div class="spread" style="margin-bottom:6px"><span class="note">${items.length} headlines · fetched ${F.time(j.fetched)}${j.stale ? " (cached)" : ""}</span><button class="btn sm ghost" data-refresh>Refresh</button></div>${items.map((it) => {
          const terms = [...new Set(TERMS.filter(([re]) => re.test(it.title)).map(([, k]) => k))].filter((k) => D.glossary[k]);
          return `<article class="headline"><a href="${esc(it.link)}" target="_blank" rel="noopener noreferrer"><h3>${esc(it.title)}</h3></a><div class="row" style="gap:8px;margin-top:6px"><span class="tag">${esc(it.source || "Unknown source")}</span><span class="note">${it.published ? rel(it.published) : ""}</span>${terms.map((k) => `<button class="chip sm" data-term="${k}">What's “${esc(D.glossary[k].term)}”?</button>`).join("")}</div></article>`;
        }).join("")}</div>` : `<div class="card empty">No headlines found. Try another search.</div>`;
        UI.award && UI.award("headlines");
      } catch (e) { if (alive && my === seq) el.innerHTML = errBox(e.message); }
    };
    const rel = (t) => { const m = Math.round((Date.now() - t) / 60000); return m < 60 ? `${Math.max(1, m)} min ago` : m < 1440 ? `${Math.round(m / 60)} h ago` : F.date(t, { day: "numeric", month: "short", year: "numeric" }); };
    root.onclick = (e) => {
      const t = e.target.closest("[data-topic]"); if (t) { cur = t.dataset.topic; root.querySelectorAll("[data-topic]").forEach((x) => x.setAttribute("aria-pressed", String(x === t))); load(cur); }
      if (e.target.closest("[data-refresh]") || e.target.closest("[data-retry]")) { mem.delete("/api/real/news?q=" + encodeURIComponent(cur)); load(cur); }
    };
    root.querySelector("#hl-form").onsubmit = (e) => { e.preventDefault(); const q = root.querySelector("#hl-q").value.trim(); if (q.length < 2) return; cur = q; root.querySelectorAll("[data-topic]").forEach((x) => x.setAttribute("aria-pressed", "false")); load(q); };
    load(cur);
    return () => { alive = false; root.onclick = null; };
  }

  return { funds, headlines, inflation, sip, ret, xirr };
})();
