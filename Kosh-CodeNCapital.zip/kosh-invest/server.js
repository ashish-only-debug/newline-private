/*
 * Kosh dev server — zero dependencies (Node 18+).
 *   node server.js                         → serves the site; AI uses the in-browser explainer
 *   OPENAI_API_KEY=sk-... node server.js   → also enables /api/chat (LLM answers grounded in demo data)
 * Optional: OPENAI_MODEL (default gpt-4o-mini), PORT (default 5173).
 * The API key stays on the server and is never sent to the browser.
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");

const PORT = +process.env.PORT || 5173;
const ROOT = __dirname;
const KEY = process.env.OPENAI_API_KEY || "";
const MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini";
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".json": "application/json" };

const SYSTEM = `You are Kosh AI, a friendly financial educator inside a hackathon prototype for first-time Indian retail investors.
Rules:
- All companies, prices, financials and news in the provided context are FICTIONAL demo data. Say so when relevant. Never present them as real or live.
- Ground every number you mention in the provided JSON context. If something isn't in the context, say you don't have that data. Never invent figures or news.
- Explain in plain language with a short example. If mode is "advanced", you may add ratios and nuance.
- Never give personalised buy/sell/hold recommendations or price targets. Offer bull and bear considerations and what to research instead.
- Keep answers under 180 words. Use short paragraphs or "- " bullets. Use **bold** sparingly.`;

// very small in-memory rate limit per IP
const hits = new Map();
function limited(ip, max = 20) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60000);
  arr.push(now); hits.set(ip, arr);
  return arr.length > max;
}

async function chat(req, res) {
  let raw = "";
  for await (const chunk of req) { raw += chunk; if (raw.length > 60000) return send(res, 413, { error: "too large" }); }
  let body;
  try { body = JSON.parse(raw); } catch { return send(res, 400, { error: "bad json" }); }
  const q = String(body.question || "").slice(0, 600);
  if (!q) return send(res, 400, { error: "empty" });
  if (limited(req.socket.remoteAddress)) return send(res, 429, { error: "slow down" });
  const history = Array.isArray(body.history) ? body.history.slice(-6).map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content || "").slice(0, 800) })) : [];
  const messages = [
    { role: "system", content: SYSTEM },
    { role: "system", content: `Explanation mode: ${body.mode === "advanced" ? "advanced" : "beginner"}.\nDemo context JSON:\n${JSON.stringify(body.stocks || []).slice(0, 20000)}` },
    ...history,
    { role: "user", content: q },
  ];
  try {
    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${KEY}` },
      body: JSON.stringify({ model: MODEL, messages, temperature: 0.3, max_tokens: 450 }),
    });
    if (!r.ok) { console.error("LLM error", r.status, await r.text()); return send(res, 502, { error: "llm failed" }); }
    const j = await r.json();
    send(res, 200, { answer: j.choices?.[0]?.message?.content || "" });
  } catch (e) {
    console.error(e); send(res, 502, { error: "llm unreachable" });
  }
}


/* ---------- Live league rooms (in memory) ---------- */
const SETUP_MS = 20000, DAY_MS = 1500, DAYS = 60;
const rooms = new Map();
const rid = (n) => crypto.randomBytes(n).toString("hex");
function newCode() {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  for (;;) { const c = Array.from({ length: 4 }, () => A[crypto.randomInt(A.length)]).join(""); if (!rooms.has(c)) return c; }
}
function roomStatus(r) {
  if (r.status === "running" && Date.now() > r.startAt + SETUP_MS + DAYS * DAY_MS + 4000) r.status = "done";
  return r.status;
}
function publicRoom(r) {
  return {
    code: r.code, round: r.round, status: roomStatus(r), startAt: r.startAt, setupMs: SETUP_MS, dayMs: DAY_MS, days: DAYS, serverNow: Date.now(),
    players: [...r.players.values()].map((p) => ({ id: p.id, name: p.name, value: p.value, day: p.day, score: p.score, arch: p.arch, done: p.done })),
  };
}
function lanUrls() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) for (const i of list || []) if (i.family === "IPv4" && !i.internal) out.push(`http://${i.address}:${PORT}`);
  return out;
}
async function readJson(req) {
  let raw = "";
  for await (const chunk of req) { raw += chunk; if (raw.length > 10000) throw new Error("too large"); }
  return JSON.parse(raw || "{}");
}
async function league(req, res, parts) {
  // parts: [] | [code] | [code, action]
  const ip = req.socket.remoteAddress;
  if (req.method === "POST" && limited("lg:" + ip, 240)) return send(res, 429, { error: "Too many requests" });
  if (!parts.length && req.method === "POST") {
    const now = Date.now();
    for (const [c, r] of rooms) if (now - r.created > 6 * 3600e3) rooms.delete(c);
    if (rooms.size >= 100) return send(res, 503, { error: "Too many rooms" });
    const code = newCode(), hostKey = rid(16);
    rooms.set(code, { code, hostKey, round: 1, status: "lobby", startAt: null, created: now, players: new Map() });
    return send(res, 200, { code, hostKey });
  }
  const r = rooms.get(String(parts[0] || "").toUpperCase());
  if (!r) return send(res, 404, { error: "Room not found" });
  if (parts.length === 1 && req.method === "GET") return send(res, 200, publicRoom(r));
  let body;
  try { body = await readJson(req); } catch { return send(res, 400, { error: "Bad request" }); }
  const action = parts[1];
  if (action === "join") {
    const name = String(body.name || "").replace(/[\u0000-\u001f<>]/g, "").trim().slice(0, 20);
    if (name.length < 2) return send(res, 400, { error: "Nickname must be at least 2 characters." });
    if (roomStatus(r) === "running") return send(res, 409, { error: "A round is in progress — wait for the next one." });
    if (r.players.size >= 200) return send(res, 409, { error: "Room is full." });
    if ([...r.players.values()].some((p) => p.name.toLowerCase() === name.toLowerCase())) return send(res, 409, { error: "That nickname is taken." });
    const p = { id: rid(6), token: rid(16), name, value: null, day: 0, score: null, arch: null, done: false };
    r.players.set(p.id, p);
    return send(res, 200, { playerId: p.id, token: p.token, name });
  }
  if (action === "start" || action === "reset") {
    if (body.hostKey !== r.hostKey) return send(res, 403, { error: "Only the host can do that." });
    if (action === "start") {
      if (roomStatus(r) === "running") return send(res, 409, { error: "Already running." });
      if (!r.players.size) return send(res, 409, { error: "Wait for at least one player." });
      r.status = "running"; r.startAt = Date.now() + 1500;
    } else {
      r.status = "lobby"; r.startAt = null; r.round++;
    }
    for (const p of r.players.values()) Object.assign(p, { value: null, day: 0, score: null, arch: null, done: false });
    return send(res, 200, publicRoom(r));
  }
  if (action === "update") {
    const p = r.players.get(String(body.playerId));
    if (!p || p.token !== body.token) return send(res, 403, { error: "Not a player in this room." });
    const v = Number(body.value), d = Number(body.day);
    if (isFinite(v) && v >= 0 && v < 1e7) p.value = Math.round(v);
    if (isFinite(d)) p.day = Math.max(0, Math.min(DAYS, Math.floor(d)));
    if (body.done) { p.done = true; p.score = Math.max(0, Math.min(100, Math.round(Number(body.score) || 0))); p.arch = String(body.arch || "").slice(0, 40); }
    return send(res, 200, { ok: true });
  }
  return send(res, 404, { error: "Unknown action" });
}


/* ---------- Real data proxies (cached). Sources: mfapi.in (AMFI NAVs), Google News RSS, World Bank ---------- */
const cache = new Map();
async function cached(key, ttlMs, fn) {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.t < ttlMs) return hit.v;
  try {
    const v = await fn();
    cache.set(key, { t: Date.now(), v });
    if (cache.size > 300) cache.delete(cache.keys().next().value);
    return v;
  } catch (e) {
    if (hit) return { ...hit.v, stale: true }; // serve last good copy if the source is down
    throw e;
  }
}
async function getJson(url) {
  const r = await fetch(url, { headers: { "User-Agent": "KoshEdu/1.0", Accept: "application/json" }, signal: AbortSignal.timeout(12000) });
  if (!r.ok) throw new Error("upstream " + r.status);
  return r.json();
}
const decode = (s) => String(s || "").replace(/<!\[CDATA\[|\]\]>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).trim();
// World Bank responds unpredictably (milliseconds to minutes), so fetch in the background and
// keep the last real response on disk with its fetch time. Never invent values.
const INF_FILE = path.join(ROOT, ".cache-inflation.json");
let inflationData = null, inflationLoading = false;
try { inflationData = JSON.parse(fs.readFileSync(INF_FILE, "utf8")); inflationData.stale = true; } catch {}
async function warmInflation() {
  if (inflationLoading) return;
  inflationLoading = true;
  try {
    const j = await (await fetch("https://api.worldbank.org/v2/country/IN/indicator/FP.CPI.TOTL.ZG?format=json&per_page=40", { headers: { "User-Agent": "KoshEdu/1.0" }, signal: AbortSignal.timeout(60000) })).json();
    const rows = (j[1] || []).filter((r) => r.value != null).map((r) => [+r.date, +r.value]).sort((a, b) => a[0] - b[0]);
    if (!rows.length) throw new Error("no rows");
    inflationData = { rows, source: "World Bank indicator FP.CPI.TOTL.ZG (consumer price inflation, India)", fetched: Date.now() };
    try { fs.writeFileSync(INF_FILE, JSON.stringify(inflationData)); } catch {}
    console.log("Inflation data loaded:", rows.at(-1));
  } catch (e) { console.error("Inflation fetch failed:", e.message); }
  inflationLoading = false;
}
async function realData(req, res, url) {
  const p = url.pathname, q = url.searchParams;
  try {
    if (p === "/api/real/mf/search") {
      const term = String(q.get("q") || "").slice(0, 60).trim();
      if (term.length < 3) return send(res, 400, { error: "Type at least 3 characters." });
      const v = await cached("mfs:" + term.toLowerCase(), 6 * 3600e3, async () => ({ results: (await getJson("https://api.mfapi.in/mf/search?q=" + encodeURIComponent(term))).slice(0, 25) }));
      return send(res, 200, v);
    }
    let m = p.match(/^\/api\/real\/mf\/(\d{3,7})$/);
    if (m) {
      const v = await cached("mf:" + m[1], 3 * 3600e3, async () => {
        const j = await getJson("https://api.mfapi.in/mf/" + m[1]);
        if (!j || !j.meta || !j.meta.scheme_name || !Array.isArray(j.data) || !j.data.length) { const e = new Error("not found"); e.notFound = true; throw e; }
        // data comes newest-first as dd-mm-yyyy; return oldest-first [isoDate, nav]
        const data = j.data.map((d) => { const [dd, mm, yy] = d.date.split("-"); return [`${yy}-${mm}-${dd}`, +d.nav]; }).filter((d) => d[1] > 0).reverse();
        return { meta: j.meta, data, source: "AMFI via mfapi.in", fetched: Date.now() };
      });
      return send(res, 200, v);
    }
    if (p === "/api/real/news") {
      const term = String(q.get("q") || "sensex OR nifty").slice(0, 80);
      const v = await cached("news:" + term.toLowerCase(), 10 * 60e3, async () => {
        const r = await fetch(`https://news.google.com/rss/search?q=${encodeURIComponent(term)}&hl=en-IN&gl=IN&ceid=IN:en`, { headers: { "User-Agent": "Mozilla/5.0 KoshEdu/1.0" }, signal: AbortSignal.timeout(12000) });
        if (!r.ok) throw new Error("upstream " + r.status);
        const xml = await r.text();
        const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0, 30).map(([, it]) => {
          const tag = (t) => (it.match(new RegExp(`<${t}[^>]*>([\\s\\S]*?)</${t}>`)) || [])[1];
          const source = decode(tag("source"));
          let title = decode(tag("title"));
          if (source && title.endsWith(" - " + source)) title = title.slice(0, -(source.length + 3));
          const link = decode(tag("link"));
          return { title, link: /^https:\/\//.test(link) ? link : null, source, published: Date.parse(decode(tag("pubDate"))) || null };
        }).filter((x) => x.title && x.link);
        return { items, source: "Google News RSS", fetched: Date.now() };
      });
      return send(res, 200, v);
    }
    if (p === "/api/real/inflation") {
      if (inflationData) return send(res, 200, inflationData);
      warmInflation();
      return send(res, 503, { error: "Inflation data is still loading from the World Bank. Try again in a moment." });
    }
    return send(res, 404, { error: "Unknown data endpoint" });
  } catch (e) {
    if (e.notFound) return send(res, 404, { error: "No mutual fund was found with this scheme code. Search by name instead." });
    console.error("real data", p, e.message);
    return send(res, 502, { error: "The data source didn't respond. Check your internet connection and try again." });
  }
}

function send(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  res.end(JSON.stringify(obj));
}

http.createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  if (url.pathname === "/api/health") return send(res, 200, { ok: true, llm: !!KEY, model: KEY ? MODEL : null });
  if (url.pathname.startsWith("/api/real/")) return realData(req, res, url);
  if (url.pathname === "/api/info") return send(res, 200, { lan: lanUrls(), port: PORT });
  if (url.pathname === "/api/league" || url.pathname.startsWith("/api/league/")) return league(req, res, url.pathname.split("/").slice(3).filter(Boolean)).catch((e) => { console.error(e); send(res, 500, { error: "Server error" }); });
  if (url.pathname === "/api/chat" && req.method === "POST") return KEY ? chat(req, res) : send(res, 503, { error: "no llm configured" });
  let p = decodeURIComponent(url.pathname);
  if (p === "/") p = "/index.html";
  const file = path.normalize(path.join(ROOT, p));
  if (!file.startsWith(ROOT) || path.basename(file) === "server.js" || path.basename(file).startsWith(".")) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    res.writeHead(200, { "Content-Type": TYPES[path.extname(file)] || "application/octet-stream", "Cache-Control": "no-cache" });
    res.end(data);
  });
}).listen(PORT, () => {
  console.log(`Kosh running at http://localhost:${PORT}  (LLM: ${KEY ? MODEL : "off — using local explainer"})`);
  lanUrls().forEach((u) => console.log(`League players on the same Wi-Fi can join via ${u}`));
  warmInflation(); setInterval(warmInflation, 12 * 3600e3);
});
